/**
 * ElevenLabs TTS service (server-side only).
 *
 * The API key is read from the server environment — it is never
 * bundled into the browser. This module runs only on the server.
 *
 * Voice policy (strict):
 *  - The teacher voice must be "Michael C. Vincent — Suspenseful Storyteller".
 *  - Its real voice ID is fetched from the connected ElevenLabs account
 *    (GET /v1/voices, then the shared voice library) using your API key.
 *  - If that exact voice cannot be found, TTS fails with a clear
 *    VOICE_UNAVAILABLE error. No substitute voice is ever used.
 *  - If ELEVENLABS_VOICE_ID is set, it must match the exact voice returned
 *    by ElevenLabs; it is never trusted without name verification.
 */

const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY || '';
const ELEVENLABS_BASE = 'https://api.elevenlabs.io/v1';

export const TEACHER_VOICE_NAME = 'Michael C. Vincent — Suspenseful Storyteller';

export type VoiceSource = 'env' | 'account' | 'library' | null;

export interface TeacherVoiceInfo {
  expectedName: string;
  voiceId: string | null;
  voiceName: string | null;
  source: VoiceSource;
  /** True only when confirmed in the account's own voice list. */
  verifiedInAccount: boolean;
  available: boolean;
  errorCode?: string;
  message: string;
}

const NOT_RESOLVED: TeacherVoiceInfo = {
  expectedName: TEACHER_VOICE_NAME,
  voiceId: null,
  voiceName: null,
  source: null,
  verifiedInAccount: false,
  available: false,
  errorCode: 'VOICE_UNAVAILABLE',
  message: 'Teacher voice has not been resolved yet.',
};

let cached: TeacherVoiceInfo | null = null;
let resolving: Promise<TeacherVoiceInfo> | null = null;
let audioVerified = false;
let lastAudioFailureCode: string | null = null;

/** A failed synthesis must never be reported as a working voice. */
export function noteAudioFailure(code: string): void {
  audioVerified = false;
  lastAudioFailureCode = code;
}

class ElevenLabsApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly code: string,
  ) {
    super(message);
    this.name = 'ElevenLabsApiError';
  }
}

const normalize = (s: string) =>
  s.toLowerCase().replace(/[—–]/g, '-').replace(/\s+/g, ' ').trim();

/** Exact-name match for the requested voice (dash style / spacing tolerant). */
const isRequestedVoice = (name: string) => {
  return normalize(name) === normalize(TEACHER_VOICE_NAME);
};

async function elevenGet(path: string): Promise<any> {
  const res = await fetch(`${ELEVENLABS_BASE}${path}`, {
    headers: { 'xi-api-key': ELEVENLABS_API_KEY, Accept: 'application/json' },
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) {
    // Inspect the response only to classify the error. Never return or log
    // upstream request headers, credentials, or raw response bodies.
    const body = (await res.text().catch(() => '')).toLowerCase();
    if (body.includes('voices_read') || body.includes('voices (read)')) {
      throw new ElevenLabsApiError(
        'Your ElevenLabs API key is valid but lacks the Voices (read) permission. Enable Voices (read) and Text to Speech on the key, then restart the backend.',
        res.status,
        'MISSING_VOICES_READ',
      );
    }
    if (res.status === 401) {
      throw new ElevenLabsApiError(
        'ElevenLabs rejected the server API key. It may be invalid, revoked, expired, or restricted. Create a new server key with Voices (read) and Text to Speech permissions.',
        res.status,
        'INVALID_API_KEY',
      );
    }
    if (res.status === 403) {
      throw new ElevenLabsApiError(
        'ElevenLabs denied the request. Check that the API key has Voices (read) permission.',
        res.status,
        'MISSING_VOICES_READ',
      );
    }
    if (res.status === 429) {
      throw new ElevenLabsApiError(
        'ElevenLabs rate limit reached while looking up the requested voice. Retry shortly.',
        res.status,
        'RATE_LIMITED',
      );
    }
    throw new ElevenLabsApiError(
      `ElevenLabs voice lookup failed with HTTP ${res.status}. Check service availability and API-key permissions.`,
      res.status,
      'VOICE_LOOKUP_FAILED',
    );
  }
  return res.json();
}

/**
 * Fetch the real voice ID for the requested voice from the connected account.
 * Order: your account voice list, then the shared voice library. An optional
 * ELEVENLABS_VOICE_ID only constrains the result; it cannot select another voice.
 * Never falls back to a different voice.
 */
export async function resolveTeacherVoice(force = false): Promise<TeacherVoiceInfo> {
  if (cached && !force) return cached;
  if (resolving && !force) return resolving;

  resolving = (async (): Promise<TeacherVoiceInfo> => {
    const envId = (process.env.ELEVENLABS_VOICE_ID || '').trim();
    let lookupError: string | null = null;

    if (!ELEVENLABS_API_KEY) {
      cached = {
        ...NOT_RESOLVED,
        errorCode: 'MISSING_API_KEY',
        message:
          'ELEVENLABS_API_KEY is missing from this Node service. Add a rotated key with Voices (read) and Text to Speech permissions in the backend host\'s secret/environment settings, then redeploy. Never add it to Arena frontend settings.',
      };
      return cached;
    }

    // 1) Voices added to your account. page_size=100 avoids missing a voice
    //    when the account has a larger collection.
    try {
      const data = await elevenGet('/voices?page_size=100');
      const hit = (data?.voices ?? []).find((v: any) => isRequestedVoice(v?.name ?? ''));
      if (hit) {
        if (envId && hit.voice_id !== envId) {
          cached = {
            ...NOT_RESOLVED,
            message:
              'ELEVENLABS_VOICE_ID does not match Michael C. Vincent — Suspenseful Storyteller in your account. No other voice will be used.',
          };
          return cached;
        }
        cached = {
          expectedName: TEACHER_VOICE_NAME,
          voiceId: hit.voice_id,
          voiceName: hit.name,
          source: 'account',
          verifiedInAccount: true,
          available: true,
          message: `Found "${hit.name}" in your ElevenLabs account voice list.`,
        };
        return cached;
      }
    } catch (err) {
      if (err instanceof ElevenLabsApiError) {
        if (err.code === 'MISSING_VOICES_READ' || err.code === 'INVALID_API_KEY') {
          cached = { ...NOT_RESOLVED, errorCode: err.code, message: err.message };
          return cached;
        }
        if (err.code === 'RATE_LIMITED') {
          cached = { ...NOT_RESOLVED, errorCode: err.code, message: err.message };
          return cached;
        }
      }
      lookupError = err instanceof ElevenLabsApiError
        ? err.message
        : 'Could not contact ElevenLabs to inspect the account voice list.';
      console.warn('[voice] account voice list lookup failed:', lookupError);
    }

    // 2) Shared voice library (public library voices can be used directly by ID)
    try {
      const q = encodeURIComponent('Michael C. Vincent');
      const data = await elevenGet(`/shared-voices?search=${q}&page_size=100`);
      const hit = (data?.voices ?? []).find((v: any) => isRequestedVoice(v?.name ?? ''));
      if (hit) {
        if (envId && hit.voice_id !== envId) {
          cached = {
            ...NOT_RESOLVED,
            message:
              'ELEVENLABS_VOICE_ID does not match the requested Michael C. Vincent voice. No other voice will be used.',
          };
          return cached;
        }
        cached = {
          expectedName: TEACHER_VOICE_NAME,
          voiceId: hit.voice_id,
          voiceName: hit.name,
          source: 'library',
          verifiedInAccount: false,
          available: true,
          message: `Found "${hit.name}" in the ElevenLabs voice library (not in your account list). It is used directly by its real voice ID.`,
        };
        return cached;
      }
    } catch (err) {
      if (err instanceof ElevenLabsApiError) {
        if (err.code === 'MISSING_VOICES_READ' || err.code === 'INVALID_API_KEY' || err.code === 'RATE_LIMITED') {
          cached = { ...NOT_RESOLVED, errorCode: err.code, message: err.message };
          return cached;
        }
      }
      lookupError = err instanceof ElevenLabsApiError
        ? err.message
        : 'Could not contact ElevenLabs to inspect the voice library.';
      console.warn('[voice] shared library lookup failed:', lookupError);
    }

    cached = {
      ...NOT_RESOLVED,
      errorCode: lookupError ? 'VOICE_LOOKUP_FAILED' : 'VOICE_UNAVAILABLE',
      message: lookupError
        ? `${lookupError} The requested voice could not be verified; no substitute voice will be used.`
        : envId
          ? `ELEVENLABS_VOICE_ID did not resolve to the exact voice "${TEACHER_VOICE_NAME}". No substitute voice will be used.`
          : `"${TEACHER_VOICE_NAME}" was not found in your ElevenLabs account voice list or the shared voice library. No substitute voice will be used.`,
    };
    return cached;
  })();

  try {
    return await resolving;
  } finally {
    resolving = null;
  }
}

export function getTeacherVoiceInfo(): TeacherVoiceInfo {
  return cached ?? NOT_RESOLVED;
}

export interface ElevenLabsHealth {
  /** Key present and exact requested voice resolved; audio may still be untested. */
  configured: boolean;
  /** True only after this process has received a valid MP3 from ElevenLabs. */
  ready: boolean;
  audioVerified: boolean;
  audioStatus: 'untested' | 'verified' | 'failed';
  lastAudioFailureCode: string | null;
  apiKeyPresent: boolean;
  voiceId: string | null;
  voiceName: string | null;
  expectedName: string;
  source: VoiceSource;
  verifiedInAccount: boolean;
  message: string;
}

export const elevenLabsHealth = (): ElevenLabsHealth => {
  const v = getTeacherVoiceInfo();
  const configured = !!ELEVENLABS_API_KEY && v.available;
  return {
    configured,
    ready: configured && audioVerified,
    audioVerified,
    audioStatus: lastAudioFailureCode ? 'failed' : audioVerified ? 'verified' : 'untested',
    lastAudioFailureCode,
    apiKeyPresent: !!ELEVENLABS_API_KEY,
    voiceId: v.voiceId,
    voiceName: v.voiceName,
    expectedName: TEACHER_VOICE_NAME,
    source: v.source,
    verifiedInAccount: v.verifiedInAccount,
    message: !configured
      ? v.message
      : lastAudioFailureCode
        ? `The exact voice is resolved, but audio generation failed (${lastAudioFailureCode}). Retry playback and check server logs.`
        : audioVerified
          ? `The exact voice is resolved and MP3 audio has been generated successfully.`
          : `The exact voice is resolved. Audio generation has not been tested yet.`,
  };
};

export interface ElevenLabsSpeechOptions {
  text: string;
  /** Optional voice override; defaults to the resolved requested voice. */
  voiceId?: string;
  stability?: number;
  clarity?: number;
  style?: number;
  speed?: number;
}

const voiceError = (message: string, code = 'VOICE_UNAVAILABLE') => {
  const err = new Error(message) as Error & { code?: string };
  err.code = code;
  return err;
};

/**
 * Synthesise speech with ElevenLabs using ONLY the requested voice.
 * Throws VOICE_UNAVAILABLE when the key or the exact voice is missing.
 */
export async function synthesizeSpeech(
  options: ElevenLabsSpeechOptions,
): Promise<ArrayBuffer> {
  if (!ELEVENLABS_API_KEY) {
    throw voiceError(
      'ELEVENLABS_API_KEY is missing from the deployed Node service. Set a rotated key in the backend host\'s secret/environment settings and redeploy; never expose it in the frontend.',
      'MISSING_API_KEY',
    );
  }

  const voice = await resolveTeacherVoice();
  if (!voice.available || !voice.voiceId) {
    throw voiceError(voice.message, voice.errorCode ?? 'VOICE_UNAVAILABLE');
  }

  // Lock to the account-resolved teacher voice. A request body cannot select
  // a different/default voice.
  const voiceId = voice.voiceId;

  const body: Record<string, any> = {
    text: options.text,
    model_id: 'eleven_multilingual_v2', // Hindi + English + Hinglish in the same male voice
    voice_settings: {
      // Calm, friendly, mature, patient teacher delivery.
      // High stability + low style keeps the deep male voice steady and
      // conversational instead of dramatic or "suspenseful".
      stability: options.stability ?? 0.68,
      similarity_boost: options.clarity ?? 0.8,
      style: options.style ?? 0.05,
      use_speaker_boost: true,
      ...(options.speed !== undefined ? { speed: options.speed } : {}),
    },
  };

  const response = await fetch(
    `${ELEVENLABS_BASE}/text-to-speech/${voiceId}?output_format=mp3_44100_128`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': ELEVENLABS_API_KEY,
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    },
  );

  if (!response.ok) {
    const responseText = (await response.text().catch(() => '')).toLowerCase();
    if (responseText.includes('text_to_speech') || responseText.includes('text to speech')) {
      const err = new Error(
        'Your ElevenLabs API key is missing Text to Speech permission. Enable it for the server key and restart the backend.',
      ) as Error & { code?: string };
      err.code = 'MISSING_TEXT_TO_SPEECH';
      throw err;
    }
    if (response.status === 403) {
      const err = new Error(
        'ElevenLabs denied text-to-speech. Ensure this server API key has Text to Speech permission.',
      ) as Error & { code?: string };
      err.code = 'MISSING_TEXT_TO_SPEECH';
      throw err;
    }
    if (response.status === 401) {
      const err = new Error(
        'ElevenLabs rejected the server API key. Rotate it and ensure it has Text to Speech and Voices (read) permissions.',
      ) as Error & { code?: string };
      err.code = 'INVALID_API_KEY';
      throw err;
    }
    throw new Error(`ElevenLabs text-to-speech failed with HTTP ${response.status}.`);
  }

  const buffer = await response.arrayBuffer();
  if (!buffer.byteLength) {
    throw new Error('ElevenLabs returned empty audio.');
  }

  // Catch HTML/JSON error responses mistakenly returned with a 2xx before
  // those bytes reach the browser's audio decoder.
  const bytes = new Uint8Array(buffer, 0, Math.min(buffer.byteLength, 3));
  const hasId3 = bytes.length >= 3 && bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33;
  const hasMpegFrame = bytes.length >= 2 && bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0;
  if (buffer.byteLength < 128 || (!hasId3 && !hasMpegFrame)) {
    throw new Error('ElevenLabs response was not valid MP3 audio.');
  }
  audioVerified = true;
  lastAudioFailureCode = null;
  return buffer;
}
