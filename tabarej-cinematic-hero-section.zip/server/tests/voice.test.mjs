import { test, after } from 'node:test';
import assert from 'node:assert/strict';

// A dummy key lets us test the API contract without contacting ElevenLabs.
process.env.ELEVENLABS_API_KEY = 'TEST_KEY_NOT_REAL';
delete process.env.ELEVENLABS_VOICE_ID;

const originalFetch = globalThis.fetch;
after(() => { globalThis.fetch = originalFetch; });

const {
  resolveTeacherVoice,
  synthesizeSpeech,
  elevenLabsHealth,
  noteAudioFailure,
} = await import('../dist/services/elevenlabs.js');

test('only the exact Michael C. Vincent voice ID is used, and a valid MP3 is accepted', async () => {
  const requests = [];
  const fakeMp3 = Buffer.concat([Buffer.from('ID3'), Buffer.alloc(320)]);
  globalThis.fetch = async (url, options = {}) => {
    requests.push({ url: String(url), options });
    if (String(url).includes('/voices?')) {
      return new Response(JSON.stringify({
        voices: [
          { voice_id: 'WRONG_NAME', name: 'Michael C. Vincent - Suspenseful Storyteller Clone' },
          { voice_id: 'EXACT_ACCOUNT_ID', name: 'Michael C. Vincent - Suspenseful Storyteller' },
        ],
      }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    if (String(url).includes('/text-to-speech/')) {
      return new Response(fakeMp3, { status: 200, headers: { 'Content-Type': 'audio/mpeg' } });
    }
    throw new Error(`Unexpected mocked request: ${url}`);
  };

  const voice = await resolveTeacherVoice(true);
  assert.equal(voice.available, true);
  assert.equal(voice.verifiedInAccount, true);
  assert.equal(voice.voiceId, 'EXACT_ACCOUNT_ID');
  assert.equal(elevenLabsHealth().ready, false, 'Lookup is not proof that audio works');

  const audio = await synthesizeSpeech({ text: 'Chalo beta, maths samajhte hain.', voiceId: 'OVERRIDE_REJECTED' });
  assert.equal(audio.byteLength, fakeMp3.byteLength);
  const tts = requests.find(({ url }) => url.includes('/text-to-speech/'));
  assert.match(tts.url, /\/EXACT_ACCOUNT_ID\?output_format=mp3_44100_128$/);
  assert.doesNotMatch(tts.url, /WRONG_NAME|OVERRIDE_REJECTED/);
  const body = JSON.parse(tts.options.body);
  assert.equal(body.model_id, 'eleven_multilingual_v2');
  assert.equal(tts.options.headers['xi-api-key'], 'TEST_KEY_NOT_REAL');
  assert.equal(elevenLabsHealth().ready, true, 'Readiness requires a validated MP3');

  noteAudioFailure('TTS_FAILED');
  assert.equal(elevenLabsHealth().ready, false, 'A later failed generation clears readiness');
});

test('a different voice is never silently selected', async () => {
  globalThis.fetch = async (url) => {
    if (String(url).includes('/voices?')) {
      return new Response(JSON.stringify({ voices: [
        { voice_id: 'NOT_EXACT', name: 'Michael C. Vincent - Suspenseful Storyteller Clone' },
      ] }), { headers: { 'Content-Type': 'application/json' } });
    }
    if (String(url).includes('/shared-voices?')) {
      return new Response(JSON.stringify({ voices: [] }), { headers: { 'Content-Type': 'application/json' } });
    }
    throw new Error(`Unexpected mocked request: ${url}`);
  };
  const voice = await resolveTeacherVoice(true);
  assert.equal(voice.available, false);
  assert.equal(voice.voiceId, null);
  await assert.rejects(() => synthesizeSpeech({ text: 'Test' }), { code: 'VOICE_UNAVAILABLE' });
});

test('a key without Voices (read) reports the permission error rather than voice-not-found', async () => {
  globalThis.fetch = async () => new Response(JSON.stringify({
    detail: {
      type: 'authentication_error',
      code: 'unauthorized',
      message: 'The API key is missing the permission voices_read.',
    },
  }), { status: 401, headers: { 'Content-Type': 'application/json' } });

  const voice = await resolveTeacherVoice(true);
  assert.equal(voice.available, false);
  assert.equal(voice.errorCode, 'MISSING_VOICES_READ');
  assert.match(voice.message, /Voices \(read\)/);
  assert.equal(elevenLabsHealth().ready, false);
  await assert.rejects(() => synthesizeSpeech({ text: 'Math explanation' }), {
    code: 'MISSING_VOICES_READ',
  });
});