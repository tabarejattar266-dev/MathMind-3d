import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const serverDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');

async function freePort() {
  const server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const { port } = server.address();
  await new Promise((r) => server.close(r));
  return port;
}

test('compiled production server serves site, liveness, and truthful voice errors', async () => {
  const port = await freePort();
  const proc = spawn(process.execPath, ['dist/index.js'], {
    cwd: serverDir,
    env: { ...process.env, PORT: String(port), ELEVENLABS_API_KEY: '' },
    stdio: 'ignore',
  });
  const base = `http://127.0.0.1:${port}`;

  try {
    let live;
    for (let i = 0; i < 50; i++) {
      try {
        live = await fetch(`${base}/livez`);
        break;
      } catch {
        await new Promise((r) => setTimeout(r, 100));
      }
    }
    assert.ok(live, 'compiled Node server starts');
    assert.equal(live.status, 200);

    const site = await fetch(base);
    assert.equal(site.status, 200);
    assert.match(await site.text(), /id="root"/);

    const health = await fetch(`${base}/api/health`);
    assert.equal(health.status, 503);
    const state = await health.json();
    assert.equal(state.server, 'mathmind-3d-backend');
    assert.equal(state.elevenlabs.configured, false);
    assert.equal(state.elevenlabs.ready, false);
    assert.equal(state.error, 'MISSING_API_KEY');
    assert.match(state.elevenlabs.message, /backend host/i);

    const voices = await fetch(`${base}/api/voices`);
    assert.deepEqual((await voices.json()).voices, []);

    const tts = await fetch(`${base}/api/tts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: 'A maths explanation.' }),
    });
    assert.equal(tts.status, 503);
    assert.equal(tts.headers.get('content-type')?.includes('application/json'), true);
    assert.equal((await tts.json()).error, 'MISSING_API_KEY');

    const unknown = await fetch(`${base}/api/does-not-exist`);
    assert.equal(unknown.status, 404);
  } finally {
    proc.kill('SIGTERM');
  }
});