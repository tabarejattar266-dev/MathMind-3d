import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const serverDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');

async function freePort() {
  const socket = createServer();
  await new Promise((done) => socket.listen(0, '127.0.0.1', done));
  const { port } = socket.address();
  await new Promise((done) => socket.close(done));
  return port;
}

test('compiled HTTP routes select exact voice, proxy MP3 bytes and only then mark audio verified', async () => {
  const port = await freePort();
  const proc = spawn(process.execPath, ['--import', './tests/mock-provider.mjs', 'dist/index.js'], {
    cwd: serverDir,
    env: { ...process.env, PORT: String(port), ELEVENLABS_API_KEY: 'TEST_KEY_NOT_REAL' },
    stdio: 'ignore',
  });
  const base = `http://127.0.0.1:${port}`;

  try {
    let live;
    for (let i = 0; i < 50; i++) {
      try {
        live = await fetch(`${base}/livez`);
        break;
      } catch {
        await new Promise((r) => setTimeout(r, 100));
      }
    }
    assert.ok(live, 'the compiled process starts');

    const first = await fetch(`${base}/api/health`);
    const initial = await first.json();
    assert.equal(first.status, 200);
    assert.equal(initial.elevenlabs.configured, true);
    assert.equal(initial.elevenlabs.audioVerified, false);
    assert.equal(initial.elevenlabs.ready, false);

    const voices = await (await fetch(`${base}/api/voices`)).json();
    assert.equal(voices.voices[0].id, 'TEST_EXACT_ID');
    assert.equal(voices.voices[0].verifiedInAccount, true);

    const audio = await fetch(`${base}/api/tts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: 'Chalo beta, maths samajhte hain.', voiceId: 'OTHER_VOICE' }),
    });
    assert.equal(audio.status, 200);
    assert.match(audio.headers.get('content-type'), /^audio\/mpeg/);
    const bytes = Buffer.from(await audio.arrayBuffer());
    assert.equal(bytes.subarray(0, 3).toString(), 'ID3');
    assert.ok(bytes.length >= 128);

    const second = await (await fetch(`${base}/api/health`)).json();
    assert.equal(second.elevenlabs.audioVerified, true);
    assert.equal(second.elevenlabs.ready, true);
  } finally {
    proc.kill('SIGTERM');
  }
});