import { test, after } from 'node:test';
import assert from 'node:assert/strict';

// The service is the real frontend code, exercised with a minimal browser API.
globalThis.window = {
  location: { origin: 'https://mathmind.arena.example', hostname: 'mathmind.arena.example' },
  setTimeout,
  clearTimeout,
};
let audioInstance;
globalThis.Audio = class AudioMock {
  constructor() {
    audioInstance = this;
    this.src = '';
    this.paused = true;
    this.playbackRate = 1;
  }
  async play() { this.paused = false; }
  pause() { this.paused = true; }
  removeAttribute(name) { if (name === 'src') this.src = ''; }
  load() {}
};

const originalFetch = globalThis.fetch;
after(() => { globalThis.fetch = originalFetch; });

const { speechService } = await import('../../src/services/speechService.ts');

const backend = (configured, audioVerified = false, note = 'Requested voice resolved') =>
  new Response(JSON.stringify({
    ok: configured,
    server: 'mathmind-3d-backend',
    elevenlabs: { configured, audioVerified, message: note },
    note,
  }), { status: configured ? 200 : 503, headers: { 'Content-Type': 'application/json' } });

test('a deployed backend permission/configuration error is not misreported as unreachable', async () => {
  const requested = [];
  globalThis.fetch = async (url) => {
    requested.push(String(url));
    if (String(url).endsWith('/voice-config.json')) {
      return new Response(JSON.stringify({ ttsEndpoint: '' }), { headers: { 'Content-Type': 'application/json' } });
    }
    return backend(false, false, 'The server key needs Voices (read) permission.');
  };

  assert.equal(await speechService.checkBackend(true), false);
  assert.equal(speechService.getVoiceStatus().status, 'unavailable');
  assert.match(speechService.getVoiceStatus().message, /Voices \(read\)/);
  assert.ok(requested.some((url) => url.includes('mathmind.arena.example/api/health?retry=1')));
});

test('a static page instead of a backend is recognized and explained', async () => {
  globalThis.fetch = async (url) => {
    if (String(url).endsWith('/voice-config.json')) {
      return new Response(JSON.stringify({ ttsEndpoint: '' }), { headers: { 'Content-Type': 'application/json' } });
    }
    return new Response('<html>Static Arena site</html>', { headers: { 'Content-Type': 'text/html' } });
  };
  assert.equal(await speechService.checkBackend(true), false);
  assert.match(speechService.getVoiceStatus().message, /static Arena site/i);
});

test('a resolved voice allows TTS but is not called ready before actual audio', async () => {
  globalThis.fetch = async (url) => {
    if (String(url).endsWith('/voice-config.json')) {
      return new Response(JSON.stringify({ ttsEndpoint: '' }), { headers: { 'Content-Type': 'application/json' } });
    }
    return backend(true, false);
  };
  assert.equal(await speechService.checkBackend(true), true);
  assert.equal(speechService.getVoiceStatus().status, 'checking');

  globalThis.fetch = async (url) => {
    if (String(url).endsWith('/voice-config.json')) {
      return new Response(JSON.stringify({ ttsEndpoint: '' }), { headers: { 'Content-Type': 'application/json' } });
    }
    return backend(true, true);
  };
  assert.equal(await speechService.checkBackend(true), true);
  assert.equal(speechService.getVoiceStatus().status, 'ready');
});

test('frontend requests backend audio and starts playback only after Audio.play succeeds (mock)', async () => {
  let ttsRequested = false;
  globalThis.fetch = async (url, options = {}) => {
    if (String(url).endsWith('/voice-config.json')) {
      return new Response(JSON.stringify({ ttsEndpoint: '' }), { headers: { 'Content-Type': 'application/json' } });
    }
    if (String(url).includes('/api/health')) return backend(true, false);
    if (String(url).endsWith('/api/tts') && options.method === 'POST') {
      ttsRequested = true;
      assert.match(JSON.parse(options.body).text, /determinant/);
      return new Response(Buffer.concat([Buffer.from('ID3'), Buffer.alloc(320)]), {
        headers: { 'Content-Type': 'audio/mpeg' },
      });
    }
    throw new Error(`Unexpected request: ${url}`);
  };
  await speechService.checkBackend(true);
  let started = false;
  let ended = false;
  await speechService.speak('Explain the determinant.', 'english', {
    onStart: () => { started = true; },
    onEnd: () => { ended = true; },
  });
  assert.equal(ttsRequested, true);
  assert.equal(started, true);
  assert.equal(speechService.getStatus().isSpeaking, true);
  assert.equal(audioInstance.paused, false);
  audioInstance.onended();
  assert.equal(ended, true);
  assert.equal(speechService.getStatus().isSpeaking, false);
  speechService.stop();
});