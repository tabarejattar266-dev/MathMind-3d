// Test-only ElevenLabs substitute loaded in the child process. No real
// credentials, network request or paid audio generation is performed.
const realFetch = globalThis.fetch;

globalThis.fetch = async (input, init) => {
  const url = String(input);
  if (!url.startsWith('https://api.elevenlabs.io/v1/')) {
    return realFetch(input, init);
  }

  if (url.includes('/voices?')) {
    return new Response(JSON.stringify({
      voices: [
        { voice_id: 'OTHER_VOICE', name: 'Other teacher' },
        { voice_id: 'TEST_EXACT_ID', name: 'Michael C. Vincent - Suspenseful Storyteller' },
      ],
    }), { headers: { 'Content-Type': 'application/json' } });
  }

  if (url.includes('/text-to-speech/TEST_EXACT_ID?output_format=mp3_44100_128')) {
    const body = JSON.parse(init.body);
    if (body.model_id !== 'eleven_multilingual_v2') {
      return new Response(JSON.stringify({ error: 'Wrong model' }), { status: 400 });
    }
    // Sufficient for the server's response-signature test; deliberately NOT
    // a real/playable MP3 and never represented as a live-audio success.
    return new Response(Buffer.concat([Buffer.from('ID3'), Buffer.alloc(360)]), {
      headers: { 'Content-Type': 'audio/mpeg' },
    });
  }

  return new Response(JSON.stringify({ error: 'Unexpected voice request' }), { status: 400 });
};