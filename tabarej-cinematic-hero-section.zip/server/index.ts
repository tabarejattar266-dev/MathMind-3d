/**
 * MATHMIND 3D — backend server.
 *
 * This is the production Node runtime for both the built single-file Vite
 * site and its same-origin /api/tts endpoint. Deploy this process on a Node
 * host; do not deploy only dist/index.html if voice is required.
 * ELEVENLABS_API_KEY is read server-side and never sent to the browser.
 */

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  synthesizeSpeech,
  elevenLabsHealth,
  resolveTeacherVoice,
  TEACHER_VOICE_NAME,
  noteAudioFailure,
} from './services/elevenlabs.js';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const SERVER_DIR = dirname(fileURLToPath(import.meta.url));
// When compiled, this file lives in server/dist/. In dev it lives in server/.
const DIST_DIR = [resolve(SERVER_DIR, '../../dist'), resolve(SERVER_DIR, '../dist')]
  .find((candidate) => existsSync(join(candidate, 'index.html')))
  ?? resolve(SERVER_DIR, '../../dist');
const DIST_INDEX = join(DIST_DIR, 'index.html');

// Same-origin deployments need no CORS. If the static frontend is hosted
// separately, list its exact origins in FRONTEND_ORIGINS (comma separated).
const frontendOrigins = new Set([
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:4173',
  'http://localhost:3000',
  'http://localhost:8080',
  ...(process.env.FRONTEND_ORIGINS || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
]);

app.use(
  cors({
    origin(origin, callback) {
      if (!origin) return callback(null, true);
      callback(null, frontendOrigins.has(origin));
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type'],
  }),
);

app.use(express.json({ limit: '1mb' }));

/** Process liveness for hosting platforms; does not claim ElevenLabs works. */
app.get('/livez', (_req, res) => {
  res.json({ ok: true, server: 'mathmind-3d-backend' });
});

/** Voice readiness: never a 200 when the key or exact voice cannot be resolved. */
app.get('/api/health', async (req, res) => {
  try {
    const voice = await resolveTeacherVoice(req.query.retry === '1');
    const health = elevenLabsHealth();
    const statuses: Record<string, number> = {
      MISSING_API_KEY: 503,
      INVALID_API_KEY: 401,
      MISSING_VOICES_READ: 403,
      MISSING_TEXT_TO_SPEECH: 403,
      RATE_LIMITED: 429,
      VOICE_UNAVAILABLE: 503,
      VOICE_LOOKUP_FAILED: 503,
    };
    const error = voice.available
      ? health.audioStatus === 'failed' ? health.lastAudioFailureCode ?? 'TTS_FAILED' : undefined
      : voice.errorCode ?? 'VOICE_UNAVAILABLE';
    res.status(error ? statuses[error] ?? 502 : 200).set('Cache-Control', 'no-store').json({
      ok: !error,
      server: 'mathmind-3d-backend',
      ...(error ? { error } : {}),
      elevenlabs: health,
      note: health.message,
    });
  } catch (err) {
    console.error('[voice] health check failed:', err instanceof Error ? err.message : 'unknown');
    res.status(503).set('Cache-Control', 'no-store').json({
      ok: false,
      server: 'mathmind-3d-backend',
      error: 'VOICE_CHECK_FAILED',
      note: 'ElevenLabs could not be reached from the backend. Retry shortly.',
    });
  }
});

/**
 * POST /api/tts
 * Body: { text: string, speed?: number }
 * Returns: audio/mpeg
 *
 * The API key never leaves this server.
 */
app.post('/api/tts', async (req, res) => {
  const { text, speed } = req.body || {};

  if (!text || typeof text !== 'string' || !text.trim()) {
    res.status(400).json({ error: 'text is required' });
    return;
  }

  try {
    const audio = await synthesizeSpeech({
      text: text.slice(0, 5000), // safety cap
      speed: typeof speed === 'number' ? speed : undefined,
    });

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Content-Length', String(audio.byteLength));
    res.setHeader('Cache-Control', 'no-store');
    res.send(Buffer.from(audio));
  } catch (err: any) {
    const code = err?.code || 'TTS_FAILED';
    // Log a stable error code, not provider response bodies or request text.
    console.error('[tts] failed:', code);
    noteAudioFailure(code);
    const statusByCode: Record<string, number> = {
      MISSING_API_KEY: 503,
      MISSING_VOICES_READ: 403,
      MISSING_TEXT_TO_SPEECH: 403,
      INVALID_API_KEY: 401,
      VOICE_UNAVAILABLE: 503,
      RATE_LIMITED: 429,
    };
    res.status(statusByCode[code] || 502).json({
      error: code,
      message: err?.message || 'ElevenLabs request failed',
    });
  }
});

/**
 * GET /api/voices
 * Returns the requested teacher voice as resolved from the connected
 * ElevenLabs account. Empty list (with a message) when unavailable.
 */
app.get('/api/voices', async (_req, res) => {
  const info = await resolveTeacherVoice();
  res.json({
    voices: info.available
      ? [
          {
            id: info.voiceId,
            name: info.voiceName,
            source: info.source,
            verifiedInAccount: info.verifiedInAccount,
            language: 'Hindi / Hinglish / English (eleven_multilingual_v2)',
            description: 'Requested teacher voice, resolved from ElevenLabs.',
          },
        ]
      : [],
    expectedName: TEACHER_VOICE_NAME,
    message: info.message,
  });
});

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'API_NOT_FOUND', message: 'Unknown MathMind API route.' });
});

// Serve the exact Vite artifact and the API from one Node origin. This avoids
// the deployed browser accidentally calling localhost on the visitor's PC.
if (existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR, { index: false, fallthrough: true }));
}

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  if (!existsSync(DIST_INDEX)) {
    return res
      .status(503)
      .type('text/plain')
      .send('Frontend build not found. Run npm run build from the project root before starting the production server.');
  }
  return res.sendFile(DIST_INDEX);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  MATHMIND 3D backend listening on port ${PORT}`);
  console.log(`  Requested teacher voice: ${TEACHER_VOICE_NAME}`);

  // Resolve the real voice ID from the connected ElevenLabs account.
  resolveTeacherVoice()
    .then((info) => {
      if (info.available) {
        console.log(`  ElevenLabs: configured ✓`);
        console.log(
          `  Teacher voice resolved (${info.source}): "${info.voiceName}" [${info.voiceId}]`,
        );
        console.log(
          info.verifiedInAccount
            ? '  Verified in your account voice list ✓\n'
            : '  Note: resolved from the shared voice library, not your account list.\n',
        );
      } else {
        console.log('  ElevenLabs: NOT ready');
        console.log(`  Teacher voice unavailable: ${info.message}\n`);
      }
    })
    .catch((err) => {
      console.log(`  Teacher voice resolution failed: ${err?.message || err}\n`);
    });
});
