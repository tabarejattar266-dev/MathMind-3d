import React from 'react';
import {
  Sparkles,
  TrendingUp,
  Settings,
  Languages,
  Upload,
} from 'lucide-react';
import { Language, LearningMode } from '../types/math';
import { progressService } from '../services/progressService';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  learningMode: LearningMode;
  onModeChange: (mode: LearningMode) => void;
  onOpenUpload: () => void;
  onOpenDashboard: () => void;
  onOpenApiSettings: () => void;
  isInClassroom?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  learningMode,
  onModeChange,
  onOpenUpload,
  onOpenDashboard,
  onOpenApiSettings,
  isInClassroom = false,
}) => {
  const progress = progressService.getProgress();

  const learningModes: { id: LearningMode; label: string }[] = [
    { id: 'teacher', label: 'Teacher Mode' },
    { id: 'visual', label: 'Visual 3D' },
    { id: 'beginner', label: 'Beginner' },
    { id: 'hint', label: 'Hint Mode' },
    { id: 'quick', label: 'Quick Revision' },
    { id: 'practice', label: 'Practice' },
  ];

  return (
    <nav className="w-full bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 sticky top-0 z-40 px-4 sm:px-6 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 flex items-center justify-center text-white shadow-[0_0_20px_rgba(56,189,248,0.35)] shrink-0">
            <Sparkles size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base sm:text-lg tracking-tight text-white font-mono">
                MATHMIND<span className="text-cyan-400">3D</span>
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30 hidden sm:inline">
                AI Teacher
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden md:block">
              Maths Samajhna Ab Hoga Easy
            </p>
          </div>
        </div>

        {/* Center: Learning Mode Selector (hidden on mobile) */}
        {!isInClassroom && (
          <div className="hidden lg:flex items-center bg-slate-900/90 rounded-xl border border-slate-800 p-1 gap-1">
            {learningModes.map((m) => (
              <button
                key={m.id}
                onClick={() => onModeChange(m.id)}
                className={`text-xs px-2.5 py-1 rounded-lg transition-all ${
                  learningMode === m.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        )}

        {/* Right Action Bar */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Switcher */}
          <div className="flex items-center bg-slate-900 rounded-xl border border-slate-800 p-1">
            <Languages size={14} className="text-cyan-400 ml-1.5 mr-1 hidden sm:inline" />
            {(['hinglish', 'hindi', 'english'] as const).map((l) => (
              <button
                key={l}
                onClick={() => onLanguageChange(l)}
                className={`text-[11px] px-2 py-0.5 rounded-lg capitalize font-medium transition-colors ${
                  language === l
                    ? 'bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {l === 'hinglish' ? 'Hinglish' : l === 'hindi' ? 'हिंदी' : 'Eng'}
              </button>
            ))}
          </div>

          {/* Student Progress Badge */}
          <button
            type="button"
            onClick={onOpenDashboard}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
            title="Open Student Dashboard"
          >
            <TrendingUp size={14} className="text-emerald-400" />
            <span className="font-mono text-emerald-300 font-bold">{progress.streakDays}d</span>
          </button>

          {/* API Settings */}
          <button
            type="button"
            onClick={onOpenApiSettings}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Configure Vision AI Keys"
          >
            <Settings size={15} />
          </button>

          {/* Upload Button */}
          <button
            type="button"
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all"
          >
            <Upload size={14} />
            <span className="hidden sm:inline">Ask Question</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
