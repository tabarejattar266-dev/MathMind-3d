import React, { useState } from 'react';
import { AlertCircle, CheckCircle, Edit3, ArrowRight } from 'lucide-react';
import MathView from '../MathView';
import { VisionAnalysisResult } from '../../services/aiTeacherService';

interface ClarificationDialogProps {
  analysis: VisionAnalysisResult;
  onConfirm: (finalText: string, finalLatex: string) => void;
  onCancel: () => void;
}

export const ClarificationDialog: React.FC<ClarificationDialogProps> = ({
  analysis,
  onConfirm,
  onCancel,
}) => {
  const [isEditing, setIsEditing] = useState(analysis.isAmbiguous);
  const [text, setText] = useState(analysis.detectedText);
  const [latex, setLatex] = useState(analysis.latexExpression);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center gap-3">
          {analysis.isAmbiguous ? (
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <AlertCircle size={22} />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <CheckCircle size={22} />
            </div>
          )}
          <div>
            <h3 className="text-base font-bold text-white">
              {analysis.isAmbiguous ? 'Clarification Required' : 'Confirm Recognized Mathematics'}
            </h3>
            <p className="text-xs text-slate-400">
              {analysis.isAmbiguous
                ? 'The image may be blurry or handwritten ambiguously. Please verify the formula.'
                : 'Our AI teacher extracted the following question. Confirm or edit before starting.'}
            </p>
          </div>
        </div>

        {analysis.ambiguityReason && (
          <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-500/30 text-amber-200 text-xs">
            ⚠️ {analysis.ambiguityReason}
          </div>
        )}

        {/* Math Preview or Edit Fields */}
        {!isEditing ? (
          <div className="space-y-3">
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-mono block mb-1">
                Detected Question:
              </span>
              <p className="text-sm text-slate-200 font-medium">{text}</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/90 border border-cyan-500/30 text-center">
              <span className="text-[10px] text-cyan-400 uppercase font-mono block mb-2">
                Recognized Formula (LaTeX):
              </span>
              <MathView math={latex} displayMode={true} className="text-xl" />
            </div>

            <div className="flex justify-between items-center text-xs text-slate-400">
              <span>Topic: <strong className="text-cyan-300">{analysis.topic}</strong></span>
              <span>Confidence: <strong className="text-emerald-400">{Math.round(analysis.confidence * 100)}%</strong></span>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-300 block mb-1">Question Description:</label>
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
              />
            </div>
            <div>
              <label className="text-xs text-slate-300 block mb-1">LaTeX Mathematical Expression:</label>
              <textarea
                rows={3}
                value={latex}
                onChange={(e) => setLatex(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono"
              />
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <MathView math={latex} displayMode={true} className="text-base" />
            </div>
          </div>
        )}

        {/* Buttons */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <Edit3 size={14} />
            {isEditing ? 'View Rendered Preview' : 'Edit Equation Manually'}
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!latex.trim()}
              title={!latex.trim() ? 'Type the question first — the teacher never guesses unreadable values.' : ''}
              onClick={() => onConfirm(text, latex)}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-40 disabled:pointer-events-none"
            >
              <span>{latex.trim() ? 'Confirm & Start Lesson' : 'Type the question to continue'}</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClarificationDialog;
