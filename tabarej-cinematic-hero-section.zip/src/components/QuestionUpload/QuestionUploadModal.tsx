import React, { useState, useRef } from 'react';
import {
  Upload,
  Camera,
  RotateCw,
  Trash2,
  Sparkles,
  BookOpen,
  X,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { Lesson } from '../../types/math';
import { SAMPLE_LESSONS } from '../../data/sampleLessons';
import MathFormulaInput from './MathFormulaInput';
import ClarificationDialog from './ClarificationDialog';
import { aiTeacherService, VisionAnalysisResult } from '../../services/aiTeacherService';

interface QuestionUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLesson: (lesson: Lesson) => void;
}

export const QuestionUploadModal: React.FC<QuestionUploadModalProps> = ({
  isOpen,
  onClose,
  onSelectLesson,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'formula' | 'samples'>('upload');

  // Image Upload state
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [rotationDeg, setRotationDeg] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [clarificationData, setClarificationData] = useState<VisionAnalysisResult | null>(null);

  // Manual Formula state
  const [manualTitle, setManualTitle] = useState('Find the value of the 3x3 determinant');
  const [manualLatex, setManualLatex] = useState(
    '\\Delta = \\begin{vmatrix} 2 & 3 & 1 \\\\ 1 & 0 & -1 \\\\ 4 & -2 & 3 \\end{vmatrix}',
  );

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  if (!isOpen) return null;

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (PNG, JPG, JPEG).');
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const rotateImage = () => {
    setRotationDeg((prev) => (prev + 90) % 360);
  };

  const removeImage = () => {
    setImageFile(null);
    setPreviewUrl(null);
    setRotationDeg(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Camera start/capture
  const startCamera = async () => {
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn('Camera error:', err);
      alert('Camera access not supported or permission denied. Please upload a photo from your device.');
      setCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg');
      setPreviewUrl(dataUrl);

      // Stop camera stream
      const stream = videoRef.current.srcObject as MediaStream;
      stream?.getTracks().forEach((track) => track.stop());
      setCameraActive(false);
    }
  };

  // Submit image for OCR/Vision
  const handleAnalyzePhoto = async () => {
    if (!previewUrl) return;
    setIsProcessing(true);
    try {
      const result = await aiTeacherService.analyzeQuestionImage(
        previewUrl,
        imageFile?.name || 'question_photo.jpg'
      );
      setIsProcessing(false);
      setClarificationData(result);
    } catch (err) {
      setIsProcessing(false);
      alert('Failed to analyze question. Please try again or use manual equation input.');
    }
  };

  // Handle confirmation from ClarificationDialog
  const handleConfirmQuestion = (finalText: string, finalLatex: string) => {
    if (clarificationData?.lesson) {
      onSelectLesson(clarificationData.lesson);
    } else {
      const generated = aiTeacherService.generateLessonFromText(finalText, finalLatex);
      onSelectLesson(generated);
    }
    setClarificationData(null);
    onClose();
  };

  // Submit manual formula
  const handleStartManualLesson = () => {
    const generated = aiTeacherService.generateLessonFromText(manualTitle, manualLatex);
    onSelectLesson(generated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700/80 shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles size={18} className="text-cyan-400" />
              Upload Maths Question & Start Learning
            </h2>
            <p className="text-xs text-slate-400">
              Snap a photo, paste LaTeX, or try an interactive sample lesson.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/30 px-5 pt-3 gap-2">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition-all border-b-2 ${
              activeTab === 'upload'
                ? 'border-cyan-400 text-cyan-300 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload size={14} />
            Photo Upload / Camera
          </button>

          <button
            onClick={() => setActiveTab('formula')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition-all border-b-2 ${
              activeTab === 'formula'
                ? 'border-cyan-400 text-cyan-300 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText size={14} />
            Type Equation / LaTeX
          </button>

          <button
            onClick={() => setActiveTab('samples')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition-all border-b-2 ${
              activeTab === 'samples'
                ? 'border-cyan-400 text-cyan-300 bg-slate-850'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen size={14} />
            Sample Lessons Library (6)
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'upload' && (
            <div className="space-y-4">
              {!previewUrl && !cameraActive && (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all flex flex-col items-center justify-center gap-3 cursor-pointer ${
                    isDragging
                      ? 'border-cyan-400 bg-cyan-950/20 shadow-[0_0_20px_rgba(56,189,248,0.2)]'
                      : 'border-slate-700 bg-slate-950/40 hover:border-cyan-500/50'
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png, image/jpeg, image/jpg"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                  />

                  <div className="w-14 h-14 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Upload size={24} />
                  </div>

                  <div>
                    <p className="text-sm font-semibold text-slate-200">
                      Click to upload photo or drag & drop
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Supports PNG, JPG, JPEG (Printed textbooks or clear handwriting)
                    </p>
                  </div>

                  <div className="flex items-center gap-2 mt-2">
                    <span className="h-px w-10 bg-slate-700" />
                    <span className="text-[11px] text-slate-500 uppercase">OR</span>
                    <span className="h-px w-10 bg-slate-700" />
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      startCamera();
                    }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-600 transition-colors"
                  >
                    <Camera size={14} className="text-cyan-400" />
                    Take Photo with Camera
                  </button>
                </div>
              )}

              {/* Active Camera View */}
              {cameraActive && (
                <div className="space-y-3">
                  <div className="relative rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                  </div>
                  <div className="flex justify-center gap-3">
                    <button
                      onClick={capturePhoto}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20"
                    >
                      Capture Photo
                    </button>
                    <button
                      onClick={() => setCameraActive(false)}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* Image Preview with Crop/Rotate/Delete */}
              {previewUrl && (
                <div className="space-y-4">
                  <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-700 p-2 flex items-center justify-center min-h-[220px]">
                    <img
                      src={previewUrl}
                      alt="Question Preview"
                      style={{ transform: `rotate(${rotationDeg}deg)` }}
                      className="max-h-64 object-contain rounded-lg transition-transform duration-200"
                    />

                    {/* Image Controls toolbar */}
                    <div className="absolute top-4 right-4 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700">
                      <button
                        onClick={rotateImage}
                        title="Rotate 90 degrees"
                        className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
                      >
                        <RotateCw size={15} />
                      </button>
                      <button
                        onClick={removeImage}
                        title="Remove image"
                        className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/50"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>

                  {/* Recognition notice */}
                  <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center gap-2 text-xs text-cyan-200">
                    <Sparkles size={16} className="text-cyan-400 shrink-0" />
                    <span>
                      Our AI will recognize handwriting, printed matrices, algebraic equations, or word problems.
                    </span>
                  </div>

                  <button
                    onClick={handleAnalyzePhoto}
                    disabled={isProcessing}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-sm shadow-xl shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Analyzing Mathematics & Generating Lesson...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={16} />
                        <span>Extract Question & Teach Me (3D + Voice)</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'formula' && (
            <div className="space-y-4">
              <MathFormulaInput
                value={manualLatex}
                onChange={setManualLatex}
                questionTitle={manualTitle}
                onQuestionTitleChange={setManualTitle}
              />

              <button
                onClick={handleStartManualLesson}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-sm shadow-xl shadow-cyan-500/25 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles size={16} />
                <span>Start AI Interactive Lesson</span>
              </button>
            </div>
          )}

          {activeTab === 'samples' && (
            <div className="space-y-3">
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300">
                ✨ Click any sample lesson to load full 3D interactive animations, voice explanations, and practice questions immediately without uploading!
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SAMPLE_LESSONS.map((sample) => (
                  <div
                    key={sample.id}
                    onClick={() => {
                      onSelectLesson(sample);
                      onClose();
                    }}
                    className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-cyan-500/60 hover:bg-slate-800/60 transition-all cursor-pointer group space-y-2 shadow-lg"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/30 text-cyan-300">
                        {sample.topic}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {sample.steps.length} Steps
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {sample.title}
                    </h4>

                    <p className="text-xs text-slate-400 line-clamp-1">
                      {sample.originalQuestion}
                    </p>

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-cyan-400 font-medium">
                      <span>3D Animation Ready</span>
                      <span className="group-hover:translate-x-1 transition-transform">Start →</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="p-3 px-6 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <AlertCircle size={13} className="text-cyan-400" />
            AI verifies every arithmetic calculation independently before teaching.
          </span>
          <span className="text-slate-500">MATHMIND 3D v2.4</span>
        </div>
      </div>

      {/* Clarification Dialog if AI detected ambiguous formula */}
      {clarificationData && (
        <ClarificationDialog
          analysis={clarificationData}
          onConfirm={handleConfirmQuestion}
          onCancel={() => setClarificationData(null)}
        />
      )}
    </div>
  );
};

export default QuestionUploadModal;
