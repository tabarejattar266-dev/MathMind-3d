import React from 'react';
import MathView from '../MathView';

interface MathFormulaInputProps {
  value: string;
  onChange: (val: string) => void;
  questionTitle: string;
  onQuestionTitleChange: (val: string) => void;
}

export const MathFormulaInput: React.FC<MathFormulaInputProps> = ({
  value,
  onChange,
  questionTitle,
  onQuestionTitleChange,
}) => {
  const quickSymbols = [
    { label: '|2x2|', latex: '\\begin{vmatrix} 2 & 3 \\\\ 1 & 5 \\end{vmatrix}', title: '2x2 Determinant' },
    { label: '|3x3|', latex: '\\begin{vmatrix} 1 & 2 & 3 \\\\ 0 & 4 & 5 \\\\ 1 & 0 & 6 \\end{vmatrix}', title: '3x3 Determinant' },
    { label: 'x²', latex: 'x^2 - 5x + 6 = 0', title: 'Quadratic Equation' },
    { label: '√x', latex: '\\sqrt{x^2 + y^2}', title: 'Square Root' },
    { label: 'a/b', latex: '\\frac{a}{b}', title: 'Fraction' },
    { label: 'sin θ', latex: '\\sin(30^\\circ) = \\frac{1}{2}', title: 'Sine Function' },
    { label: 'df/dx', latex: '\\lim_{h \\to 0} \\frac{f(x+h)-f(x)}{h}', title: 'Derivative' },
    { label: '∫ dx', latex: '\\int_{0}^{1} x^2 \\, dx', title: 'Integral' },
    { label: 'π r² h', latex: 'V = \\pi r^2 h', title: 'Cylinder Volume' },
    { label: '2x + 5 = 15', latex: '2x + 5 = 15', title: 'Linear Equation' },
  ];

  const handleInsert = (latex: string) => {
    onChange(latex);
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-1">
          Problem Description / Question Prompt:
        </label>
        <input
          type="text"
          value={questionTitle}
          onChange={(e) => onQuestionTitleChange(e.target.value)}
          placeholder="e.g. Find the determinant of matrix or Solve for x"
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 placeholder:text-slate-500"
        />
      </div>

      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="block text-xs font-medium text-slate-300">
            Mathematical Expression (LaTeX or Formula):
          </label>
          <span className="text-[11px] text-cyan-400 font-mono">KaTeX Supported</span>
        </div>

        <textarea
          rows={3}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="e.g. \Delta = \begin{vmatrix} 2 & 3 \\ 1 & 5 \end{vmatrix}"
          className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 placeholder:text-slate-600 resize-none"
        />
      </div>

      {/* Quick symbol insertion pills */}
      <div>
        <span className="text-[11px] text-slate-400 block mb-1.5">Quick Insert Formulas:</span>
        <div className="flex flex-wrap gap-1.5">
          {quickSymbols.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => handleInsert(item.latex)}
              className="px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700/80 text-xs font-mono text-cyan-300 hover:bg-cyan-950/80 hover:border-cyan-500 transition-colors"
              title={item.title}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Real-time KaTeX Live Preview */}
      <div className="p-3.5 rounded-xl bg-slate-950/80 border border-cyan-500/20">
        <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
          Live Rendered Math Preview:
        </span>
        <div className="min-h-[44px] flex items-center justify-center text-center">
          {value ? (
            <MathView math={value} displayMode={true} className="text-lg" />
          ) : (
            <span className="text-xs text-slate-500 italic">
              Formula will preview here in real time...
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default MathFormulaInput;
