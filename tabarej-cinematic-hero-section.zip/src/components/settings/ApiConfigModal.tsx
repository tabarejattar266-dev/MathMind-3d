import React, { useState } from 'react';
import { Key, ShieldCheck, AlertCircle, X, ExternalLink, Check } from 'lucide-react';
import { ApiSettings } from '../../types/math';
import { aiTeacherService } from '../../services/aiTeacherService';

interface ApiConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiConfigModal: React.FC<ApiConfigModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [settings, setSettings] = useState<ApiSettings>(aiTeacherService.getSettings());
  const [keyInput, setKeyInput] = useState(settings.apiKey || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    const updated: ApiSettings = {
      ...settings,
      apiKey: keyInput.trim(),
      isConfigured: keyInput.trim().length > 10,
    };
    aiTeacherService.saveSettings(updated);
    setSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Key size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">AI Engine & Vision Configuration</h3>
              <p className="text-[11px] text-slate-400">
                Setup optional custom Vision model keys or use our built-in offline engine.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Built-in Engine Status Banner */}
          <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-start gap-2.5 text-xs text-cyan-200">
            <ShieldCheck size={18} className="text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block mb-0.5">Built-in Offline Engine Active</strong>
              <span>
                MATHMIND 3D contains fully verified offline lessons for Determinants, Trigonometry, Calculus, 3D Geometry, and Algebra. No API key is required to use all features!
              </span>
            </div>
          </div>

          {/* Provider selection */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 block">External Vision AI Provider:</label>
            <div className="grid grid-cols-3 gap-2">
              {(['builtin', 'openai', 'anthropic'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setSettings({ ...settings, provider: p })}
                  className={`p-2.5 rounded-xl border text-xs font-semibold capitalize transition-all ${
                    settings.provider === p
                      ? 'bg-cyan-600 border-cyan-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p === 'builtin' ? 'Built-in (Offline)' : p}
                </button>
              ))}
            </div>
          </div>

          {settings.provider !== 'builtin' && (
            <div className="space-y-2">
              <label className="text-xs text-slate-300 block">
                {settings.provider.toUpperCase()} API Key:
              </label>
              <input
                type="password"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder={`Paste your ${settings.provider} API key (sk-...)`}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
              />
              <p className="text-[11px] text-slate-400 flex items-center gap-1">
                <AlertCircle size={13} className="text-amber-400" />
                Keys are stored only in your browser localStorage and are never sent to external servers.
              </p>
            </div>
          )}

          {/* Env Instructions */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
            <div className="text-white font-medium flex items-center justify-between">
              <span>Server-Side Deployment:</span>
              <span className="text-[10px] text-cyan-400 font-mono">.env.example created</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              For production servers, configure credentials in server-side environment variables (`OPENAI_API_KEY`) as documented in `.env.example`.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <a
            href="https://platform.openai.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
          >
            <span>Get an API Key</span>
            <ExternalLink size={12} />
          </a>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 font-medium"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <Check size={14} />
                  <span>Saved!</span>
                </>
              ) : (
                <span>Save Settings</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiConfigModal;
