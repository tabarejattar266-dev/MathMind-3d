import React from 'react';
import MathView from '../MathView';
import { Lesson, SolutionStep } from '../../types/math';

interface Fallback2DDiagramProps {
  lesson: Lesson;
  currentStep: SolutionStep;
}

export const Fallback2DDiagram: React.FC<Fallback2DDiagramProps> = ({
  lesson,
  currentStep,
}) => {
  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-4 select-none">
      <div className="w-full flex items-center justify-between mb-3 px-2">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
          Visual Equation Step Diagram
        </span>
        <span className="text-xs text-slate-400">Step {currentStep.stepNumber}</span>
      </div>

      <div className="w-full max-w-lg bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl flex flex-col items-center text-center space-y-4">
        <div className="text-xs font-mono text-cyan-300 uppercase tracking-widest">
          {currentStep.operation}
        </div>

        {/* Large Equation Focus with Glow */}
        <div className="p-4 rounded-xl bg-slate-950/90 border border-cyan-500/30 w-full shadow-[0_0_20px_rgba(56,189,248,0.1)]">
          <MathView math={currentStep.equation} displayMode={true} className="text-xl sm:text-2xl" />
        </div>

        {/* Rule or Theorem Badge */}
        <div className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
          <span className="text-slate-400">Rule Applied:</span>
          <span className="font-mono text-emerald-300 font-semibold">{currentStep.ruleUsed}</span>
        </div>

        {/* Conceptual rationale */}
        <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/50 p-3 rounded-lg border border-slate-800/80">
          💡 <span className="font-semibold text-white">Why this step works:</span> {currentStep.whyNecessary}
        </p>

        {/* Topic Context */}
        <div className="flex items-center gap-2 text-[11px] text-slate-500">
          <span>Topic: {lesson.topic}</span>
          <span>•</span>
          <span>{lesson.subtopic}</span>
        </div>
      </div>
    </div>
  );
};

export default Fallback2DDiagram;
