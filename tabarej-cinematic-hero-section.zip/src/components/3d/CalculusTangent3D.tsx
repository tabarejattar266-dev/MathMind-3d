import React, { useState } from 'react';
import { VisualHighlight } from '../../types/math';

interface CalculusTangent3DProps {
  xTarget?: number;
  highlight?: VisualHighlight;
}

export const CalculusTangent3D: React.FC<CalculusTangent3DProps> = ({
  xTarget = 2,
  highlight,
}) => {
  const [h, setH] = useState<number>(highlight?.deltaX !== undefined ? highlight.deltaX : 1.5);

  const pX = xTarget;
  const pY = pX * pX; // f(2) = 4

  const qX = pX + h;
  const qY = qX * qX; // f(2+h)

  const deltaY = qY - pY;
  const secantSlope = h !== 0 ? deltaY / h : 4;
  const isTangent = Math.abs(h) <= 0.05;

  // Viewport mapping for SVG: x from 0 to 4.5, y from 0 to 16
  const scaleX = 60;
  const scaleY = 16;
  const originX = 40;
  const originY = 260;

  const toSvgX = (x: number) => originX + x * scaleX;
  const toSvgY = (y: number) => originY - y * scaleY;

  // Generate curve path for f(x) = x^2
  const points: string[] = [];
  for (let x = 0; x <= 4.2; x += 0.1) {
    const y = x * x;
    points.push(`${toSvgX(x)},${toSvgY(y)}`);
  }
  const curvePath = `M ${points.join(' L ')}`;

  // Line endpoints through P and Q extended
  const lineX1 = pX - 1.2;
  const lineY1 = pY - 1.2 * secantSlope;
  const lineX2 = qX + 1.2;
  const lineY2 = qY + 1.2 * secantSlope;

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-3 select-none">
      <div className="w-full flex items-center justify-between mb-2 px-2">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
          Calculus: Limit of Secant Slopes (h → 0)
        </span>
        <span
          className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
            isTangent
              ? 'bg-violet-900/80 border-violet-400 text-violet-200 shadow-[0_0_12px_rgba(168,85,247,0.5)]'
              : 'bg-amber-900/80 border-amber-400 text-amber-200'
          }`}
        >
          {isTangent ? 'Tangent Line Locked (h ≈ 0)' : `Secant Line (h = ${h.toFixed(2)})`}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl items-center">
        {/* SVG Curve Plot */}
        <div className="relative flex items-center justify-center bg-slate-950/90 p-3 rounded-2xl border border-slate-800">
          <svg viewBox="0 0 320 280" className="w-64 h-56 sm:w-72 sm:h-64">
            {/* Grid & Axes */}
            <line x1={originX} y1="20" x2={originX} y2={originY + 10} stroke="#334155" strokeWidth="1.5" />
            <line x1={originX - 10} y1={originY} x2="310" y2={originY} stroke="#334155" strokeWidth="1.5" />

            {/* Labels */}
            <text x="305" y={originY - 8} fill="#64748b" fontSize="10" fontFamily="monospace">x</text>
            <text x={originX + 8} y="25" fill="#64748b" fontSize="10" fontFamily="monospace">f(x) = x²</text>

            {/* Ticks on X axis */}
            {[1, 2, 3, 4].map((tick) => (
              <g key={tick}>
                <line
                  x1={toSvgX(tick)}
                  y1={originY - 3}
                  x2={toSvgX(tick)}
                  y2={originY + 3}
                  stroke="#475569"
                />
                <text
                  x={toSvgX(tick) - 4}
                  y={originY + 14}
                  fill="#94a3b8"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  {tick}
                </text>
              </g>
            ))}

            {/* Parabola Curve f(x) = x² */}
            <path
              d={curvePath}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2.5"
              className="drop-shadow-[0_0_8px_rgba(56,189,248,0.4)]"
            />

            {/* Secant / Tangent line */}
            <line
              x1={toSvgX(lineX1)}
              y1={toSvgY(lineY1)}
              x2={toSvgX(lineX2)}
              y2={toSvgY(lineY2)}
              stroke={isTangent ? '#a855f7' : '#f59e0b'}
              strokeWidth={isTangent ? '3' : '2'}
              strokeDasharray={isTangent ? 'none' : '4 3'}
              className="drop-shadow-[0_0_8px_rgba(168,85,247,0.7)]"
            />

            {/* Delta X (horizontal dashed line) */}
            {!isTangent && (
              <line
                x1={toSvgX(pX)}
                y1={toSvgY(pY)}
                x2={toSvgX(qX)}
                y2={toSvgY(pY)}
                stroke="#64748b"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
            )}

            {/* Delta Y (vertical dashed line) */}
            {!isTangent && (
              <line
                x1={toSvgX(qX)}
                y1={toSvgY(pY)}
                x2={toSvgX(qX)}
                y2={toSvgY(qY)}
                stroke="#64748b"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
            )}

            {/* Target Point P(2, 4) */}
            <circle
              cx={toSvgX(pX)}
              cy={toSvgY(pY)}
              r="6"
              fill="#38bdf8"
              stroke="#ffffff"
              strokeWidth="2"
            />
            <text
              x={toSvgX(pX) - 45}
              y={toSvgY(pY) - 8}
              fill="#38bdf8"
              fontSize="9"
              fontFamily="monospace"
              fontWeight="bold"
            >
              P(2, 4)
            </text>

            {/* Approaching Point Q(2+h, f(2+h)) */}
            {!isTangent && (
              <>
                <circle
                  cx={toSvgX(qX)}
                  cy={toSvgY(qY)}
                  r="5"
                  fill="#f59e0b"
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
                <text
                  x={toSvgX(qX) + 8}
                  y={toSvgY(qY) + 4}
                  fill="#f59e0b"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  Q({qX.toFixed(2)}, {qY.toFixed(1)})
                </text>
              </>
            )}
          </svg>
        </div>

        {/* Math & Slider Controls */}
        <div className="space-y-3">
          <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="text-[11px] font-mono text-cyan-400">Slope Formula:</div>
            <div className="text-xs text-slate-300 font-mono">
              m = \frac{'{'}Δy{'}'}{'{'}Δx{'}'} = \frac{'{'}(2+h)² - 4{'}'}{'{'}h{'}'} = \frac{'{'}4h + h²{'}'}{'{'}h{'}'} = 4 + h
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
              <span className="text-xs text-slate-400">Current Slope (m):</span>
              <span
                className={`text-base font-bold font-mono ${
                  isTangent ? 'text-violet-300 text-lg' : 'text-amber-300'
                }`}
              >
                {secantSlope.toFixed(3)}
              </span>
            </div>
          </div>

          {/* Shrink h Interactive Slider */}
          <div className="space-y-2 bg-slate-900/70 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Shrink Distance (h → 0):</span>
              <span className="font-mono text-cyan-400 font-bold">h = {h.toFixed(2)}</span>
            </div>

            <input
              type="range"
              min="0.02"
              max="2.0"
              step="0.02"
              value={h}
              onChange={(e) => setH(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
            />

            <div className="flex gap-2 mt-1">
              <button
                onClick={() => setH(2.0)}
                className="flex-1 text-[11px] py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                h = 2.0 (Wide)
              </button>
              <button
                onClick={() => setH(0.5)}
                className="flex-1 text-[11px] py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                h = 0.5 (Close)
              </button>
              <button
                onClick={() => setH(0.02)}
                className="flex-1 text-[11px] py-1 rounded bg-violet-900/80 text-violet-200 border border-violet-500/50 hover:bg-violet-800 font-bold"
              >
                h → 0 (Tangent!)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalculusTangent3D;
