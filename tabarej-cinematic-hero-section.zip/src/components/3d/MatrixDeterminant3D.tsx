import React, { useState } from 'react';
import { VisualHighlight } from '../../types/math';

interface MatrixDeterminant3DProps {
  matrix?: number[][];
  highlight?: VisualHighlight;
  currentStepIndex?: number;
}

export const MatrixDeterminant3D: React.FC<MatrixDeterminant3DProps> = ({
  matrix = [
    [2, 3],
    [1, 5],
  ],
  highlight,
  currentStepIndex = 0,
}) => {
  const [showGeometricArea, setShowGeometricArea] = useState(false);
  const [customMatrix, setCustomMatrix] = useState<number[][]>(matrix);

  React.useEffect(() => {
    if (matrix && matrix.length >= 2) {
      setCustomMatrix(matrix);
    }
  }, [matrix]);

  const a = customMatrix[0][0];
  const b = customMatrix[0][1];
  const c = customMatrix[1][0];
  const d = customMatrix[1][1];

  const primaryProduct = a * d;
  const secondaryProduct = b * c;
  const detValue = primaryProduct - secondaryProduct;

  const activeHighlight = highlight?.highlightDiagonals;

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-4 select-none">
      {/* Top visual controls */}
      <div className="w-full flex items-center justify-between mb-4 px-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
            2×2 Determinant Visualizer
          </span>
          <span className="text-xs text-slate-400">
            Step {currentStepIndex + 1} of 4
          </span>
        </div>

        <button
          onClick={() => setShowGeometricArea(!showGeometricArea)}
          className={`text-xs px-3 py-1 rounded-full border transition-all ${
            showGeometricArea
              ? 'bg-violet-600 border-violet-400 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
              : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:border-violet-500/50'
          }`}
        >
          {showGeometricArea ? 'Show Matrix Grid' : 'Show 2D Area (Parallelogram)'}
        </button>
      </div>

      {!showGeometricArea ? (
        /* Matrix Grid View with Glowing Diagonals */
        <div className="relative flex flex-col items-center justify-center w-full max-w-md py-6">
          {/* Main Matrix Box with Bracket Bars */}
          <div className="relative flex items-center justify-center gap-6 px-8 py-8 rounded-2xl bg-slate-900/80 border border-slate-700/60 shadow-[0_0_30px_rgba(0,0,0,0.5)]">
            {/* Left Vertical Determinant Bar | */}
            <div className="w-1.5 h-44 bg-gradient-to-b from-cyan-400 via-blue-500 to-cyan-400 rounded-full shadow-[0_0_12px_rgba(56,189,248,0.5)]" />

            {/* Matrix 2x2 Grid */}
            <div className="relative grid grid-cols-2 gap-6 w-48 h-44">
              {/* SVG Overlay for Diagonal Arrows & Connecting Lines */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10 overflow-visible">
                {/* Primary diagonal arrow (a -> d) */}
                {(activeHighlight === 'primary' || activeHighlight === 'both' || currentStepIndex === 1) && (
                  <g className="animate-pulse">
                    <line
                      x1="25%"
                      y1="25%"
                      x2="75%"
                      y2="75%"
                      stroke="#10b981"
                      strokeWidth="3.5"
                      strokeDasharray="6 4"
                      className="drop-shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                    />
                    <circle cx="25%" cy="25%" r="7" fill="#10b981" />
                    <circle cx="75%" cy="75%" r="7" fill="#10b981" />
                  </g>
                )}

                {/* Secondary diagonal arrow (b -> c) */}
                {(activeHighlight === 'secondary' || activeHighlight === 'both' || currentStepIndex === 2) && (
                  <g className="animate-pulse">
                    <line
                      x1="75%"
                      y1="25%"
                      x2="25%"
                      y2="75%"
                      stroke="#f59e0b"
                      strokeWidth="3.5"
                      strokeDasharray="6 4"
                      className="drop-shadow-[0_0_8px_rgba(245,158,11,0.8)]"
                    />
                    <circle cx="75%" cy="25%" r="7" fill="#f59e0b" />
                    <circle cx="25%" cy="75%" r="7" fill="#f59e0b" />
                  </g>
                )}
              </svg>

              {/* Cell a (top-left) */}
              <div
                className={`flex flex-col items-center justify-center rounded-xl p-3 border transition-all duration-300 ${
                  activeHighlight === 'primary' || activeHighlight === 'both' || currentStepIndex === 1
                    ? 'bg-emerald-950/70 border-emerald-400 text-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.4)] scale-105'
                    : 'bg-slate-800/60 border-slate-700 text-white'
                }`}
              >
                <span className="text-[10px] text-slate-400 font-mono">a (r1, c1)</span>
                <span className="text-2xl font-bold font-mono">{a}</span>
              </div>

              {/* Cell b (top-right) */}
              <div
                className={`flex flex-col items-center justify-center rounded-xl p-3 border transition-all duration-300 ${
                  activeHighlight === 'secondary' || activeHighlight === 'both' || currentStepIndex === 2
                    ? 'bg-amber-950/70 border-amber-400 text-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.4)] scale-105'
                    : 'bg-slate-800/60 border-slate-700 text-white'
                }`}
              >
                <span className="text-[10px] text-slate-400 font-mono">b (r1, c2)</span>
                <span className="text-2xl font-bold font-mono">{b}</span>
              </div>

              {/* Cell c (bottom-left) */}
              <div
                className={`flex flex-col items-center justify-center rounded-xl p-3 border transition-all duration-300 ${
                  activeHighlight === 'secondary' || activeHighlight === 'both' || currentStepIndex === 2
                    ? 'bg-amber-950/70 border-amber-400 text-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.4)] scale-105'
                    : 'bg-slate-800/60 border-slate-700 text-white'
                }`}
              >
                <span className="text-[10px] text-slate-400 font-mono">c (r2, c1)</span>
                <span className="text-2xl font-bold font-mono">{c}</span>
              </div>

              {/* Cell d (bottom-right) */}
              <div
                className={`flex flex-col items-center justify-center rounded-xl p-3 border transition-all duration-300 ${
                  activeHighlight === 'primary' || activeHighlight === 'both' || currentStepIndex === 1
                    ? 'bg-emerald-950/70 border-emerald-400 text-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.4)] scale-105'
                    : 'bg-slate-800/60 border-slate-700 text-white'
                }`}
              >
                <span className="text-[10px] text-slate-400 font-mono">d (r2, c2)</span>
                <span className="text-2xl font-bold font-mono">{d}</span>
              </div>
            </div>

            {/* Right Vertical Determinant Bar | */}
            <div className="w-1.5 h-44 bg-gradient-to-b from-cyan-400 via-blue-500 to-cyan-400 rounded-full shadow-[0_0_12px_rgba(56,189,248,0.5)]" />
          </div>

          {/* Dynamic calculation step cards below */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full mt-5">
            {/* Primary diagonal box */}
            <div
              className={`p-3 rounded-xl border text-center transition-all ${
                activeHighlight === 'primary' || activeHighlight === 'both' || currentStepIndex === 1
                  ? 'bg-emerald-950/80 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.25)]'
                  : 'bg-slate-900/60 border-slate-800 opacity-60'
              }`}
            >
              <div className="text-[11px] font-mono text-emerald-400 uppercase">Primary Diagonal</div>
              <div className="text-sm font-semibold text-white mt-1">
                {a} × {d} = <span className="text-emerald-300 text-base">{primaryProduct}</span>
              </div>
            </div>

            {/* Secondary diagonal box */}
            <div
              className={`p-3 rounded-xl border text-center transition-all ${
                activeHighlight === 'secondary' || activeHighlight === 'both' || currentStepIndex === 2
                  ? 'bg-amber-950/80 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                  : 'bg-slate-900/60 border-slate-800 opacity-60'
              }`}
            >
              <div className="text-[11px] font-mono text-amber-400 uppercase">Secondary Diagonal</div>
              <div className="text-sm font-semibold text-white mt-1">
                {b} × {c} = <span className="text-amber-300 text-base">{secondaryProduct}</span>
              </div>
            </div>

            {/* Subtraction result */}
            <div
              className={`p-3 rounded-xl border text-center transition-all ${
                activeHighlight === 'both' || currentStepIndex === 3
                  ? 'bg-violet-950/80 border-violet-500 shadow-[0_0_20px_rgba(168,85,247,0.35)]'
                  : 'bg-slate-900/60 border-slate-800 opacity-60'
              }`}
            >
              <div className="text-[11px] font-mono text-violet-400 uppercase">Determinant (ad - bc)</div>
              <div className="text-sm font-semibold text-white mt-1">
                {primaryProduct} - {secondaryProduct} ={' '}
                <span className="text-violet-300 text-lg font-bold">{detValue}</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Geometric 2D Parallelogram Area Demonstration */
        <div className="relative flex flex-col items-center justify-center w-full max-w-md py-4">
          <div className="w-full bg-slate-900/90 rounded-2xl p-4 border border-violet-500/30">
            <div className="text-xs font-mono text-violet-300 mb-2 flex items-center justify-between">
              <span>Geometric Interpretation: Area of Parallelogram</span>
              <span className="text-cyan-400 font-bold">Area = |{detValue}| sq units</span>
            </div>

            <svg viewBox="-1 -1 9 7" className="w-full h-52 bg-slate-950 rounded-xl border border-slate-800">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="1" height="1" patternUnits="userSpaceOnUse">
                  <path d="M 1 0 L 0 0 0 1" fill="none" stroke="#1e293b" strokeWidth="0.05" />
                </pattern>
              </defs>
              <rect x="-1" y="-1" width="10" height="8" fill="url(#grid)" />

              {/* Axes */}
              <line x1="-1" y1="0" x2="8" y2="0" stroke="#475569" strokeWidth="0.08" />
              <line x1="0" y1="-1" x2="0" y2="6" stroke="#475569" strokeWidth="0.08" />

              {/* Parallelogram vertices: (0,0), (a, c)=(2, 1), (a+b, c+d)=(5, 6), (b, d)=(3, 5) */}
              <polygon
                points={`0,0 ${a},${c} ${a + b},${c + d} ${b},${d}`}
                fill="rgba(168, 85, 247, 0.25)"
                stroke="#a855f7"
                strokeWidth="0.1"
              />

              {/* Vector 1 (from origin to (a,c)) */}
              <line x1="0" y1="0" x2={a} y2={c} stroke="#10b981" strokeWidth="0.14" />
              <circle cx={a} cy={c} r="0.18" fill="#10b981" />
              <text x={a + 0.2} y={c} fill="#10b981" fontSize="0.45" fontFamily="monospace">
                v₁({a}, {c})
              </text>

              {/* Vector 2 (from origin to (b,d)) */}
              <line x1="0" y1="0" x2={b} y2={d} stroke="#f59e0b" strokeWidth="0.14" />
              <circle cx={b} cy={d} r="0.18" fill="#f59e0b" />
              <text x={b + 0.2} y={d} fill="#f59e0b" fontSize="0.45" fontFamily="monospace">
                v₂({b}, {d})
              </text>

              {/* Center Area Label */}
              <text
                x={(a + b) / 2}
                y={(c + d) / 2}
                fill="#ffffff"
                fontSize="0.55"
                fontWeight="bold"
                textAnchor="middle"
              >
                Area = {Math.abs(detValue)}
              </text>
            </svg>

            <p className="text-[11px] text-slate-400 mt-2 text-center">
              The determinant represents the signed 2D area spanned by the two column vectors. If det = 0, the vectors collapse onto a single line!
            </p>
          </div>
        </div>
      )}

      {/* Interactive Quick Experiment Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
        <span className="text-[11px] text-slate-400 font-mono">Try other matrices:</span>
        <button
          onClick={() => setCustomMatrix([[2, 3], [1, 5]])}
          className="text-[11px] px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
        >
          [2, 3; 1, 5] (det = 7)
        </button>
        <button
          onClick={() => setCustomMatrix([[4, 2], [3, 5]])}
          className="text-[11px] px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
        >
          [4, 2; 3, 5] (det = 14)
        </button>
        <button
          onClick={() => setCustomMatrix([[2, 4], [1, 2]])}
          className="text-[11px] px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700"
        >
          [2, 4; 1, 2] (det = 0, Collinear)
        </button>
      </div>
    </div>
  );
};

export default MatrixDeterminant3D;
