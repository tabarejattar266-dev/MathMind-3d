import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const ThreeHeroScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x060a17, 0.035);

    const camera = new THREE.PerspectiveCamera(
      55,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 1.5, 7.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Ambient and Directional Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x38bdf8, 3, 20);
    pointLight1.position.set(4, 4, 3);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0xa855f7, 2.5, 20);
    pointLight2.position.set(-4, -2, 2);
    scene.add(pointLight2);

    // 1. Central 3D Mathematical Blackboard
    const boardGeo = new THREE.BoxGeometry(4.4, 2.7, 0.12);
    const boardMat = new THREE.MeshStandardMaterial({
      color: 0x091122,
      roughness: 0.4,
      metalness: 0.1,
      transparent: true,
      opacity: 0.9,
    });
    const blackboard = new THREE.Mesh(boardGeo, boardMat);
    blackboard.position.set(0, 0.3, -0.5);
    scene.add(blackboard);

    // Glowing border frame for the blackboard
    const frameGeo = new THREE.BoxGeometry(4.55, 2.85, 0.1);
    const frameEdges = new THREE.EdgesGeometry(frameGeo);
    const frameLineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8 });
    const boardFrame = new THREE.LineSegments(frameEdges, frameLineMat);
    boardFrame.position.copy(blackboard.position);
    scene.add(boardFrame);

    // 2. 3D Coordinate Grid Plane
    const gridHelper = new THREE.GridHelper(16, 24, 0x38bdf8, 0x1e293b);
    gridHelper.position.set(0, -2.2, 0);
    scene.add(gridHelper);

    // 3. Floating 3D Geometric Mathematical Polyhedra
    // Icosahedron
    const icoGeo = new THREE.IcosahedronGeometry(0.7, 0);
    const icoMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      wireframe: true,
      emissive: 0x0891b2,
      emissiveIntensity: 0.3,
    });
    const icosahedron = new THREE.Mesh(icoGeo, icoMat);
    icosahedron.position.set(-3.2, 1.8, 1);
    scene.add(icosahedron);

    // Torus (representing topological manifolds / equations)
    const torusGeo = new THREE.TorusGeometry(0.65, 0.2, 16, 40);
    const torusMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      wireframe: true,
      emissive: 0x7c3aed,
      emissiveIntensity: 0.3,
    });
    const torus = new THREE.Mesh(torusGeo, torusMat);
    torus.position.set(3.4, 1.5, 0.5);
    scene.add(torus);

    // Octahedron
    const octGeo = new THREE.OctahedronGeometry(0.55, 0);
    const octMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      wireframe: true,
      emissive: 0x2563eb,
      emissiveIntensity: 0.35,
    });
    const octahedron = new THREE.Mesh(octGeo, octMat);
    octahedron.position.set(-2.8, -1.2, 1.5);
    scene.add(octahedron);

    // Dodecahedron
    const dodecGeo = new THREE.DodecahedronGeometry(0.5, 0);
    const dodecMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      wireframe: true,
      emissive: 0x059669,
      emissiveIntensity: 0.3,
    });
    const dodecahedron = new THREE.Mesh(dodecGeo, dodecMat);
    dodecahedron.position.set(2.9, -1.1, 1.2);
    scene.add(dodecahedron);

    // 4. Floating Mathematical Particles (representing coordinates & formula dust)
    const particleCount = 140;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 8;

      // Cyan / Electric Blue / Violet tints
      const pick = Math.random();
      if (pick < 0.5) {
        colors[i * 3] = 0.22; // R
        colors[i * 3 + 1] = 0.74; // G
        colors[i * 3 + 2] = 0.97; // B (cyan/blue)
      } else {
        colors[i * 3] = 0.65;
        colors[i * 3 + 1] = 0.35;
        colors[i * 3 + 2] = 0.97; // violet
      }
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Mouse Interaction
    let mouseX = 0;
    let mouseY = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
      mouseY = -(((e.clientY - rect.top) / container.clientHeight) * 2 - 1);
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Responsive Resize
    const handleResize = () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle rotation of math objects
      icosahedron.rotation.x = elapsedTime * 0.4;
      icosahedron.rotation.y = elapsedTime * 0.5;
      icosahedron.position.y = 1.8 + Math.sin(elapsedTime * 1.5) * 0.15;

      torus.rotation.x = elapsedTime * 0.45;
      torus.rotation.y = elapsedTime * 0.6;
      torus.position.y = 1.5 + Math.cos(elapsedTime * 1.3) * 0.15;

      octahedron.rotation.x = elapsedTime * 0.35;
      octahedron.rotation.y = elapsedTime * 0.5;
      octahedron.position.y = -1.2 + Math.sin(elapsedTime * 1.8) * 0.12;

      dodecahedron.rotation.x = elapsedTime * 0.3;
      dodecahedron.rotation.y = elapsedTime * 0.4;
      dodecahedron.position.y = -1.1 + Math.cos(elapsedTime * 1.6) * 0.12;

      // Subtle blackboard tilt responding to mouse cursor
      blackboard.rotation.y = THREE.MathUtils.lerp(blackboard.rotation.y, mouseX * 0.15, 0.05);
      blackboard.rotation.x = THREE.MathUtils.lerp(blackboard.rotation.x, -mouseY * 0.1, 0.05);
      boardFrame.rotation.copy(blackboard.rotation);

      // Rotate particle field
      particles.rotation.y = elapsedTime * 0.04;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      scene.clear();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[360px] md:h-[480px] lg:h-[540px] overflow-hidden select-none"
    >
      {/* 2D HTML Overlay on the 3D Blackboard for crystal-clear mathematical equations */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[320px] sm:w-[420px] md:w-[490px] p-5 rounded-xl border border-cyan-500/30 bg-slate-950/60 backdrop-blur-md shadow-[0_0_35px_rgba(56,189,248,0.15)] text-center transition-all">
          <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20 mb-3">
            <span className="text-[11px] font-mono tracking-widest text-cyan-400 uppercase flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Interactive 3D Blackboard
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Euler · Gauss · Newton</span>
          </div>

          <div className="space-y-2 py-1">
            <div className="text-xl sm:text-2xl md:text-3xl font-serif text-white tracking-wide">
              <span className="text-cyan-300">e</span>
              <sup className="text-violet-300">iπ</sup> + 1 = 0
            </div>
            <div className="text-xs sm:text-sm text-cyan-200/90 font-mono">
              {'\\Delta = ad - bc \\quad | \\quad f\'(x) = \\lim_{h \\to 0} \\frac{f(x+h)-f(x)}{h}'}
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-around text-[11px] text-slate-300">
            <span className="px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/30 text-cyan-300">
              Interactive Vectors
            </span>
            <span className="px-2 py-0.5 rounded bg-violet-950/80 border border-violet-500/30 text-violet-300">
              3D Matrix Diagonals
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/30 text-emerald-300">
              Real-time Limits
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThreeHeroScene;
