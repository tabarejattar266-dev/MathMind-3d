import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface GeometrySolids3DProps {
  solidType?: 'cylinder' | 'sphere' | 'cube' | 'cone';
  radius?: number;
  height?: number;
}

export const GeometrySolids3D: React.FC<GeometrySolids3DProps> = ({
  solidType = 'cylinder',
  radius = 3,
  height = 7,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentSolid, setCurrentSolid] = useState<'cylinder' | 'sphere' | 'cube' | 'cone'>(solidType);
  const [r, setR] = useState(radius);
  const [h, setH] = useState(height);
  const [wireframe, setWireframe] = useState(false);

  // Math calculations
  const baseArea = Math.PI * r * r;
  const volume = Math.PI * r * r * h;
  const curvedArea = 2 * Math.PI * r * h;
  const totalArea = curvedArea + 2 * baseArea;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 3, 9);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 2);
    dirLight1.position.set(5, 8, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xa855f7, 1.5);
    dirLight2.position.set(-5, -4, 3);
    scene.add(dirLight2);

    // Dynamic Mesh Creation
    let geometry: THREE.BufferGeometry;
    const normR = Math.max(0.8, Math.min(2.5, r * 0.45));
    const normH = Math.max(1.2, Math.min(3.8, h * 0.45));

    if (currentSolid === 'cylinder') {
      geometry = new THREE.CylinderGeometry(normR, normR, normH, 32);
    } else if (currentSolid === 'sphere') {
      geometry = new THREE.SphereGeometry(normR * 1.2, 32, 24);
    } else if (currentSolid === 'cone') {
      geometry = new THREE.ConeGeometry(normR, normH, 32);
    } else {
      geometry = new THREE.BoxGeometry(normR * 1.5, normH, normR * 1.5);
    }

    const material = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.2,
      roughness: 0.3,
      wireframe: wireframe,
      transparent: true,
      opacity: 0.85,
    });

    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Edges outline for crisp visual clarity
    const edges = new THREE.EdgesGeometry(geometry);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x0284c7, linewidth: 2 });
    const wire = new THREE.LineSegments(edges, lineMat);
    mesh.add(wire);

    // Coordinate ground grid
    const grid = new THREE.GridHelper(8, 12, 0x1e293b, 0x0f172a);
    grid.position.y = -normH / 2 - 0.2;
    scene.add(grid);

    // Mouse drag rotation
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      mesh.rotation.y += deltaX * 0.01;
      mesh.rotation.x += deltaY * 0.01;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Touch support for mobile
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    };
    const onTouchMove = (e: TouchEvent) => {
      if (isDragging && e.touches.length === 1) {
        const deltaX = e.touches[0].clientX - prevMouseX;
        const deltaY = e.touches[0].clientY - prevMouseY;
        mesh.rotation.y += deltaX * 0.015;
        mesh.rotation.x += deltaY * 0.015;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    };
    const onTouchEnd = () => {
      isDragging = false;
    };

    container.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onTouchEnd);

    // Resize
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation loop (slow gentle idle rotation)
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (!isDragging) {
        mesh.rotation.y += 0.005;
      }
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      geometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  }, [currentSolid, r, h, wireframe]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-3 select-none">
      <div className="w-full flex items-center justify-between mb-2 px-2">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
          Interactive 3D Solid Geometry
        </span>
        <div className="flex gap-1.5">
          {(['cylinder', 'sphere', 'cone', 'cube'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setCurrentSolid(s)}
              className={`text-[11px] px-2.5 py-1 rounded border uppercase transition-all ${
                currentSolid === s
                  ? 'bg-cyan-600 border-cyan-400 text-white font-bold'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl items-center">
        {/* 3D WebGL Canvas */}
        <div className="relative w-full h-64 bg-slate-950/90 rounded-2xl border border-slate-800 overflow-hidden">
          <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
          <div className="absolute bottom-2 left-2 pointer-events-none text-[10px] text-slate-400 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-700 font-mono">
            Drag to rotate 3D view
          </div>
          <button
            onClick={() => setWireframe(!wireframe)}
            className="absolute top-2 right-2 text-[10px] px-2 py-1 rounded bg-slate-800/80 border border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            {wireframe ? 'Solid Mode' : 'Wireframe'}
          </button>
        </div>

        {/* Live Calculation Cards & Dimension Sliders */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40">
              <span className="text-[10px] text-cyan-400 font-mono">Base Area (π r²)</span>
              <div className="text-base font-bold text-cyan-200">
                {baseArea.toFixed(2)} cm²
              </div>
              <span className="text-[10px] text-slate-400">π × {r}²</span>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40">
              <span className="text-[10px] text-emerald-400 font-mono">Volume (V = π r² h)</span>
              <div className="text-base font-bold text-emerald-200">
                {volume.toFixed(2)} cm³
              </div>
              <span className="text-[10px] text-slate-400">Base × Height ({h})</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-violet-950/70 border border-violet-500/40">
            <div className="flex justify-between items-center text-xs">
              <span className="text-violet-300">Total Surface Area (2πr(r+h)):</span>
              <span className="font-mono text-violet-200 font-bold text-sm">
                {totalArea.toFixed(2)} cm²
              </span>
            </div>
          </div>

          {/* Dimension Controls */}
          <div className="space-y-2 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Radius (r):</span>
              <span className="font-mono text-cyan-400 font-bold">{r} cm</span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              step="1"
              value={r}
              onChange={(e) => setR(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
            />

            <div className="flex justify-between text-xs text-slate-300 mt-2">
              <span>Height (h):</span>
              <span className="font-mono text-cyan-400 font-bold">{h} cm</span>
            </div>
            <input
              type="range"
              min="2"
              max="12"
              step="1"
              value={h}
              onChange={(e) => setH(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeometrySolids3D;
