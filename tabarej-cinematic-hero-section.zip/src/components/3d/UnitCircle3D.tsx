import React, { useState } from 'react';
import { VisualHighlight } from '../../types/math';

interface UnitCircle3DProps {
  initialAngle?: number;
  highlight?: VisualHighlight;
}

export const UnitCircle3D: React.FC<UnitCircle3DProps> = ({
  initialAngle = 30,
}) => {
  const [angleDeg, setAngleDeg] = useState(initialAngle);

  const angleRad = (angleDeg * Math.PI) / 180;
  const cosVal = Math.cos(angleRad);
  const sinVal = Math.sin(angleRad);
  const tanVal = Math.abs(cosVal) > 0.001 ? Math.tan(angleRad) : Infinity;

  // SVG coordinate mapping: center at (150, 150), radius R = 110
  const cx = 150;
  const cy = 150;
  const R = 110;

  const px = cx + cosVal * R;
  const py = cy - sinVal * R; // SVG y is inverted

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-3 select-none">
      <div className="w-full flex items-center justify-between mb-2 px-2">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
          Unit Circle & Trigonometric Projections
        </span>
        <span className="text-xs font-mono text-violet-300">
          θ = {angleDeg}° ({((angleDeg * Math.PI) / 180).toFixed(2)} rad)
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl items-center">
        {/* Unit Circle SVG Diagram */}
        <div className="relative flex items-center justify-center bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
          <svg viewBox="0 0 300 300" className="w-64 h-64 sm:w-72 sm:h-72">
            {/* Coordinate Grid axes */}
            <line x1="20" y1={cy} x2="280" y2={cy} stroke="#334155" strokeWidth="1.5" />
            <line x1={cx} y1="20" x2={cx} y2="280" stroke="#334155" strokeWidth="1.5" />

            {/* Axis markers */}
            <text x="282" y={cy + 4} fill="#64748b" fontSize="10" fontFamily="monospace">x</text>
            <text x={cx - 4} y="15" fill="#64748b" fontSize="10" fontFamily="monospace">y</text>
            <text x={cx + R + 3} y={cy + 13} fill="#64748b" fontSize="9" fontFamily="monospace">+1</text>
            <text x={cx - R - 15} y={cy + 13} fill="#64748b" fontSize="9" fontFamily="monospace">-1</text>
            <text x={cx + 4} y={cy - R - 3} fill="#64748b" fontSize="9" fontFamily="monospace">+1</text>

            {/* The Unit Circle Boundary (R = 1) */}
            <circle
              cx={cx}
              cy={cy}
              r={R}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              className="drop-shadow-[0_0_8px_rgba(56,189,248,0.35)]"
            />

            {/* Angle Sector shading */}
            <path
              d={`M ${cx} ${cy} L ${cx + 35} ${cy} A 35 35 0 ${angleDeg > 180 ? 1 : 0} 0 ${
                cx + 35 * Math.cos(angleRad)
              } ${cy - 35 * Math.sin(angleRad)} Z`}
              fill="rgba(56, 189, 248, 0.15)"
            />

            {/* Horizontal Cosine base line */}
            <line
              x1={cx}
              y1={cy}
              x2={px}
              y2={cy}
              stroke="#38bdf8"
              strokeWidth="3.5"
              className="drop-shadow-[0_0_6px_rgba(56,189,248,0.7)]"
            />

            {/* Vertical Sine height line */}
            <line
              x1={px}
              y1={cy}
              x2={px}
              y2={py}
              stroke="#10b981"
              strokeWidth="3.5"
              className="drop-shadow-[0_0_6px_rgba(16,185,129,0.7)]"
            />

            {/* Hypotenuse / Radius Vector (r = 1) */}
            <line
              x1={cx}
              y1={cy}
              x2={px}
              y2={py}
              stroke="#e2e8f0"
              strokeWidth="2.5"
            />

            {/* Right-angle square indicator */}
            <path
              d={`M ${px - Math.sign(cosVal || 1) * 8} ${cy} L ${
                px - Math.sign(cosVal || 1) * 8
              } ${cy - Math.sign(sinVal || 1) * 8} L ${px} ${cy - Math.sign(sinVal || 1) * 8}`}
              fill="none"
              stroke="#64748b"
              strokeWidth="1.2"
            />

            {/* Boundary point P(x, y) */}
            <circle
              cx={px}
              cy={py}
              r="6.5"
              fill="#a855f7"
              stroke="#ffffff"
              strokeWidth="2"
              className="drop-shadow-[0_0_10px_rgba(168,85,247,0.9)]"
            />

            {/* Label at point P */}
            <text
              x={px + (cosVal >= 0 ? 8 : -55)}
              y={py + (sinVal >= 0 ? -10 : 20)}
              fill="#e2e8f0"
              fontSize="10"
              fontFamily="monospace"
              fontWeight="bold"
            >
              P({cosVal.toFixed(2)}, {sinVal.toFixed(2)})
            </text>
          </svg>
        </div>

        {/* Live Values and Sine Wave representation */}
        <div className="space-y-3">
          {/* Real-time Math Cards */}
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40">
              <span className="text-[10px] text-cyan-400 font-mono">Horizontal (cos θ)</span>
              <div className="text-lg font-bold text-cyan-200">
                {cosVal.toFixed(3)}
              </div>
              <span className="text-[10px] text-slate-400">Adjacent / Hypotenuse</span>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40">
              <span className="text-[10px] text-emerald-400 font-mono">Vertical (sin θ)</span>
              <div className="text-lg font-bold text-emerald-200">
                {sinVal.toFixed(3)}
              </div>
              <span className="text-[10px] text-slate-400">Opposite / Hypotenuse</span>
            </div>
          </div>

          {/* Tangent and Identity Verification */}
          <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">tan(θ) = sin/cos:</span>
              <span className="font-mono text-amber-300 font-semibold">
                {Math.abs(tanVal) > 100 ? 'Undefined (∞)' : tanVal.toFixed(3)}
              </span>
            </div>

            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Identity: sin²θ + cos²θ</span>
              <span className="font-mono text-violet-300 font-bold">
                {(sinVal * sinVal + cosVal * cosVal).toFixed(3)} = 1.000 ✓
              </span>
            </div>
          </div>

          {/* Interactive Slider */}
          <div className="space-y-1 bg-slate-900/70 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Rotate Angle (θ):</span>
              <span className="font-mono text-cyan-400 font-bold">{angleDeg}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="360"
              step="1"
              value={angleDeg}
              onChange={(e) => setAngleDeg(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
            />

            {/* Quick angle presets */}
            <div className="flex justify-between gap-1 mt-2">
              {[0, 30, 45, 60, 90, 180, 270].map((deg) => (
                <button
                  key={deg}
                  onClick={() => setAngleDeg(deg)}
                  className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${
                    angleDeg === deg
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-cyan-500/50'
                  }`}
                >
                  {deg}°
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnitCircle3D;
