import React, { useState } from 'react';

interface EquationBalance3DProps {
  initialLeftWeights?: number;
  initialRightWeights?: number;
}

export const EquationBalance3D: React.FC<EquationBalance3DProps> = () => {
  // Stages: 0: 2x + 5 = 15, 1: 2x = 10 (subtracted 5), 2: x = 5 (divided by 2)
  const [stage, setStage] = useState<number>(0);

  const leftEquation = stage === 0 ? '2x + 5' : stage === 1 ? '2x' : 'x';
  const rightEquation = stage === 0 ? '15' : stage === 1 ? '10' : '5';

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center p-3 select-none">
      <div className="w-full flex items-center justify-between mb-2 px-2">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
          The Golden Rule of Algebra: Balancing Scale
        </span>
        <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
          Equilibrium Maintained (=)
        </span>
      </div>

      <div className="flex flex-col items-center justify-center w-full max-w-xl py-2">
        {/* SVG Balance Scale */}
        <div className="relative w-full h-56 bg-slate-950/90 rounded-2xl border border-slate-800 p-2 flex items-center justify-center">
          <svg viewBox="0 0 400 220" className="w-full h-full">
            {/* Center Pivot Base */}
            <polygon points="200,80 185,180 215,180" fill="#334155" stroke="#475569" strokeWidth="2" />
            <rect x="160" y="180" width="80" height="15" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="2" />
            <circle cx="200" cy="80" r="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="2" />

            {/* Horizontal Balance Beam */}
            <line
              x1="60"
              y1="80"
              x2="340"
              y2="80"
              stroke="#38bdf8"
              strokeWidth="5"
              strokeLinecap="round"
              className="drop-shadow-[0_0_8px_rgba(56,189,248,0.4)]"
            />

            {/* Left Pan Chains & Pan */}
            <line x1="80" y1="80" x2="50" y2="140" stroke="#64748b" strokeWidth="1.5" />
            <line x1="80" y1="80" x2="110" y2="140" stroke="#64748b" strokeWidth="1.5" />
            <path d="M 40 140 Q 80 160 120 140 Z" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

            {/* Right Pan Chains & Pan */}
            <line x1="320" y1="80" x2="290" y2="140" stroke="#64748b" strokeWidth="1.5" />
            <line x1="320" y1="80" x2="350" y2="140" stroke="#64748b" strokeWidth="1.5" />
            <path d="M 280 140 Q 320 160 360 140 Z" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

            {/* Left Pan Contents */}
            {stage === 0 && (
              <g transform="translate(55, 110)">
                {/* 2 mystery boxes (x) */}
                <rect x="0" y="0" width="22" height="24" rx="3" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="7" y="16" fill="#fff" fontSize="12" fontWeight="bold">x</text>

                <rect x="25" y="0" width="22" height="24" rx="3" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="32" y="16" fill="#fff" fontSize="12" fontWeight="bold">x</text>

                {/* +5 weights */}
                <circle cx="15" cy="-8" r="6" fill="#f59e0b" />
                <text x="12" y="-5" fill="#000" fontSize="8" fontWeight="bold">5</text>
              </g>
            )}

            {stage === 1 && (
              <g transform="translate(60, 110)">
                <rect x="0" y="0" width="22" height="24" rx="3" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="7" y="16" fill="#fff" fontSize="12" fontWeight="bold">x</text>

                <rect x="25" y="0" width="22" height="24" rx="3" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                <text x="32" y="16" fill="#fff" fontSize="12" fontWeight="bold">x</text>
              </g>
            )}

            {stage === 2 && (
              <g transform="translate(72, 110)">
                <rect x="0" y="0" width="24" height="26" rx="3" fill="#a855f7" stroke="#c084fc" strokeWidth="2" />
                <text x="8" y="18" fill="#fff" fontSize="14" fontWeight="bold">x</text>
              </g>
            )}

            {/* Right Pan Contents */}
            {stage === 0 && (
              <g transform="translate(305, 115)">
                <rect x="-10" y="-8" width="30" height="26" rx="4" fill="#10b981" stroke="#34d399" strokeWidth="1.5" />
                <text x="-4" y="10" fill="#fff" fontSize="13" fontWeight="bold">15</text>
              </g>
            )}

            {stage === 1 && (
              <g transform="translate(305, 115)">
                <rect x="-10" y="-8" width="30" height="26" rx="4" fill="#10b981" stroke="#34d399" strokeWidth="1.5" />
                <text x="-4" y="10" fill="#fff" fontSize="13" fontWeight="bold">10</text>
              </g>
            )}

            {stage === 2 && (
              <g transform="translate(310, 115)">
                <rect x="-8" y="-8" width="26" height="26" rx="4" fill="#a855f7" stroke="#c084fc" strokeWidth="2" />
                <text x="0" y="10" fill="#fff" fontSize="14" fontWeight="bold">5</text>
              </g>
            )}
          </svg>
        </div>

        {/* Live Equation Display */}
        <div className="flex items-center justify-center gap-6 my-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 w-full">
          <div className="text-xl font-mono text-cyan-300 font-bold">{leftEquation}</div>
          <div className="text-2xl font-mono text-white">=</div>
          <div className="text-xl font-mono text-emerald-300 font-bold">{rightEquation}</div>
        </div>

        {/* Step-by-step interactive action buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => setStage(0)}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
              stage === 0
                ? 'bg-cyan-600 text-white font-bold border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.4)]'
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            Step 1: Original (2x + 5 = 15)
          </button>
          <button
            onClick={() => setStage(1)}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
              stage === 1
                ? 'bg-cyan-600 text-white font-bold border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.4)]'
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            Step 2: Subtract 5 on Both Sides (-5)
          </button>
          <button
            onClick={() => setStage(2)}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
              stage === 2
                ? 'bg-violet-600 text-white font-bold border-violet-400 shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            Step 3: Divide Both Sides by 2 (x = 5)
          </button>
        </div>
      </div>
    </div>
  );
};

export default EquationBalance3D;
