import React, { useState } from 'react';
import { Target, HelpCircle, CheckCircle2, XCircle, ChevronRight, X } from 'lucide-react';
import { Lesson, PracticeQuestion } from '../../types/math';
import MathView from '../MathView';
import { progressService } from '../../services/progressService';

interface PracticeModalProps {
  isOpen: boolean;
  onClose: () => void;
  lesson: Lesson;
}

export const PracticeModal: React.FC<PracticeModalProps> = ({
  isOpen,
  onClose,
  lesson,
}) => {
  const questions = lesson.practiceQuestions;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [unlockedHints, setUnlockedHints] = useState<number>(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [showSolution, setShowSolution] = useState(false);

  if (!isOpen || questions.length === 0) return null;

  const currentQ: PracticeQuestion = questions[currentIndex];

  const handleCheckAnswer = () => {
    if (!userAnswer.trim()) return;

    const cleanUser = userAnswer.trim().toLowerCase().replace(/\s+/g, '');
    const cleanActual = currentQ.finalAnswer.trim().toLowerCase().replace(/\s+/g, '');

    const isMatch = cleanUser === cleanActual || cleanUser.includes(cleanActual) || cleanActual.includes(cleanUser);

    if (isMatch) {
      setFeedback('correct');
      progressService.recordPracticeAttempt(true);
    } else {
      setFeedback('incorrect');
      progressService.recordPracticeAttempt(false);
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setUnlockedHints(0);
      setUserAnswer('');
      setFeedback(null);
      setShowSolution(false);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Target size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Independent Practice: {lesson.title}
              </h3>
              <p className="text-[11px] text-slate-400">
                Question {currentIndex + 1} of {questions.length}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Question text */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <p className="text-sm text-slate-200 font-medium">{currentQ.question}</p>
            {currentQ.latex && (
              <div className="py-2 text-center">
                <MathView math={currentQ.latex} displayMode={true} className="text-lg" />
              </div>
            )}
          </div>

          {/* Progressive 3-Tier Hints */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <HelpCircle size={14} className="text-cyan-400" />
                Step-by-Step Hints ({unlockedHints}/{currentQ.hints.length}):
              </span>
              {unlockedHints < currentQ.hints.length && (
                <button
                  type="button"
                  onClick={() => setUnlockedHints((prev) => prev + 1)}
                  className="text-[11px] text-cyan-400 hover:text-cyan-300 underline font-medium"
                >
                  Reveal Hint {unlockedHints + 1}
                </button>
              )}
            </div>

            {currentQ.hints.slice(0, unlockedHints).map((hint, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-200 flex items-start gap-2"
              >
                <span className="font-mono text-cyan-400 font-bold shrink-0">H{idx + 1}:</span>
                <span>{hint}</span>
              </div>
            ))}
          </div>

          {/* Answer Input */}
          <div className="space-y-2 pt-2">
            <label className="text-xs text-slate-300 block">Your Final Answer:</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={userAnswer}
                onChange={(e) => {
                  setUserAnswer(e.target.value);
                  setFeedback(null);
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleCheckAnswer()}
                placeholder="Type your calculated answer here..."
                className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
              <button
                type="button"
                onClick={handleCheckAnswer}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors"
              >
                Check
              </button>
            </div>
          </div>

          {/* Feedback & Solution */}
          {feedback === 'correct' && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
              <span>
                <strong>Excellent! That is correct.</strong> {currentQ.explanation}
              </span>
            </div>
          )}

          {feedback === 'incorrect' && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs space-y-1">
              <div className="flex items-center gap-2">
                <XCircle size={16} className="text-rose-400 shrink-0" />
                <span>Not quite. Check your calculations or use a hint!</span>
              </div>
              <button
                type="button"
                onClick={() => setShowSolution(true)}
                className="text-[11px] text-cyan-400 underline font-medium block pt-1"
              >
                Show Step-by-Step Solution
              </button>
            </div>
          )}

          {showSolution && (
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
              <div className="text-cyan-400 font-bold">Complete Solution:</div>
              <p>{currentQ.explanation}</p>
              <div className="font-mono text-emerald-300">Answer: {currentQ.finalAnswer}</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            Practice increases your mastery score in the dashboard.
          </span>
          <button
            type="button"
            onClick={handleNextQuestion}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
          >
            <span>{currentIndex < questions.length - 1 ? 'Next Practice Question' : 'Finish Practice'}</span>
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PracticeModal;
