import React, { useState } from 'react';
import { Award, CheckCircle2, XCircle, RotateCcw, X } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Lesson } from '../../types/math';
import { progressService } from '../../services/progressService';

interface MasteryQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  lesson: Lesson;
}

export const MasteryQuizModal: React.FC<MasteryQuizModalProps> = ({
  isOpen,
  onClose,
  lesson,
}) => {
  const quiz = lesson.masteryQuiz;
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>(new Array(quiz.length).fill(-1));
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || quiz.length === 0) return null;

  const handleSelectOption = (qIndex: number, optionIndex: number) => {
    if (submitted) return;
    const updated = [...selectedAnswers];
    updated[qIndex] = optionIndex;
    setSelectedAnswers(updated);
  };

  const calculateScore = () => {
    let score = 0;
    quiz.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) {
        score += 1;
      }
    });
    return score;
  };

  const handleSubmit = () => {
    setSubmitted(true);
    const score = calculateScore();
    const isMastered = score === quiz.length;

    if (isMastered) {
      progressService.completeLesson(lesson.id);
      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#38bdf8', '#818cf8', '#34d399', '#f472b6'],
        });
      } catch (e) {
        // Safe fallback if canvas not available
      }
    }
  };

  const handleRetry = () => {
    setSelectedAnswers(new Array(quiz.length).fill(-1));
    setSubmitted(false);
  };

  const score = calculateScore();
  const allAnswered = selectedAnswers.every((ans) => ans !== -1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-violet-500/20 border border-violet-500/40 flex items-center justify-center text-violet-400">
              <Award size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Concept Mastery Check: {lesson.title}
              </h3>
              <p className="text-[11px] text-slate-400">
                Verify that you understand the underlying concepts, not merely answers.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        {/* Questions list */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          {quiz.map((q, qIdx) => {
            const isCorrect = submitted && selectedAnswers[qIdx] === q.correctAnswer;

            return (
              <div
                key={q.id}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-bold text-slate-300">
                    Q{qIdx + 1}. {q.question}
                  </span>
                  {submitted && (
                    <span>
                      {isCorrect ? (
                        <CheckCircle2 size={16} className="text-emerald-400" />
                      ) : (
                        <XCircle size={16} className="text-rose-400" />
                      )}
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  {q.options.map((opt, optIdx) => {
                    const isSelected = selectedAnswers[qIdx] === optIdx;
                    let optClass = 'bg-slate-900 border-slate-700/80 text-slate-300 hover:bg-slate-800';

                    if (submitted) {
                      if (optIdx === q.correctAnswer) {
                        optClass = 'bg-emerald-950/70 border-emerald-500 text-emerald-300 font-bold';
                      } else if (isSelected) {
                        optClass = 'bg-rose-950/70 border-rose-500 text-rose-300 line-through';
                      } else {
                        optClass = 'bg-slate-900/50 border-slate-800 text-slate-500';
                      }
                    } else if (isSelected) {
                      optClass = 'bg-cyan-950 border-cyan-400 text-cyan-200 font-medium';
                    }

                    return (
                      <button
                        key={optIdx}
                        type="button"
                        disabled={submitted}
                        onClick={() => handleSelectOption(qIdx, optIdx)}
                        className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all flex items-center justify-between ${optClass}`}
                      >
                        <span>{opt}</span>
                        {isSelected && !submitted && (
                          <span className="w-2 h-2 rounded-full bg-cyan-400" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {submitted && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                    💡 <strong className="text-white">Explanation:</strong> {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          {!submitted ? (
            <>
              <span className="text-[11px] text-slate-400">
                {selectedAnswers.filter((a) => a !== -1).length} of {quiz.length} answered
              </span>
              <button
                type="button"
                disabled={!allAnswered}
                onClick={handleSubmit}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 disabled:opacity-40"
              >
                Submit Answers
              </button>
            </>
          ) : (
            <>
              <div className="text-xs">
                Score: <strong className="text-cyan-300">{score}/{quiz.length}</strong>{' '}
                {score === quiz.length ? (
                  <span className="text-emerald-400 font-bold ml-1">🎉 Concept Mastered!</span>
                ) : (
                  <span className="text-amber-400 ml-1">Needs revision</span>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleRetry}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700"
                >
                  <RotateCcw size={12} />
                  <span>Retry</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs"
                >
                  Done
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MasteryQuizModal;
