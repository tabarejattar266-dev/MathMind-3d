import React from 'react';
import {
  Sparkles,
  ArrowRight,
  Upload,
  Box,
  Volume2,
  Target,
  CheckCircle2,
  Play,
} from 'lucide-react';
import { Lesson, Language } from '../types/math';
import { SAMPLE_LESSONS } from '../data/sampleLessons';
import ThreeHeroScene from './3d/ThreeHeroScene';
import MathView from './MathView';
import { speechService } from '../services/speechService';

interface HeroSectionProps {
  onStartLearning: () => void;
  onTrySample: (sample: Lesson) => void;
  language: Language;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartLearning,
  onTrySample,
  language,
}) => {
  const featuredLesson = SAMPLE_LESSONS[0]; // 3x3 Determinant Classroom Master

  const sampleVoiceDemo = () => {
    const text =
      language === 'hindi'
        ? 'चलो बच्चों, सबसे पहले प्रश्न को ध्यान से देखिए। हमें इस three-by-three सारणिक का मान ज्ञात करना है।'
        : language === 'english'
        ? 'Welcome class! Today we will find the value of this three-by-three determinant step by step.'
        : 'Chalo beta, sabse pehle question ko dhyan se dekho. Humein is three-by-three determinant ki value find karni hai!';
    speechService.speak(text, language);
  };

  return (
    <div className="relative w-full overflow-hidden select-none">
      {/* Background radial gradients for deep navy / electric cyan atmosphere */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-cyan-600/15 via-blue-600/10 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute top-40 left-10 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Hero Header */}
      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-12 pb-6 text-center space-y-6">
        {/* Top Announcement Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs text-cyan-300 shadow-[0_0_20px_rgba(56,189,248,0.2)]">
          <Sparkles size={14} className="text-cyan-400" />
          <span className="font-semibold">MATHMIND 3D AI Teacher</span>
          <span className="w-1 h-1 rounded-full bg-slate-600" />
          <span className="text-slate-400">Hindi · Hinglish · English Voice</span>
        </div>

        {/* Primary Headline & Subtitle */}
        <div className="space-y-4 max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.1]">
            Maths Samajhna{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(56,189,248,0.4)]">
              Ab Hoga Easy.
            </span>
          </h1>

          <p className="text-base sm:text-lg lg:text-xl text-slate-300 font-normal max-w-2xl mx-auto leading-relaxed">
            Your personal AI teacher that explains every step through voice, visuals, and interactive 3D animations.
          </p>
        </div>

        {/* Call to Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            type="button"
            onClick={onStartLearning}
            className="flex items-center gap-2.5 px-7 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-cyan-500 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-sm shadow-[0_0_35px_rgba(56,189,248,0.4)] transition-all hover:scale-105 active:scale-95"
          >
            <Upload size={18} />
            <span>Start Learning</span>
            <ArrowRight size={16} />
          </button>

          <button
            type="button"
            onClick={() => onTrySample(featuredLesson)}
            className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/50 text-white font-semibold text-sm transition-all shadow-xl"
          >
            <Play size={16} className="text-cyan-400" />
            <span>Try a Sample Question</span>
          </button>

          {/* Voice sample trigger */}
          <button
            type="button"
            onClick={sampleVoiceDemo}
            className="flex items-center gap-2 px-4 py-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-violet-500/50 text-violet-300 text-xs font-semibold transition-colors"
            title="Hear Teacher Voice"
          >
            <Volume2 size={15} />
            <span>Hear Teacher Voice</span>
          </button>
        </div>
      </div>

      {/* Interactive 3D Mathematics Scene */}
      <div className="relative max-w-5xl mx-auto px-4 mt-2">
        <div className="relative rounded-3xl bg-slate-900/50 border border-slate-800/80 backdrop-blur-xl shadow-[0_0_50px_rgba(0,0,0,0.6)] overflow-hidden">
          <ThreeHeroScene />

          {/* Bottom badge */}
          <div className="absolute bottom-3 right-4 pointer-events-none hidden sm:flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-950/80 border border-slate-800 text-[10px] text-slate-400 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>Real-time Three.js 3D Coordinate Engine</span>
          </div>
        </div>
      </div>

      {/* 4 Feature Cards Specified in Requirement 3 */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center space-y-2 mb-10">
          <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 bg-cyan-950/80 px-3 py-1 rounded-full border border-cyan-500/30">
            Pedagogical Mastery Architecture
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            How MATHMIND Teaches Like a Real Patient Teacher
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            Never just final answers. Every calculation is explained with geometric intuition, voice, and interactive control.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Upload Question */}
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-3 group shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <Upload size={22} />
            </div>
            <div className="text-xs font-mono text-cyan-400 uppercase">Step 01</div>
            <h3 className="text-base font-bold text-white">1. Upload a Maths Question</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Snap a textbook photo or paste LaTeX. Our vision AI extracts matrices, calculus, trigonometry, and geometry with zero guessing.
            </p>
          </div>

          {/* 2. Learn with 3D Animation */}
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-blue-500/50 transition-all space-y-3 group shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
              <Box size={22} />
            </div>
            <div className="text-xs font-mono text-blue-400 uppercase">Step 02</div>
            <h3 className="text-base font-bold text-white">2. Learn with 3D Animation</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Watch determinant diagonals cross-multiply in real time, see secant lines shrink into tangents, and rotate 3D solids.
            </p>
          </div>

          {/* 3. Ask Your AI Teacher */}
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-violet-500/50 transition-all space-y-3 group shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 group-hover:scale-110 transition-transform">
              <Volume2 size={22} />
            </div>
            <div className="text-xs font-mono text-violet-400 uppercase">Step 03</div>
            <h3 className="text-base font-bold text-white">3. Ask Your AI Teacher</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Natural spoken voice in Hindi, Hinglish, or English. Interrupt anytime to ask "Ye step samajh nahi aaya" or request a real-life analogy!
            </p>
          </div>

          {/* 4. Practice Until You Understand */}
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/50 transition-all space-y-3 group shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <Target size={22} />
            </div>
            <div className="text-xs font-mono text-emerald-400 uppercase">Step 04</div>
            <h3 className="text-base font-bold text-white">4. Practice Until You Understand</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Adaptive 3-tier hints and conceptual mastery checks ensure genuine retention rather than mechanical memorization.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Sample Lessons Library Showcase */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
              Instant Working Experience
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              Try Ready-to-Learn 3D Lessons
            </h2>
            <p className="text-xs text-slate-400">
              Click any lesson below to enter the live 3D classroom immediately.
            </p>
          </div>

          <button
            type="button"
            onClick={onStartLearning}
            className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold underline"
          >
            <span>Or upload your own question</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SAMPLE_LESSONS.map((sample) => (
            <div
              key={sample.id}
              onClick={() => onTrySample(sample)}
              className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/60 hover:bg-slate-850/80 transition-all cursor-pointer group flex flex-col justify-between shadow-xl"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/30 text-cyan-300">
                    {sample.topic}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {sample.steps.length} Solution Steps
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {sample.title}
                </h3>

                <p className="text-xs text-slate-400 line-clamp-2">
                  {sample.originalQuestion}
                </p>

                {/* LaTeX Preview */}
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
                  <MathView math={sample.latexExpression} displayMode={true} className="text-sm" />
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <CheckCircle2 size={13} className="text-emerald-400" />
                  Voice + 3D Ready
                </span>
                <span className="text-cyan-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  Launch 3D Room →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
