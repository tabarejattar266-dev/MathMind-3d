import React, { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import katex from 'katex';
import { BoardAction, BoardColor, Lesson } from '../../types/math';
import { FrameInfo, TimelineSnapshot, WritingTimeline } from '../../services/writingTimeline';
import { chalkBridge } from '../../services/chalkBridge';
import { centerOf, highlightLeaves, revealChalkLine } from '../../services/chalkRevealer';
import './chalk.css';

const renderTex = (latex: string) =>
  katex.renderToString(latex, { displayMode: true, throwOnError: false, strict: false, output: 'html' });

const inkClass = (c?: BoardColor) => (c ? `ink-${c}` : '');

/**
 * One written line. Its symbols are revealed by `revealChalkLine`, driven by the
 * timeline's frame loop, so the line appears stroke by stroke as the chalk moves.
 */
const ChalkBlock = React.memo(function ChalkBlock({ action, initial }: { action: BoardAction; initial: number }) {
  const html = useMemo(() => renderTex(action.latex ?? ''), [action.latex]);
  const ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    revealChalkLine(el, initial);
    el.dataset.p = initial.toFixed(3);
    // initial reveal is only needed when the line is first mounted
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [html]);

  return (
    <div ref={ref} data-action={action.id} className="chalk-block">
      {action.label && <div className="chalk-label">{action.label}</div>}
      <div className={`chalk-ink ${inkClass(action.color)}`} dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  );
});

interface ChalkBoardProps {
  lesson: Lesson;
  timeline: WritingTimeline;
  snap: TimelineSnapshot;
  stageLabel: string;
}

export const ChalkBoard: React.FC<ChalkBoardProps> = ({ lesson, timeline, snap, stageLabel }) => {
  const rootRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const tipRef = useRef<HTMLDivElement>(null);
  const wipeRef = useRef<HTMLDivElement>(null);
  const hlRef = useRef<{ key: string; els: HTMLElement[] }>({ key: '', els: [] });

  /* Paint each frame of the timeline directly into the DOM (no React re-render). */
  useEffect(() => {
    const root = rootRef.current;
    const tip = tipRef.current;
    const wipe = wipeRef.current;
    if (!root || !tip || !wipe) return;

    chalkBridge.overlayEl = root;

    const paint = (f: FrameInfo) => {
      const a = f.action;
      let tipAt: { x: number; y: number } | null = null;

      // 1 · chalk writing: reveal the symbols of the line being written
      if (a.kind === 'write' && f.phase !== 'erase') {
        const el = root.querySelector<HTMLElement>(`[data-action="${a.id}"]`);
        if (el) {
          const p = f.phase === 'write' ? f.progress : 1;
          const key = p.toFixed(3);
          if (f.phase === 'write' || el.dataset.p !== key) {
            const res = revealChalkLine(el, p);
            el.dataset.p = key;
            if (res && f.phase === 'write') tipAt = res.point;
          }
        }
      }

      // 2 · pointing: highlight the symbols being discussed
      const targetId = a.kind === 'point' ? a.refersTo ?? '' : a.id;
      const wantsHl = (f.phase === 'explain' || f.phase === 'hold') && !!a.highlight?.length && !!targetId;
      const key = wantsHl ? `${targetId}|${(a.highlight ?? []).join(',')}|${a.id}` : '';
      if (key !== hlRef.current.key) {
        hlRef.current.els.forEach((el) => el.classList.remove('chalk-hl'));
        let els: HTMLElement[] = [];
        if (wantsHl) {
          const tgt = root.querySelector<HTMLElement>(`[data-action="${targetId}"]`);
          if (tgt) {
            els = highlightLeaves(tgt, a.highlight ?? []);
            els.forEach((el) => el.classList.add('chalk-hl'));
          }
        }
        hlRef.current = { key, els };
      }
      if (hlRef.current.els.length) tipAt = centerOf(hlRef.current.els[0]);

      // 3 · chalk tip + teacher's arm target
      const ov = root.getBoundingClientRect();
      if (tipAt && ov.width > 0) {
        const x = tipAt.x - ov.left;
        const y = tipAt.y - ov.top;
        tip.style.display = 'block';
        tip.style.transform = `translate(${x}px, ${y}px)`;
        chalkBridge.target = { nx: x / ov.width, ny: y / ov.height };
        chalkBridge.mode = f.phase === 'write' ? 'write' : 'point';
      } else {
        tip.style.display = 'none';
        chalkBridge.target = null;
        chalkBridge.mode = 'idle';
      }

      // 4 · eraser sweep
      if (f.phase === 'erase') {
        wipe.style.display = 'block';
        wipe.style.transform = `scaleX(${f.wipe.toFixed(4)})`;
      } else if (wipe.style.display !== 'none') {
        wipe.style.display = 'none';
        wipe.style.transform = 'scaleX(0)';
      }
    };

    const off = timeline.onFrame(paint);
    timeline.emitNow();

    return () => {
      off();
      hlRef.current.els.forEach((el) => el.classList.remove('chalk-hl'));
      hlRef.current = { key: '', els: [] };
      chalkBridge.overlayEl = null;
      chalkBridge.target = null;
      chalkBridge.mode = 'idle';
    };
  }, [timeline]);

  /* Keep the newest line in view, like a teacher stepping down the board. */
  useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [snap.index, snap.visibleActions.length]);

  const cur = snap.currentAction;

  return (
    <div ref={rootRef} className="chalk-board" data-phase={snap.phase}>
      <div className="chalk-dust" />

      <div className="chalk-head">
        <span className="chalk-stage">{stageLabel}</span>
        <span className="chalk-title">{lesson.boardTitle || lesson.title}</span>
        <span className={`chalk-status ${snap.phase === 'write' && snap.playing ? 'live' : ''}`}>
          {snap.finished ? 'done' : snap.phase === 'write' ? 'writing' : snap.playing ? 'explaining' : 'paused'}
        </span>
      </div>

      <div ref={bodyRef} className="chalk-body">
        {snap.visibleActions.length === 0 && (
          <div className="chalk-empty">Press Play — the teacher will start writing on the board.</div>
        )}
        {snap.visibleActions.map((a) => (
          <ChalkBlock
            key={a.id}
            action={a}
            initial={cur && a.id === cur.id && snap.phase === 'write' ? 0 : 1}
          />
        ))}
      </div>

      <div ref={tipRef} className="chalk-tip" style={{ display: 'none' }} />
      <div ref={wipeRef} className="chalk-wipe" style={{ display: 'none' }} />

      <div className="chalk-tray">
        <i />
        <i />
        <i />
        <span className="ml-auto text-[9px] font-mono text-white/40">
          {snap.visibleActions.length} lines
        </span>
      </div>
    </div>
  );
};

export default ChalkBoard;
