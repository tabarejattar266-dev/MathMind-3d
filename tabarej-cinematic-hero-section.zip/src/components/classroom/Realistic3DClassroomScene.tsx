import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { chalkBridge } from '../../services/chalkBridge';

export type CameraMode = 'wide' | 'board';

interface Realistic3DClassroomSceneProps {
  /** True while the teacher's voice is playing. Drives the mouth. */
  isSpeaking: boolean;
  cameraMode: CameraMode;
  lowPower?: boolean;
  onWebGLFail?: () => void;
}

/** The green board in world space. The 2D chalk frame is projected onto this rectangle. */
const BOARD = { x: -0.6, y: 1.6, z: -1.98, w: 6.15, h: 3.15 };

const PRESETS: Record<CameraMode, { pos: [number, number, number]; look: [number, number, number] }> = {
  wide: { pos: [0.3, 1.35, 4.4], look: [-0.35, 1.45, -1.2] },
  board: { pos: [-0.3, 1.5, 3.2], look: [-0.7, 1.55, -2.0] },
};

/** Shoulder of the chalk arm, in teacher-local space. */
const SHOULDER = new THREE.Vector3(-0.42, 1.95, 0);
/** Direction from shoulder to hand in the rest pose. */
const REST_DIR = new THREE.Vector3(-0.76, 0.55, 0.2).normalize();

const CORNERS: Array<[number, number]> = [
  [-1, 1],
  [1, 1],
  [1, -1],
  [-1, -1],
];

export const Realistic3DClassroomScene: React.FC<Realistic3DClassroomSceneProps> = ({
  isSpeaking,
  cameraMode,
  lowPower = false,
  onWebGLFail,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef({ isSpeaking, cameraMode });
  stateRef.current = { isSpeaking, cameraMode };
  const failRef = useRef(onWebGLFail);
  failRef.current = onWebGLFail;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: !lowPower, powerPreference: 'high-performance' });
    } catch (err) {
      console.warn('WebGL unavailable, using the 2D classroom fallback:', err);
      failRef.current?.();
      return;
    }

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0d131a);
    scene.fog = new THREE.FogExp2(0x0d131a, 0.035);

    const camera = new THREE.PerspectiveCamera(42, container.clientWidth / Math.max(1, container.clientHeight), 0.1, 100);
    camera.position.set(...PRESETS.wide.pos);
    camera.lookAt(...PRESETS.wide.look);

    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPower ? 1 : 2));
    renderer.shadowMap.enabled = !lowPower;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);

    /* ------------------------------ LIGHT ------------------------------ */
    scene.add(new THREE.AmbientLight(0xdbeafe, 0.62));

    const sun = new THREE.DirectionalLight(0xffedd5, 1.9);
    sun.position.set(-6, 5, 2);
    if (!lowPower) {
      sun.castShadow = true;
      sun.shadow.mapSize.set(1024, 1024);
    }
    scene.add(sun);

    const boardSpot = new THREE.SpotLight(0xfffbeb, 1.6, 11, Math.PI / 4, 0.45);
    boardSpot.position.set(0.4, 3.9, 1.6);
    boardSpot.target.position.set(-0.6, 1.5, -2);
    scene.add(boardSpot, boardSpot.target);

    const rim = new THREE.PointLight(0x38bdf8, 1.1, 8);
    rim.position.set(2.6, 2.4, 0.6);
    scene.add(rim);

    /* ------------------------------ ROOM ------------------------------- */
    const backWall = new THREE.Mesh(
      new THREE.PlaneGeometry(16, 8),
      new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.85 }),
    );
    backWall.position.set(0, 2.2, -2.1);
    scene.add(backWall);

    const leftWall = new THREE.Mesh(
      new THREE.PlaneGeometry(14, 8),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.9 }),
    );
    leftWall.position.set(-5.5, 2.2, 1.5);
    leftWall.rotation.y = Math.PI / 2;
    scene.add(leftWall);

    for (let w = 0; w < 3; w++) {
      const frame = new THREE.Mesh(
        new THREE.BoxGeometry(0.1, 2.4, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 }),
      );
      frame.position.set(-5.42, 2.4, -0.6 + w * 2.2);
      scene.add(frame);

      const glass = new THREE.Mesh(
        new THREE.PlaneGeometry(1.6, 2.2),
        new THREE.MeshBasicMaterial({ color: 0xfef3c7, transparent: true, opacity: 0.3 }),
      );
      glass.rotation.y = Math.PI / 2;
      glass.position.set(-5.4, 2.4, -0.6 + w * 2.2);
      scene.add(glass);
    }

    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(16, 14),
      new THREE.MeshStandardMaterial({ color: 0x271e16, roughness: 0.65, metalness: 0.1 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, -0.6, 1.5);
    scene.add(floor);

    /* ------------------------- GREEN BLACKBOARD ------------------------- */
    const board = new THREE.Group();
    board.position.set(BOARD.x, BOARD.y, -2.05);
    scene.add(board);
    board.add(
      new THREE.Mesh(
        new THREE.BoxGeometry(6.4, 3.4, 0.12),
        new THREE.MeshStandardMaterial({ color: 0x5a341a, roughness: 0.7 }),
      ),
    );
    const slate = new THREE.Mesh(
      new THREE.PlaneGeometry(BOARD.w, BOARD.h),
      new THREE.MeshStandardMaterial({ color: 0x143424, roughness: 0.9, metalness: 0.04 }),
    );
    slate.position.z = 0.065;
    board.add(slate);
    const tray = new THREE.Mesh(
      new THREE.BoxGeometry(6.25, 0.08, 0.22),
      new THREE.MeshStandardMaterial({ color: 0x3d2314, roughness: 0.6 }),
    );
    tray.position.set(0, -1.68, 0.12);
    board.add(tray);

    /* ------------------------------ CLOCK ------------------------------ */
    const clock = new THREE.Group();
    clock.position.set(3.4, 3.2, -2.05);
    scene.add(clock);
    const rimMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.38, 0.38, 0.06, 32),
      new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5 }),
    );
    rimMesh.rotation.x = Math.PI / 2;
    clock.add(rimMesh);
    const face = new THREE.Mesh(new THREE.CircleGeometry(0.33, 32), new THREE.MeshBasicMaterial({ color: 0xf8fafc }));
    face.position.z = 0.035;
    clock.add(face);
    const hourHand = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.18, 0.01), new THREE.MeshBasicMaterial({ color: 0x0f172a }));
    hourHand.position.set(0, 0.07, 0.04);
    hourHand.rotation.z = -0.8;
    clock.add(hourHand);
    const minHand = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.24, 0.01), new THREE.MeshBasicMaterial({ color: 0x0f172a }));
    minHand.position.set(0, 0.09, 0.045);
    clock.add(minHand);
    const secHand = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.26, 0.01), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    secHand.position.set(0, 0.1, 0.05);
    clock.add(secHand);

    /* ------------------------------ TEACHER ------------------------------ */
    const teacher = new THREE.Group();
    teacher.position.set(1.4, -0.6, -1.35);
    teacher.rotation.y = -0.38;
    scene.add(teacher);

    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const hoodieMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.92, metalness: 0.05 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xdeb892, roughness: 0.65 });
    const shoeMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6 });

    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.11, 1.15, 12), pantsMat);
    legL.position.set(-0.18, 0.58, 0);
    teacher.add(legL);
    const legR = legL.clone();
    legR.position.x = 0.18;
    teacher.add(legR);

    const shoeL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.28), shoeMat);
    shoeL.position.set(-0.18, 0.05, 0.06);
    teacher.add(shoeL);
    const shoeR = shoeL.clone();
    shoeR.position.x = 0.18;
    teacher.add(shoeR);

    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.35, 1.0, 16), hoodieMat);
    torso.position.set(0, 1.62, 0);
    if (!lowPower) torso.castShadow = true;
    teacher.add(torso);

    const pocket = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.22, 0.1), hoodieMat);
    pocket.position.set(0, 1.35, 0.2);
    teacher.add(pocket);

    const hood = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.1, 8, 16), hoodieMat);
    hood.rotation.x = Math.PI / 2.3;
    hood.position.set(0, 2.05, -0.08);
    teacher.add(hood);

    const head = new THREE.Group();
    head.position.set(0, 2.22, 0.02);
    teacher.add(head);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.12, 0.22, 12), skinMat);
    neck.position.y = -0.12;
    head.add(neck);

    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.24, 28, 24), skinMat);
    if (!lowPower) skull.castShadow = true;
    head.add(skull);

    const hair = new THREE.Mesh(
      new THREE.SphereGeometry(0.255, 20, 16, 0, Math.PI * 2, 0, Math.PI * 0.52),
      new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.85 }),
    );
    hair.position.set(0, 0.05, -0.02);
    head.add(hair);

    // Glasses
    const glassMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const ringGeo = new THREE.RingGeometry(0.05, 0.065, 20);
    const gL = new THREE.Mesh(ringGeo, glassMat);
    gL.position.set(-0.085, 0.02, 0.23);
    head.add(gL);
    const gR = new THREE.Mesh(ringGeo, glassMat);
    gR.position.set(0.085, 0.02, 0.23);
    head.add(gR);

    // Mouth — opens and closes while the voice is speaking
    const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 10), new THREE.MeshBasicMaterial({ color: 0x7f1d1d }));
    mouth.position.set(0, -0.1, 0.225);
    mouth.scale.set(1.1, 0.25, 0.5);
    head.add(mouth);

    // Left arm: relaxed, sways gently
    const leftArm = new THREE.Group();
    leftArm.position.set(0.42, 1.95, 0);
    teacher.add(leftArm);
    const leftMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.08, 0.75, 12), hoodieMat);
    leftMesh.position.set(0.06, -0.32, 0);
    leftMesh.rotation.z = -0.25;
    leftArm.add(leftMesh);

    // Chalk arm — its orientation is aimed at the live chalk tip every frame
    const arm = new THREE.Group();
    arm.position.copy(SHOULDER);
    teacher.add(arm);

    const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.08, 0.5, 12), hoodieMat);
    upper.position.set(-0.2, 0.1, 0.1);
    upper.rotation.z = 1.25;
    arm.add(upper);
    const fore = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.07, 0.5, 12), hoodieMat);
    fore.position.set(-0.52, 0.35, 0.15);
    fore.rotation.z = 0.95;
    fore.rotation.x = -0.3;
    arm.add(fore);
    // The hand sits exactly on REST_DIR, so aiming the arm places the chalk where the teacher points.
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 12), skinMat);
    hand.position.set(-0.76, 0.55, 0.2);
    arm.add(hand);
    const chalk = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.1, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    chalk.rotation.z = Math.PI / 3;
    chalk.position.set(-0.81, 0.59, 0.22);
    arm.add(chalk);
    const chalkGlow = new THREE.PointLight(0xfffbeb, 1.1, 0.9);
    chalkGlow.position.copy(chalk.position);
    arm.add(chalkGlow);

    /* ---------------------- STUDENTS & DESKS ---------------------- */
    const buildStudent = (x: number, z: number, rotY: number, shirt: number, hairColor: number) => {
      const g = new THREE.Group();
      g.position.set(x, -0.6, z);
      g.rotation.y = rotY;
      scene.add(g);
      const t = new THREE.Mesh(
        new THREE.CylinderGeometry(0.31, 0.29, 0.84, 12),
        new THREE.MeshStandardMaterial({ color: shirt, roughness: 0.85 }),
      );
      t.position.y = 0.85;
      g.add(t);
      const h = new THREE.Mesh(
        new THREE.SphereGeometry(0.2, 16, 16),
        new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.9 }),
      );
      h.position.set(0, 1.37, 0);
      g.add(h);
    };
    buildStudent(-1.15, 2.65, 0.15, 0x3b82f6, 0x172554);
    buildStudent(0.95, 2.55, -0.22, 0xd97706, 0x3f2411);
    if (!lowPower) buildStudent(2.6, 2.8, -0.5, 0x0f766e, 0x1c1917);

    const buildDesk = (x: number, z: number, tilt: number) => {
      const g = new THREE.Group();
      g.position.set(x, -0.6, z);
      scene.add(g);
      const top = new THREE.Mesh(
        new THREE.BoxGeometry(1.3, 0.06, 0.7),
        new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.6 }),
      );
      top.position.set(0, 0.72, 0);
      g.add(top);
      for (let l = 0; l < 4; l++) {
        const leg = new THREE.Mesh(
          new THREE.CylinderGeometry(0.02, 0.02, 0.72, 8),
          new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.7 }),
        );
        leg.position.set(l % 2 === 0 ? -0.55 : 0.55, 0.36, l < 2 ? -0.25 : 0.25);
        g.add(leg);
      }
      const notebook = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.015, 0.24), new THREE.MeshBasicMaterial({ color: 0xf8fafc }));
      notebook.position.set(0.05, 0.76, 0.05);
      notebook.rotation.y = tilt;
      g.add(notebook);
    };
    buildDesk(-1.1, 2.25, 0.12);
    buildDesk(0.9, 2.15, -0.12);
    if (!lowPower) buildDesk(2.55, 2.4, 0.2);

    /* ------------------------------ LOOP ------------------------------ */
    const clockTimer = new THREE.Clock();
    const lookTarget = new THREE.Vector3(...PRESETS.wide.look);
    const camDesired = new THREE.Vector3();
    const lookGoal = new THREE.Vector3();
    const wp = new THREE.Vector3();
    const dir = new THREE.Vector3();
    const targetQ = new THREE.Quaternion();
    const eul = new THREE.Euler();
    const proj = new THREE.Vector3();
    let headYaw = 0.15;

    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = clockTimer.getElapsedTime();
      const s = stateRef.current;
      const bridge = chalkBridge;

      // Wall clock keeps ticking
      secHand.rotation.z = -t;
      minHand.rotation.z = -t / 60;

      // Breathing and body sway
      teacher.position.y = -0.6 + Math.sin(t * 1.6) * 0.014;
      teacher.updateMatrixWorld(true);
      leftArm.rotation.z = Math.sin(t * 1.1) * 0.05;

      // Cinematic camera between presets
      const preset = PRESETS[s.cameraMode] ?? PRESETS.wide;
      camDesired.set(preset.pos[0] + Math.sin(t * 0.25) * 0.04, preset.pos[1] + Math.sin(t * 0.2) * 0.02, preset.pos[2]);
      camera.position.lerp(camDesired, 0.035);
      lookGoal.set(preset.look[0], preset.look[1], preset.look[2]);
      lookTarget.lerp(lookGoal, 0.05);
      camera.lookAt(lookTarget);
      camera.updateMatrixWorld();

      // Project the 3D board onto the 2D chalk frame so the writing sits on the green board
      const frame = bridge.frameEl;
      if (bridge.projectOverlay && frame) {
        const W = container.clientWidth;
        const H = container.clientHeight;
        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        for (const [sx, sy] of CORNERS) {
          proj.set(BOARD.x + (sx * BOARD.w) / 2, BOARD.y + (sy * BOARD.h) / 2, BOARD.z).project(camera);
          const px = ((proj.x + 1) / 2) * W;
          const py = ((1 - proj.y) / 2) * H;
          minX = Math.min(minX, px);
          maxX = Math.max(maxX, px);
          minY = Math.min(minY, py);
          maxY = Math.max(maxY, py);
        }
        frame.style.left = `${minX}px`;
        frame.style.top = `${minY}px`;
        frame.style.width = `${maxX - minX}px`;
        frame.style.height = `${maxY - minY}px`;
      }

      // Chalk arm: aims at the live chalk tip (or the highlighted symbol when pointing)
      const aiming = !!bridge.target && (bridge.mode === 'write' || bridge.mode === 'point');
      if (aiming && bridge.target) {
        wp.set(
          BOARD.x + (bridge.target.nx - 0.5) * BOARD.w,
          BOARD.y + (0.5 - bridge.target.ny) * BOARD.h,
          BOARD.z + 0.14,
        );
        teacher.worldToLocal(wp);
        dir.copy(wp).sub(SHOULDER);
        if (bridge.mode === 'write') {
          // small wrist motion while writing
          dir.x += Math.sin(t * 10) * 0.035;
          dir.y += Math.cos(t * 7.3) * 0.03;
        }
        dir.normalize();
        targetQ.setFromUnitVectors(REST_DIR, dir);
        headYaw = THREE.MathUtils.clamp(dir.x * 0.7, -0.6, 0.6);
      } else {
        // Resting: open-hand explaining gesture
        eul.set(0.04 * Math.sin(t * 1.3), 0, 0.12 + 0.07 * Math.sin(t * 1.7));
        targetQ.setFromEuler(eul);
        headYaw = 0.15 + 0.1 * Math.sin(t * 0.9);
      }
      arm.quaternion.slerp(targetQ, aiming ? (bridge.mode === 'write' ? 0.2 : 0.1) : 0.05);

      head.rotation.y = THREE.MathUtils.lerp(head.rotation.y, headYaw, 0.06);
      head.rotation.x = Math.sin(t * 1.4) * 0.03;

      // Mouth moves with speech
      if (s.isSpeaking) {
        mouth.scale.set(1.1, 0.3 + Math.abs(Math.sin(t * 17)) * 0.9, 0.5);
      } else {
        mouth.scale.set(1.1, 0.25, 0.5);
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = container.clientWidth / Math.max(1, container.clientHeight);
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else if (mat) mat.dispose();
      });
      renderer.dispose();
    };
  }, [lowPower]);

  return <div ref={containerRef} className="absolute inset-0 w-full h-full overflow-hidden select-none" />;
};

export default Realistic3DClassroomScene;
