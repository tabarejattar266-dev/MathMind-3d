import React, { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import {
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  SkipBack,
  SkipForward,
  MessageSquare,
  Award,
  BookOpen,
  Sparkles,
  Captions,
  Volume2,
  VolumeX,
  Target,
  MonitorSmartphone,
} from 'lucide-react';
import { Language, Lesson, TeachingMode } from '../../types/math';
import Realistic3DClassroomScene, { CameraMode } from './Realistic3DClassroomScene';
import ChalkBoard from './ChalkBoard';
import DoubtInterruption from './DoubtInterruption';
import LearningSummarySection from './LearningSummarySection';
import PracticeModal from '../practice/PracticeModal';
import MasteryQuizModal from '../practice/MasteryQuizModal';
import { WritingTimeline } from '../../services/writingTimeline';
import { cuesToBoardScript } from '../../services/boardScript';
import { speechService } from '../../services/speechService';
import { chalkBridge } from '../../services/chalkBridge';

interface ClassroomWorkspaceProps {
  lesson: Lesson;
  language: Language;
  onLanguageChange: (l: Language) => void;
  onBackToHome: () => void;
}

const GROUP_LABEL: Record<number, string> = {
  0: 'Stage 1 · Understand the question',
  1: 'Stage 2–3 · Basics & the formula',
  2: 'Stage 4 · Identify every value',
  3: 'Stage 5 · Substitute & calculate',
  4: 'Stage 6 · Verify the answer',
  5: 'Stage 7 · Your turn',
};

const SPEEDS = [0.75, 1, 1.25, 1.5];
const MODE_SPEED: Record<TeachingMode, number> = { beginner: 0.8, normal: 1, exam: 1.25 };

export const ClassroomWorkspace: React.FC<ClassroomWorkspaceProps> = ({
  lesson,
  language,
  onLanguageChange,
  onBackToHome,
}) => {
  /* The blackboard script: generated for 3×3 determinants, adapted from cues for other lessons. */
  const script = useMemo(() => lesson.boardScript ?? cuesToBoardScript(lesson), [lesson]);
  const timeline = useMemo(() => new WritingTimeline(script, language), [script]);
  const snap = useSyncExternalStore(timeline.subscribe, timeline.getSnapshot);

  const [mode, setMode] = useState<TeachingMode>('normal');
  const [speed, setSpeedState] = useState(1);
  const [voiceOn, setVoiceOn] = useState(true);
  const [captionsOn, setCaptionsOn] = useState(true);
  const [force2D, setForce2D] = useState(false);
  const [webglFailed, setWebglFailed] = useState(false);
  const [doubtOpen, setDoubtOpen] = useState(false);
  const [practiceOpen, setPracticeOpen] = useState(false);
  const [quizOpen, setQuizOpen] = useState(false);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const reduced = useMemo(
    () => typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
    [],
  );
  const [wide, setWide] = useState(
    () => typeof window !== 'undefined' && !!window.matchMedia?.('(min-width: 768px)').matches,
  );

  const frameRef = useRef<HTMLDivElement>(null);

  /* ---------- voice availability (ElevenLabs only, no substitute) ---------- */
  useEffect(() => {
    speechService.checkBackend();
    const off = speechService.onVoiceStatus((s, m) => {
      if (s === 'unavailable') {
        setVoiceError(m ?? 'The ElevenLabs teacher voice is not available.');
      } else if (s === 'ready') {
        setVoiceError(null);
      }
    });
    return off;
  }, []);

  /* ---------- timeline wiring ---------- */
  useEffect(() => {
    timeline.setLanguage(language);
  }, [language, timeline]);

  useEffect(() => {
    timeline.setVoice(voiceOn);
  }, [voiceOn, timeline]);

  useEffect(() => () => timeline.dispose(), [timeline]);

  useEffect(() => {
    timeline.setSpeed(MODE_SPEED[mode]);
    setSpeedState(MODE_SPEED[mode]);
  }, [mode, timeline]);

  const changeSpeed = (s: number) => {
    setSpeedState(s);
    timeline.setSpeed(s);
  };

  /* ---------- board projection (2D frame sits on the 3D board) ---------- */
  useEffect(() => {
    chalkBridge.frameEl = frameRef.current;
    return () => {
      chalkBridge.frameEl = null;
    };
  }, []);

  useEffect(() => {
    const on = wide && !force2D && !webglFailed && !reduced;
    chalkBridge.projectOverlay = on;
    if (!on && frameRef.current) {
      // hand layout back to the CSS breakpoints
      const s = frameRef.current.style;
      s.left = '';
      s.top = '';
      s.width = '';
      s.height = '';
    }
  }, [wide, force2D, webglFailed, reduced]);

  useEffect(() => {
    const onResize = () => setWide(!!window.matchMedia?.('(min-width: 768px)').matches);
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      chalkBridge.projectOverlay = false;
    };
  }, []);

  /* ---------- keyboard: Space = play/pause, arrows = steps ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (doubtOpen || practiceOpen || quizOpen || summaryOpen) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') {
        e.preventDefault();
        if (timeline.getSnapshot().playing) timeline.pause();
        else timeline.play();
      } else if (e.key === 'ArrowRight') {
        timeline.next();
      } else if (e.key === 'ArrowLeft') {
        timeline.prev();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [doubtOpen, practiceOpen, quizOpen, summaryOpen, timeline]);

  /* ---------- derived ---------- */
  const currentStep = lesson.steps[Math.min(snap.stepIndex, lesson.steps.length - 1)] ?? lesson.steps[0];
  const stageLabel = GROUP_LABEL[snap.stepIndex] ?? `Step ${snap.stepIndex + 1}`;
  const cameraMode: CameraMode =
    snap.phase === 'write' || snap.currentAction?.kind === 'point' ? 'board' : 'wide';
  const sceneOn = !force2D && !webglFailed;

  /* ---------- actions ---------- */
  const openDoubt = () => {
    timeline.pause();
    setDoubtOpen(true);
  };

  const closeDoubt = () => {
    setDoubtOpen(false);
    timeline.resumeAfterDoubt();
  };

  const explainSimply = () => {
    const text =
      currentStep?.simplerExplanation?.[language] ||
      currentStep?.simplerExplanation?.hinglish ||
      `Chalo ise aur aasan karte hain. ${currentStep?.operation ?? ''}`;
    timeline.pause();
    setToast(text);
    if (voiceOn) speechService.speak(text, language);
  };

  const togglePlay = () => (snap.playing ? timeline.pause() : timeline.play());

  const progressPct = Math.round((snap.index / Math.max(1, snap.total - 1)) * 100);

  return (
    <div className="relative w-full h-screen flex flex-col bg-[#0a0f16] text-slate-100 overflow-hidden select-none">
      {/* ---------------- TOP BAR ---------------- */}
      <header className="h-14 shrink-0 bg-slate-950/95 border-b border-slate-800 px-3 sm:px-5 flex items-center justify-between gap-2 z-40">
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700"
          >
            <ArrowLeft size={14} />
            <span className="hidden sm:inline">Exit</span>
          </button>
          <div className="h-4 w-px bg-slate-700 hidden sm:block" />
          <div className="min-w-0">
            <p className="text-xs sm:text-sm font-bold text-white truncate">{lesson.title}</p>
            <p className="text-[10px] text-amber-300/90 font-mono truncate">
              {stageLabel} · line {Math.min(snap.index + 1, snap.total)}/{snap.total}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="hidden md:flex items-center bg-slate-900 rounded-xl border border-slate-800 p-0.5">
            {(['beginner', 'normal', 'exam'] as TeachingMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold capitalize transition-colors ${
                  mode === m ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          <div className="flex items-center bg-slate-900 rounded-xl border border-slate-800 p-0.5">
            {(['hinglish', 'hindi', 'english'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => onLanguageChange(l)}
                className={`px-2 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                  language === l ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                {l === 'hinglish' ? 'Hinglish' : l === 'hindi' ? 'हिंदी' : 'Eng'}
              </button>
            ))}
          </div>

          <button
            onClick={() => setSummaryOpen(true)}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white"
            title="Lesson summary"
          >
            <BookOpen size={15} />
          </button>
        </div>
      </header>

      {/* ---------------- CLASSROOM THEATRE ---------------- */}
      <main className="relative flex-1 min-h-0 overflow-hidden">
        {sceneOn ? (
          <Realistic3DClassroomScene
            isSpeaking={snap.playing && voiceOn && snap.phase !== 'hold'}
            cameraMode={cameraMode}
            lowPower={reduced}
            onWebGLFail={() => setWebglFailed(true)}
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-b from-[#0d131a] to-[#131b25]">
            <div className="absolute right-[6%] bottom-[8%] w-[26%] h-[42%] rounded-full bg-slate-800/70 border border-slate-700" />
            <div className="absolute left-[8%] bottom-[6%] w-[70%] h-16 rounded-lg bg-[#78350f]/70 border border-amber-900/60" />
            <p className="absolute right-4 top-4 text-[10px] font-mono text-white/50 text-right leading-relaxed">
              Lightweight classroom mode
              <br />
              (3D disabled)
            </p>
          </div>
        )}

        {/* The green board. Its frame is projected onto the 3D board when 3D is on. */}
        <div
          ref={frameRef}
          className="absolute z-20 overflow-hidden rounded-[4px] shadow-[0_0_0_6px_#5a341a,0_0_60px_rgba(0,0,0,0.75)] left-[3%] right-[3%] top-[4%] bottom-[30%] md:left-[5%] md:right-[38%] md:top-[7%] md:bottom-[24%] xl:right-[36%]"
        >
          <ChalkBoard lesson={lesson} timeline={timeline} snap={snap} stageLabel={stageLabel} />
        </div>

        {/* Teacher's spoken line, as captions */}
        {captionsOn && snap.caption && (
          <div className="absolute left-0 right-0 bottom-2 z-30 px-3 pointer-events-none">
            <div className="mx-auto max-w-2xl rounded-2xl bg-black/80 border border-white/15 px-4 py-2.5 backdrop-blur-md">
              <div className="flex items-start gap-2">
                <span className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${snap.playing ? 'bg-amber-400 animate-pulse' : 'bg-white/40'}`} />
                <p className="text-[12px] sm:text-[13px] text-white/95 leading-relaxed font-serif italic">“{snap.caption}”</p>
              </div>
            </div>
          </div>
        )}

        {/* Lesson rail (desktop) */}
        <div className="absolute right-3 top-3 z-30 w-[30%] max-w-[300px] hidden lg:flex flex-col gap-2">
          <div className="rounded-2xl bg-slate-950/85 border border-slate-800 p-3 backdrop-blur-md">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400">Now on the board</span>
              <span className="text-[10px] text-slate-400 font-mono">{snap.phase}</span>
            </div>
            <h3 className="mt-1 text-xs font-bold text-white leading-snug">
              {snap.currentAction?.label ?? currentStep?.title}
            </h3>
            <p className="mt-2 text-[10px] text-slate-400 leading-relaxed">{currentStep?.ruleUsed}</p>
          </div>

          <div className="rounded-2xl bg-slate-950/85 border border-slate-800 p-3 backdrop-blur-md space-y-1.5">
            <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400">Verification</span>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {lesson.verification.isVerified
                ? 'The answer is checked by an independent method before it is announced.'
                : 'Verification pending. Treat this result with care.'}
            </p>
          </div>

          <button
            onClick={() => setPracticeOpen(true)}
            className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
          >
            <Target size={14} /> Practice this concept
          </button>
        </div>

        {/* Mobile step chip */}
        <div className="lg:hidden absolute right-3 top-3 z-30 rounded-xl bg-slate-950/85 border border-slate-800 px-3 py-2 backdrop-blur-md">
          <p className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">Step</p>
          <p className="text-[11px] font-bold text-white max-w-[130px] truncate">{currentStep?.title}</p>
        </div>

        {/* Speaking indicator */}
        <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 top-3 z-30 items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 border border-white/15 text-[10px] text-white/80 backdrop-blur-md">
          <span className={`w-2 h-2 rounded-full ${snap.playing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
          {snap.finished
            ? 'Lesson complete'
            : snap.playing
            ? snap.phase === 'write'
              ? 'Teacher is writing'
              : 'Teacher is explaining'
            : 'Paused — press Play, or ask a doubt'}
        </div>
      </main>

      {/* ---------------- VOICE ERROR (error + retry, no substitute voice) ---------------- */}
      {voiceError && (
        <div className="absolute left-1/2 -translate-x-1/2 top-16 z-50 w-[92%] max-w-xl rounded-2xl border-2 border-rose-400 bg-rose-950/95 p-3.5 text-xs text-rose-100 shadow-2xl flex items-start justify-between gap-3">
          <div>
            <p className="font-bold text-white mb-0.5">Teacher voice unavailable</p>
            <p className="leading-relaxed">
              {voiceError} The lesson continues with captions and the blackboard animation — no
              substitute voice is used.
            </p>
            <button
              onClick={async () => {
                const canAttemptAudio = await speechService.checkBackend(true);
                if (!canAttemptAudio) return;
                // A health check alone is not an audio test: replay the current
                // spoken line through ElevenLabs when the backend is reachable.
                if (!voiceOn) {
                  timeline.setVoice(true);
                  setVoiceOn(true);
                }
                timeline.replay();
              }}
              className="mt-2 px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-400 text-white text-[11px] font-bold"
            >
              Retry voice connection
            </button>
          </div>
          <button onClick={() => setVoiceError(null)} className="text-rose-300 hover:text-white font-bold">
            ✕
          </button>
        </div>
      )}

      {/* ---------------- TOAST ---------------- */}
      {toast && (
        <div className="absolute left-1/2 -translate-x-1/2 top-16 z-50 w-[92%] max-w-xl rounded-2xl border-2 border-amber-400 bg-amber-950/95 p-3.5 text-xs text-amber-100 shadow-2xl flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <Sparkles size={15} className="text-amber-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed whitespace-pre-line">{toast}</p>
          </div>
          <button onClick={() => setToast(null)} className="text-amber-300 hover:text-white font-bold">
            ✕
          </button>
        </div>
      )}

      {/* ---------------- CONTROLS ---------------- */}
      <footer className="shrink-0 bg-slate-950/95 border-t border-slate-800 backdrop-blur-xl z-40">
        <div className="h-1.5 bg-slate-800">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-cyan-400 transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        <div className="px-3 sm:px-4 pt-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-2 min-w-0 flex-wrap">
            <button
              onClick={() => setCaptionsOn((c) => !c)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border ${
                captionsOn ? 'bg-slate-800 border-slate-600 text-white' : 'border-slate-800 text-slate-500'
              }`}
            >
              <Captions size={13} /> Captions
            </button>
            <button
              onClick={() => setVoiceOn((v) => !v)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border ${
                voiceOn ? 'bg-slate-800 border-slate-600 text-white' : 'border-slate-800 text-slate-500'
              }`}
            >
              {voiceOn ? <Volume2 size={13} /> : <VolumeX size={13} />} Voice
            </button>
            <div className="flex items-center bg-slate-900 rounded-lg border border-slate-800 p-0.5">
              {SPEEDS.map((s) => (
                <button
                  key={s}
                  onClick={() => changeSpeed(s)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                    speed === s ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => setForce2D((f) => !f)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-slate-800 text-slate-400 hover:text-white"
          >
            <MonitorSmartphone size={13} />
            {force2D ? 'Enable 3D classroom' : 'Lightweight mode'}
          </button>
        </div>

        <div className="px-3 sm:px-4 py-2.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={timeline.prevStep.bind(timeline)}
              className="flex items-center gap-1 px-2.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold hover:text-white"
              title="Previous step"
            >
              <SkipBack size={14} />
              <span className="hidden sm:inline">Prev step</span>
            </button>

            <button
              onClick={togglePlay}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-extrabold text-xs shadow-[0_0_20px_rgba(251,191,36,0.35)]"
            >
              {snap.playing ? <Pause size={15} /> : <Play size={15} />}
              {snap.playing ? 'Pause' : snap.finished ? 'Play again' : snap.index > 0 || snap.phase !== 'write' ? 'Resume' : 'Play'}
            </button>

            <button
              onClick={() => timeline.replay()}
              className="flex items-center gap-1 px-2.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold hover:text-white"
              title="Replay the current line"
            >
              <RotateCcw size={14} />
              <span className="hidden sm:inline">Replay</span>
            </button>

            <button
              onClick={() => timeline.nextStep()}
              className="flex items-center gap-1 px-2.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold hover:text-white"
              title="Next step"
            >
              <span className="hidden sm:inline">Next step</span>
              <SkipForward size={14} />
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={explainSimply}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-amber-300 text-xs font-medium"
            >
              <Sparkles size={13} /> <span className="hidden sm:inline">Explain simply</span>
            </button>

            <button
              onClick={openDoubt}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20"
            >
              <MessageSquare size={14} /> Ask teacher
            </button>

            <button
              onClick={() => setPracticeOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 text-xs font-medium"
            >
              <Target size={13} /> Practice
            </button>

            <button
              onClick={() => setQuizOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white text-xs font-bold"
            >
              <Award size={14} /> <span className="hidden sm:inline">Test me</span>
            </button>
          </div>
        </div>
      </footer>

      {/* ---------------- OVERLAYS ---------------- */}
      <DoubtInterruption
        open={doubtOpen}
        lesson={lesson}
        currentStep={currentStep}
        language={language}
        mode={mode}
        onClose={closeDoubt}
        onExplainSimpler={explainSimply}
      />

      <PracticeModal isOpen={practiceOpen} onClose={() => setPracticeOpen(false)} lesson={lesson} />
      <MasteryQuizModal isOpen={quizOpen} onClose={() => setQuizOpen(false)} lesson={lesson} />

      {summaryOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-4xl max-h-[86vh] bg-slate-900 border border-slate-700 rounded-3xl p-5 overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BookOpen size={18} className="text-amber-400" /> Lesson summary & revision
              </h3>
              <button
                onClick={() => setSummaryOpen(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                Close
              </button>
            </div>
            <LearningSummarySection
              lesson={lesson}
              onOpenFullPractice={() => {
                setSummaryOpen(false);
                setPracticeOpen(true);
              }}
              onOpenMasteryQuiz={() => {
                setSummaryOpen(false);
                setQuizOpen(true);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ClassroomWorkspace;
