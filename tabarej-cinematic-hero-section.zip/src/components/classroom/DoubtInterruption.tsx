import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Send,
  X,
  Sparkles,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Play,
} from 'lucide-react';
import { Language, Lesson, SolutionStep, TeachingMode } from '../../types/math';
import MathView from '../MathView';
import { aiTeacherService } from '../../services/aiTeacherService';
import { speechService } from '../../services/speechService';

interface DoubtInterruptionProps {
  open: boolean;
  lesson: Lesson;
  currentStep: SolutionStep;
  language: Language;
  mode: TeachingMode;
  onClose: () => void;
  onExplainSimpler: () => void;
}

interface Turn {
  id: string;
  who: 'student' | 'teacher';
  text: string;
  latex?: string;
  kind?: 'answer' | 'remediation' | 'check';
}

/**
 * Interruptible tutoring. Pauses the lesson, answers using the current step,
 * points the teacher at the board, then runs a comprehension check. If the
 * check fails the teacher re-teaches the prerequisite with an easier example.
 */
export const DoubtInterruption: React.FC<DoubtInterruptionProps> = ({
  open,
  lesson,
  currentStep,
  language,
  onClose,
  onExplainSimpler,
}) => {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [attempt, setAttempt] = useState(0);

  // comprehension check state
  const [checkAnswer, setCheckAnswer] = useState<number | null>(null);
  const [checkResult, setCheckResult] = useState<'correct' | 'wrong' | null>(null);
  const [followUp, setFollowUp] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const check = currentStep.checkQuestion;

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [turns, checkResult, followUp]);

  useEffect(() => {
    // reset per-step context so the teacher always speaks about THIS step
    setTurns([]);
    setCheckAnswer(null);
    setCheckResult(null);
    setFollowUp(null);
  }, [currentStep.stepNumber]);

  const say = (text: string) => speechService.speak(text, language);

  const ask = async (question: string) => {
    if (!question.trim()) return;
    setTurns((t) => [...t, { id: `s${Date.now()}`, who: 'student', text: question }]);
    setInput('');
    setBusy(true);
    speechService.stop();

    const reply = await aiTeacherService.answerDoubt(lesson, currentStep, question, language, attempt);
    setAttempt((a) => a + 1);
    setTurns((t) => [...t, { id: reply.id, who: 'teacher', text: reply.text, latex: reply.latex, kind: 'answer' }]);
    setBusy(false);
    say(reply.text);
  };

  const submitCheck = (idx: number) => {
    if (!check || checkAnswer !== null) return;
    setCheckAnswer(idx);
    const correct = idx === check.correctIndex;
    setCheckResult(correct ? 'correct' : 'wrong');

    if (correct) {
      say(language === 'hindi' ? 'बहुत बढ़िया! अब हम आगे बढ़ते हैं।' : language === 'english' ? 'Excellent! Let us move on.' : 'Shabash beta! Ab aage chalte hain.');
    } else {
      const rem = aiTeacherService.buildRemediation(lesson, currentStep, language);
      setFollowUp(rem.text);
      say(rem.text);
    }
  };

  const retryDifferentWay = () => {
    onExplainSimpler();
    setFollowUp(null);
    setCheckAnswer(null);
    setCheckResult(null);
  };

  const toggleMic = () => {
    if (listening) {
      speechService.stopSpeechRecognition();
      setListening(false);
      return;
    }
    setListening(true);
    const ok = speechService.startSpeechRecognition(
      language,
      (t) => setInput(t),
      () => setListening(false),
      () => setListening(false),
    );
    if (!ok) setListening(false);
  };

  if (!open) return null;

  const quickPrompts = [
    'Sir, ye step samajh nahi aaya.',
    'Ye number kahan se aaya?',
    'Minus kyun hua?',
    'Formula dobara samjhao.',
    'Ek easy example do.',
    'Hindi mein samjhao.',
    'Mujhe hint do, answer mat batao.',
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center sm:justify-end bg-black/70 backdrop-blur-sm">
      <div className="w-full sm:max-w-md h-[88vh] sm:h-[92vh] bg-slate-900 border border-slate-700 sm:rounded-3xl sm:mr-4 rounded-t-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shrink-0">
              <Sparkles size={17} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Lesson paused · Ask your teacher
              </h3>
              <p className="text-[11px] text-slate-400">
                Step {currentStep.stepNumber} · {currentStep.title}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X size={18} />
          </button>
        </div>

        {/* quick doubts */}
        <div className="px-3 py-2.5 border-b border-slate-800/80 bg-slate-950/40 flex gap-1.5 overflow-x-auto">
          {quickPrompts.map((p) => (
            <button
              key={p}
              onClick={() => ask(p)}
              disabled={busy}
              className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 hover:border-cyan-500/60 hover:text-cyan-300 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>

        {/* transcript */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {turns.length === 0 && (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3.5 space-y-2">
              <div className="text-[10px] font-mono uppercase tracking-widest text-cyan-400">
                Current board line
              </div>
              <div className="py-1.5 text-center rounded-lg bg-black/40 border border-white/10 overflow-x-auto">
                <MathView math={currentStep.equation} displayMode className="text-lg" />
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">{currentStep.whyNecessary}</p>
            </div>
          )}

          {turns.map((t) => (
            <div key={t.id} className={`flex ${t.who === 'student' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[88%] rounded-2xl p-3 text-xs leading-relaxed ${
                  t.who === 'student'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                    : 'bg-slate-800 border border-slate-700 text-slate-200'
                }`}
              >
                <p className="whitespace-pre-line">{t.text}</p>
                {t.latex && (
                  <div className="mt-2 pt-2 border-t border-white/10 overflow-x-auto">
                    <MathView math={t.latex} displayMode className="text-sm" />
                  </div>
                )}
              </div>
            </div>
          ))}

          {busy && (
            <div className="flex items-center gap-2 text-xs text-cyan-300">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Teacher is thinking…
            </div>
          )}

          {/* comprehension check */}
          {check && turns.length > 0 && checkResult === null && (
            <div className="rounded-2xl border border-cyan-500/40 bg-slate-950 p-3.5 space-y-2.5">
              <div className="text-[10px] font-mono uppercase tracking-widest text-cyan-400">
                Quick check before we continue
              </div>
              <p className="text-xs text-slate-200">{check.question}</p>
              <div className="grid grid-cols-2 gap-2">
                {check.options.map((o, i) => (
                  <button
                    key={i}
                    onClick={() => submitCheck(i)}
                    className="p-2 rounded-xl border border-slate-800 bg-slate-900 text-xs text-slate-300 hover:border-cyan-500 hover:text-white transition-colors"
                  >
                    {o}
                  </button>
                ))}
              </div>
            </div>
          )}

          {checkResult === 'correct' && check && (
            <div className="rounded-2xl border border-emerald-500/50 bg-emerald-950/40 p-3 text-xs text-emerald-200 flex items-start gap-2">
              <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
              <span>{check.explanation}</span>
            </div>
          )}

          {checkResult === 'wrong' && check && (
            <div className="rounded-2xl border border-rose-500/50 bg-rose-950/30 p-3 text-xs text-rose-200 flex items-start gap-2">
              <XCircle size={15} className="shrink-0 mt-0.5" />
              <span>{check.explanation}</span>
            </div>
          )}

          {followUp && (
            <div className="rounded-2xl border border-amber-500/50 bg-amber-950/30 p-3.5 space-y-2">
              <div className="text-[10px] font-mono uppercase tracking-widest text-amber-300 flex items-center gap-1.5">
                <Lightbulb size={13} /> Re-teaching the prerequisite
              </div>
              <p className="text-xs text-amber-100 whitespace-pre-line leading-relaxed">{followUp}</p>
              <button
                onClick={retryDifferentWay}
                className="mt-1 w-full py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold hover:bg-amber-400"
              >
                Explain it a different way
              </button>
            </div>
          )}
        </div>

        {/* composer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/90 space-y-2">
          {listening && (
            <div className="text-[11px] text-rose-400 flex items-center gap-1.5 animate-pulse">
              <Mic size={12} /> Listening… speak your doubt
            </div>
          )}
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && ask(input)}
              placeholder="Type or speak your doubt…"
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
            />
            <button
              onClick={toggleMic}
              className={`p-2.5 rounded-xl border ${
                listening
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300 animate-pulse'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              {listening ? <MicOff size={15} /> : <Mic size={15} />}
            </button>
            <button
              onClick={() => ask(input)}
              disabled={!input.trim() || busy}
              className="p-2.5 rounded-xl bg-cyan-500 text-slate-950 disabled:opacity-40"
            >
              <Send size={15} />
            </button>
          </div>

          <button
            onClick={() => {
              speechService.stop();
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold"
          >
            <Play size={14} /> Resume the lesson
          </button>
        </div>
      </div>
    </div>
  );
};

export default DoubtInterruption;
