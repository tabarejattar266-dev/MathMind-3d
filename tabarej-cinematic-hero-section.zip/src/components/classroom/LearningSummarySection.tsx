import React, { useState } from 'react';
import {
  BookOpen,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  Target,
  ArrowRight,
} from 'lucide-react';
import { Lesson } from '../../types/math';
import MathView from '../MathView';

interface LearningSummarySectionProps {
  lesson: Lesson;
  onOpenFullPractice?: () => void;
  onOpenMasteryQuiz?: () => void;
}

export const LearningSummarySection: React.FC<LearningSummarySectionProps> = ({
  lesson,
  onOpenFullPractice,
  onOpenMasteryQuiz,
}) => {
  const [unlockedHints, setUnlockedHints] = useState<Record<string, number>>({});
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [answerFeedback, setAnswerFeedback] = useState<Record<string, 'correct' | 'incorrect'>>({});

  const handleRevealHint = (qId: string) => {
    setUnlockedHints((prev) => ({
      ...prev,
      [qId]: (prev[qId] || 0) + 1,
    }));
  };

  const handleCheckAnswer = (qId: string, actualAnswer: string) => {
    const userVal = (userAnswers[qId] || '').trim().toLowerCase().replace(/\s+/g, '');
    const actualVal = actualAnswer.trim().toLowerCase().replace(/\s+/g, '');

    const isMatch = userVal === actualVal || userVal.includes(actualVal) || actualVal.includes(userVal);
    setAnswerFeedback((prev) => ({
      ...prev,
      [qId]: isMatch ? 'correct' : 'incorrect',
    }));
  };

  return (
    <div className="w-full space-y-6 pt-6 border-t border-slate-800">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 bg-cyan-950/80 px-2.5 py-0.5 rounded border border-cyan-500/30">
            End of Lesson Review
          </span>
          <h3 className="text-xl font-bold text-white mt-1">Learning Summary & Retention</h3>
          <p className="text-xs text-slate-400">
            Solidify the core concepts, avoid common student traps, and practice immediately.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onOpenMasteryQuiz && (
            <button
              type="button"
              onClick={onOpenMasteryQuiz}
              className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs shadow-lg shadow-violet-500/20 transition-all flex items-center gap-1.5"
            >
              <Sparkles size={14} />
              <span>Mastery Quiz</span>
            </button>
          )}
        </div>
      </div>

      {/* Grid of Key Formulas & Common Mistakes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Key Formulas Card */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
            <BookOpen size={16} className="text-cyan-400" />
            <span>Key Formulas to Remember</span>
          </div>

          <div className="space-y-2.5">
            {lesson.formulas.map((f, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-xs font-semibold text-white block">{f.name}</span>
                <div className="py-1">
                  <MathView math={f.latex} displayMode={true} className="text-sm font-bold text-cyan-200" />
                </div>
                <p className="text-[11px] text-slate-400">{f.note}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Common Mistakes & Traps to Avoid */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-rose-300">
            <AlertTriangle size={16} className="text-rose-400" />
            <span>Common Mistakes & Traps to Avoid</span>
          </div>

          <div className="space-y-2">
            {lesson.commonMistakes.map((mistake, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/20 text-xs text-rose-200 flex items-start gap-2.5 leading-relaxed"
              >
                <span className="w-5 h-5 rounded-full bg-rose-900/60 text-rose-300 flex items-center justify-center shrink-0 font-mono text-[10px] mt-0.5">
                  ✕
                </span>
                <span>{mistake}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 3. Important Sign Rules & Short Revision Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Important Sign Rules */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <Sparkles size={16} className="text-amber-400" />
            <span>Important Sign Rules for this Topic</span>
          </div>

          <div className="space-y-2">
            {lesson.importantSignRules.map((rule, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-semibold text-slate-200">{rule.rule}</div>
                  <div className="text-[11px] text-slate-400">{rule.note}</div>
                </div>
                <div className="font-mono text-amber-300 bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-500/30 shrink-0">
                  {rule.example}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Short Revision Summary */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
            <CheckCircle2 size={16} className="text-emerald-400" />
            <span>Short Revision Summary (Key Takeaways)</span>
          </div>

          <ul className="space-y-2 text-xs text-slate-300">
            {lesson.revisionSummary.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2 leading-relaxed">
                <span className="text-emerald-400 font-bold shrink-0">✓</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 4. Integrated Practice Questions (2 to 3 questions) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Target size={18} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">
                Practice Questions (Solve on Rough Copy)
              </h4>
              <p className="text-[11px] text-slate-400">
                Test whether you can calculate without assistance. Progressive hints available!
              </p>
            </div>
          </div>

          {onOpenFullPractice && (
            <button
              type="button"
              onClick={onOpenFullPractice}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
            >
              <span>Practice Mode</span>
              <ArrowRight size={13} />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {lesson.practiceQuestions.map((q, idx) => {
            const hintsRevealed = unlockedHints[q.id] || 0;
            const currentAnswer = userAnswers[q.id] || '';
            const status = answerFeedback[q.id];

            return (
              <div
                key={q.id}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase">
                    Practice Question {idx + 1}
                  </span>
                  {status === 'correct' && (
                    <span className="text-[10px] text-emerald-300 font-bold px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40">
                      Correct ✓
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-200 font-medium">{q.question}</p>

                {q.latex && (
                  <div className="py-1 text-center bg-slate-900/60 rounded-xl border border-slate-800">
                    <MathView math={q.latex} displayMode={true} className="text-base" />
                  </div>
                )}

                {/* Hints */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 flex items-center gap-1">
                      <HelpCircle size={12} className="text-cyan-400" />
                      Hints ({hintsRevealed}/{q.hints.length})
                    </span>
                    {hintsRevealed < q.hints.length && (
                      <button
                        type="button"
                        onClick={() => handleRevealHint(q.id)}
                        className="text-cyan-400 hover:underline"
                      >
                        Reveal Hint {hintsRevealed + 1}
                      </button>
                    )}
                  </div>

                  {q.hints.slice(0, hintsRevealed).map((h, hIdx) => (
                    <div
                      key={hIdx}
                      className="p-2 rounded-lg bg-cyan-950/30 border border-cyan-500/30 text-[11px] text-cyan-200"
                    >
                      💡 {h}
                    </div>
                  ))}
                </div>

                {/* Input Answer */}
                <div className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={currentAnswer}
                    onChange={(e) =>
                      setUserAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                    }
                    placeholder="Enter answer..."
                    className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => handleCheckAnswer(q.id, q.finalAnswer)}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                  >
                    Check
                  </button>
                </div>

                {status === 'correct' && (
                  <div className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">
                    Shabash! {q.explanation}
                  </div>
                )}

                {status === 'incorrect' && (
                  <div className="p-2 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">
                    Not quite. Use a hint or re-calculate: {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default LearningSummarySection;
