import React, { useState } from 'react';
import {
  X,
  Flame,
  CheckCircle,
  TrendingUp,
  BookOpen,
  Bookmark,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { StudentProgress, Lesson } from '../../types/math';
import { progressService } from '../../services/progressService';
import { SAMPLE_LESSONS } from '../../data/sampleLessons';

interface StudentDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLesson: (lesson: Lesson) => void;
}

export const StudentDashboardModal: React.FC<StudentDashboardModalProps> = ({
  isOpen,
  onClose,
  onSelectLesson,
}) => {
  const [progress, setProgress] = useState<StudentProgress>(progressService.getProgress());

  if (!isOpen) return null;

  const handleReset = () => {
    if (window.confirm('Reset all progress and practice statistics?')) {
      const reset = progressService.resetProgress();
      setProgress(reset);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <TrendingUp size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Student Learning Dashboard</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300">
                  Guest Learning Mode
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Track your real mathematical comprehension, streak, and revision topics.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X size={18} />
          </button>
        </div>

        {/* Stats Grid */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                <Flame size={15} />
                <span>Streak</span>
              </div>
              <div className="text-2xl font-bold text-white mt-1">
                {progress.streakDays} <span className="text-xs text-slate-400 font-normal">days</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-medium">
                <BookOpen size={15} />
                <span>Topics Studied</span>
              </div>
              <div className="text-2xl font-bold text-white mt-1">
                {progress.topicsStudied}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                <CheckCircle size={15} />
                <span>Accuracy</span>
              </div>
              <div className="text-2xl font-bold text-emerald-300 mt-1">
                {progress.practiceAccuracy}%
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-violet-400 font-medium">
                <Sparkles size={15} />
                <span>Questions Done</span>
              </div>
              <div className="text-2xl font-bold text-white mt-1">
                {progress.questionsAttempted}
              </div>
            </div>
          </div>

          {/* Mastered Lessons */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle size={14} className="text-emerald-400" />
              Completed & Mastered Lessons ({progress.completedLessonIds.length}):
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SAMPLE_LESSONS.map((l) => {
                const isCompleted = progress.completedLessonIds.includes(l.id);
                return (
                  <div
                    key={l.id}
                    onClick={() => {
                      onSelectLesson(l);
                      onClose();
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isCompleted
                        ? 'bg-emerald-950/20 border-emerald-500/40 hover:border-emerald-400'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-white">{l.title}</div>
                      <div className="text-[10px] text-slate-400">{l.topic}</div>
                    </div>
                    {isCompleted ? (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-900/60 border border-emerald-500/50 text-emerald-300 font-bold">
                        Mastered ✓
                      </span>
                    ) : (
                      <span className="text-[10px] text-cyan-400 hover:underline">
                        Start →
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Weak Topics / Areas for Revision */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                <Bookmark size={14} />
                Topics Recommended for Revision:
              </span>
              <span className="text-[10px] text-slate-400">Based on quiz responses</span>
            </div>
            <div className="flex flex-wrap gap-2 pt-1">
              {progress.weakTopics.map((topic, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs"
                >
                  ⚡ {topic}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-300 transition-colors"
          >
            <RotateCcw size={12} />
            <span>Reset Progress Data</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors"
          >
            Close Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboardModal;
