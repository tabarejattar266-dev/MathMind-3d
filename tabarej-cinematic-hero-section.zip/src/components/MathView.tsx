import React, { useMemo } from 'react';
import katex from 'katex';

interface MathViewProps {
  math: string;
  displayMode?: boolean;
  className?: string;
  highlightClass?: string;
}

export const MathView: React.FC<MathViewProps> = ({
  math,
  displayMode = false,
  className = '',
  highlightClass = '',
}) => {
  const html = useMemo(() => {
    if (!math) return '';
    try {
      // Clean up common input quirks
      const cleanMath = math.trim();
      return katex.renderToString(cleanMath, {
        displayMode,
        throwOnError: false,
        output: 'html',
        trust: false,
        strict: false,
      });
    } catch (err) {
      console.warn('KaTeX render error:', err);
      return `<span class="text-rose-400 font-mono text-xs">${math}</span>`;
    }
  }, [math, displayMode]);

  return (
    <span
      className={`inline-block ${displayMode ? 'w-full text-center my-1' : ''} ${highlightClass} ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export default MathView;
