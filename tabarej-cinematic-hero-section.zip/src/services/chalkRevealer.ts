/**
 * chalkRevealer
 * -------------
 * Progressive chalk writing for KaTeX output.
 *
 * KaTeX renders a formula as many small leaf <span>s (one per symbol, plus
 * fraction bars, bracket strokes, spacing). We:
 *   1. collect the leaves in reading order (row by row, left to right),
 *   2. reveal them with a clip-path whose right edge sweeps across each symbol
 *      as the chalk passes over it,
 *   3. report the exact screen point of the chalk tip so the 2D chalk tip and
 *      the 3D teacher's arm can follow the writing.
 *
 * Bracket / fraction strokes are revealed with the overall progress of the line
 * (they are drawn while the expression is being written).
 */

export interface ChalkLeaf {
  el: HTMLElement;
  w: number;
  text: string;
  cx: number;
  cy: number;
}

interface Built {
  texts: ChalkLeaf[];
  strokes: HTMLElement[];
  total: number;
}

const cache = new WeakMap<Element, Built>();

const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);

const hostOf = (root: Element): Element => root.querySelector('.katex-html') ?? root;

const build = (host: Element): Built => {
  const spans = Array.from(host.querySelectorAll<HTMLElement>('span')).filter(
    (s) => s.children.length === 0 && !s.classList.contains('strut') && !s.classList.contains('pstrut'),
  );

  const boxes = spans.map((el) => ({
    el,
    r: el.getBoundingClientRect(),
    text: (el.textContent ?? '').trim(),
  }));

  const heights = boxes
    .filter((b) => b.text && b.r.height > 0)
    .map((b) => b.r.height)
    .sort((a, b) => a - b);
  const medH = heights.length ? heights[Math.floor(heights.length / 2)] : 12;

  const texts: ChalkLeaf[] = [];
  const strokes: HTMLElement[] = [];

  for (const b of boxes) {
    const isStroke = !b.text && (b.r.height > 1.6 * medH || b.r.width > 2.5 * Math.max(b.r.height, 0.5));
    if (isStroke) {
      strokes.push(b.el);
    } else {
      texts.push({
        el: b.el,
        w: Math.max(b.r.width, 1),
        text: b.text,
        cx: b.r.left + b.r.width / 2,
        cy: b.r.top + b.r.height / 2,
      });
    }
  }

  // Reading order: group into rows by vertical centre, then left to right.
  texts.sort((p, q) => p.cy - q.cy);
  const tol = medH * 0.6;
  const rows: ChalkLeaf[][] = [];
  for (const l of texts) {
    const row = rows[rows.length - 1];
    const rowCy = row ? row.reduce((s, x) => s + x.cy, 0) / row.length : 0;
    if (row && Math.abs(l.cy - rowCy) <= tol) row.push(l);
    else rows.push([l]);
  }
  const ordered = rows.flatMap((r) => r.sort((p, q) => p.cx - q.cx));
  const total = ordered.reduce((s, l) => s + l.w, 0) || 1;

  return { texts: ordered, strokes, total };
};

const getBuilt = (root: Element): Built => {
  const host = hostOf(root);
  let b = cache.get(host);
  if (!b) {
    b = build(host);
    cache.set(host, b);
  }
  return b;
};

const setClip = (el: HTMLElement, local: number) => {
  const v =
    local >= 0.999
      ? ''
      : local <= 0.001
      ? 'inset(0 100% 0 0)'
      : `inset(-0.3em ${((1 - local) * 100).toFixed(1)}% -0.3em -0.3em)`;
  if (el.style.clipPath !== v) {
    el.style.clipPath = v;
    (el.style as any).webkitClipPath = v;
  }
};

export const centerOf = (el: HTMLElement) => {
  const r = el.getBoundingClientRect();
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
};

/**
 * Reveal a rendered line up to `p` (0..1). Returns the chalk-tip point on screen.
 */
export const revealChalkLine = (root: Element, p: number): { point: { x: number; y: number } } | null => {
  const built = getBuilt(root);
  const prog = clamp01(p);
  const target = prog * built.total;

  let acc = 0;
  let front: ChalkLeaf | null = null;
  let frontLocal = 0;

  for (const l of built.texts) {
    const local = clamp01((target - acc) / l.w);
    acc += l.w;
    setClip(l.el, local);
    if (local > 0) {
      front = l;
      frontLocal = local;
    }
  }
  for (const s of built.strokes) setClip(s, prog);

  const pick = front ?? built.texts[0] ?? null;
  if (!pick) return null;

  const r = pick.el.getBoundingClientRect();
  const local = front ? frontLocal : 0;
  return { point: { x: r.left + r.width * local, y: r.top + r.height * 0.5 } };
};

/**
 * Find the first occurrence of each token (e.g. "a", "e") in a written line and
 * return those symbol elements so they can be highlighted.
 */
export const highlightLeaves = (root: Element, tokens: string[]): HTMLElement[] => {
  const built = getBuilt(root);
  const used = new Set<ChalkLeaf>();
  const out: HTMLElement[] = [];
  for (const tok of tokens) {
    const hit = built.texts.find((l) => !used.has(l) && l.text === tok);
    if (hit) {
      used.add(hit);
      out.push(hit.el);
    }
  }
  return out;
};
