import { buildDet3BoardScript } from './boardScript';
import {
  BoardColor,
  BoardLine,
  CalculationLine,
  Lesson,
  LessonCue,
  MathAnimationSpec,
  SolutionStep,
  TeachingStage,
} from '../types/math';
import {
  det2,
  det3Breakdown,
  Det3Breakdown,
  p,
  sarrusVerificationLatex,
  solveLinear,
  solveQuadratic,
} from './mathVerifier';

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const N = (hinglish: string, hindi: string, english: string) => ({ hinglish, hindi, english });
const NB = (hinglish: string, hindi: string, english: string) => ({ hinglish, hindi, english });

const L = (id: string, latex: string, color: BoardColor = 'chalk', label?: string): BoardLine => ({
  id,
  latex,
  color,
  label,
});

const vmatrix2 = (m: number[][]) =>
  String.raw`\begin{vmatrix} ${p(m[0][0])} & ${p(m[0][1])} \\ ${p(m[1][0])} & ${p(m[1][1])} \end{vmatrix}`;

const vmatrix3 = (m: number[][]) =>
  String.raw`\begin{vmatrix} ${p(m[0][0])} & ${p(m[0][1])} & ${p(m[0][2])} \\ ${p(m[1][0])} & ${p(m[1][1])} & ${p(m[1][2])} \\ ${p(m[2][0])} & ${p(m[2][1])} & ${p(m[2][2])} \end{vmatrix}`;



interface StepSpec {
  title: string;
  stage: TeachingStage;
  equation: string;
  operation: string;
  whyNecessary: string;
  ruleUsed: string;
  cues: LessonCue[];
  calculationLines?: CalculationLine[];
  checkQuestion?: SolutionStep['checkQuestion'];
  simplerExplanation?: SolutionStep['simplerExplanation'];
  realLifeAnalogy?: SolutionStep['realLifeAnalogy'];
  remediation?: SolutionStep['remediation'];
}

interface LessonSkeleton {
  id: string;
  title: string;
  topic: string;
  subtopic: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  originalQuestion: string;
  latexExpression: string;
  boardTitle: string;
  teacherIntro: Lesson['teacherIntro'];
  quickReminder: Lesson['quickReminder'];
  prerequisites: string[];
  formulas: Lesson['formulas'];
  steps: StepSpec[];
  finalAnswerSummary: Lesson['finalAnswerSummary'];
  verification: Lesson['verification'];
  animationType: Lesson['animationType'];
  animationInitialParams: Record<string, any>;
  commonMistakes: string[];
  importantSignRules: Lesson['importantSignRules'];
  revisionSummary: string[];
  practiceQuestions: Lesson['practiceQuestions'];
  masteryQuiz: Lesson['masteryQuiz'];
}

const assemble = (s: LessonSkeleton): Lesson => {
  const steps: SolutionStep[] = s.steps.map((st, idx) => ({
    stepNumber: idx + 1,
    title: st.title,
    stage: st.stage,
    equation: st.equation,
    operation: st.operation,
    whyNecessary: st.whyNecessary,
    ruleUsed: st.ruleUsed,
    speechText: st.cues[0]?.narration ?? N('', '', ''),
    simplerExplanation: st.simplerExplanation,
    realLifeAnalogy: st.realLifeAnalogy,
    calculationLines: st.calculationLines,
    checkQuestion: st.checkQuestion,
    remediation: st.remediation,
    cues: st.cues.map((c) => ({ ...c, stepIndex: idx })),
  }));

  const cues: LessonCue[] = steps.flatMap((st) => st.cues ?? []);

  return {
    id: s.id,
    title: s.title,
    topic: s.topic,
    subtopic: s.subtopic,
    difficulty: s.difficulty,
    originalQuestion: s.originalQuestion,
    latexExpression: s.latexExpression,
    boardTitle: s.boardTitle,
    imageUrl: undefined,
    teacherIntro: s.teacherIntro,
    quickReminder: s.quickReminder,
    prerequisites: s.prerequisites,
    formulas: s.formulas,
    steps,
    cues,
    finalAnswerSummary: s.finalAnswerSummary,
    verification: s.verification,
    animationType: s.animationType,
    animationInitialParams: s.animationInitialParams,
    commonMistakes: s.commonMistakes,
    importantSignRules: s.importantSignRules,
    revisionSummary: s.revisionSummary,
    practiceQuestions: s.practiceQuestions,
    masteryQuiz: s.masteryQuiz,
    pausedPrompt: N(
      'Koi jaldi nahi hai beta. Jab ready ho jao, Play dabao — main wahi se continue karunga.',
      'कोई जल्दी नहीं है। जब तैयार हो जाओ, Play दबाओ — मैं वहीं से आगे बढ़ूंगा।',
      'No hurry. When you are ready, press Play and I will continue from this exact line.',
    ),
  };
};

/* ------------------------------------------------------------------ */
/* 3×3 DETERMINANT LESSON                                              */
/* ------------------------------------------------------------------ */

const buildDeterminant3LessonBase = (matrix: number[][]): Lesson => {
  const B: Det3Breakdown = det3Breakdown(matrix);
  const {
    a, b, c, d, e, f, g, h, i,
    minor11, minor12, minor13,
    minor11Latex,
    term1, term2, term3,
    det,
    sarrusDet,
    verified,
  } = B;

  const hasNegatives = [a, b, c, d, e, f, g, h, i].some((n) => n < 0);

  const steps: StepSpec[] = [];

  /* ---------- STEP 1 : Understand the question ---------- */
  steps.push({
    title: 'Understand the Question',
    stage: 'question',
    equation: String.raw`\Delta = ${vmatrix3(matrix)}`,
    operation: 'Read the question aloud and identify what must be found',
    whyNecessary: 'A student must know exactly what is asked before touching a formula.',
    ruleUsed: 'Reading comprehension of the problem statement',
    simplerExplanation: N(
      'Board par ek 3 guna 3 ka box bana hai. Is box ki ek value hoti hai jise determinant kehte hain. Humein wahi value nikalni hai.',
      'बोर्ड पर 3x3 का एक बॉक्स बना है। इस बॉक्स की एक संख्या होती है जिसे सारणिक कहते हैं। हमें वही संख्या निकालनी है।',
      'There is a 3 by 3 box on the board. This box has one special number called its determinant. Our job is to find that number.',
    ),
    realLifeAnalogy: N(
      'Determinant ka use engineering mein system solve karne, computer graphics mein area rotate karne aur physics mein equations solve karne mein hota hai.',
      'सारणिक का उपयोग इंजीनियरिंग में समीकरण हल करने और कंप्यूटर ग्राफिक्स में क्षेत्र घुमाने में होता है।',
      'Determinants are used to solve systems of equations in engineering and to rotate shapes in computer graphics.',
    ),
    cues: [
      {
        id: 'd3-q1',
        stepIndex: 0,
        stage: 'question',
        narration: N(
          `Chalo beta, tension mat lo. Sabse pehle board par diye gaye question ko dhyan se dekho. Humein is three-by-three determinant ki value find karni hai.`,
          `चलो बच्चों, घबराओ मत। सबसे पहले बोर्ड पर दिए गए प्रश्न को ध्यान से देखिए। हमें इस 3x3 सारणिक का मान ज्ञात करना है।`,
          `Let's begin, and do not worry. First look carefully at the question on the board. We have to find the value of this three-by-three determinant.`,
        ),
        beginnerNote: NB(
          'Dekho, ye ek bixa hai jisme nau numbers hain. Humein in nau numbers se ek single answer nikalna hai.',
          'देखो, यह एक बक्सा है जिसमें नौ संख्याएँ हैं। हमें इन नौ संख्याओं से एक उत्तर निकालना है।',
          'Look, this is a box with nine numbers. From these nine numbers we will produce a single answer.',
        ),
        boardAppend: [
          L('title', String.raw`\textbf{Topic: Determinant of a } 3 \times 3 \textbf{ matrix}`, 'yellow'),
          L('question', String.raw`Q. \ \ Find \ \Delta = ${vmatrix3(matrix)}`, 'chalk', 'Question'),
        ],
        focus: 'question',
        gesture: 'explain',
        camera: 'teacher',
        animation: { kind: 'point_terms', operands: ['3 × 3 matrix'], label: 'Read the question' },
        minMs: 5200,
      },
      {
        id: 'd3-q2',
        stepIndex: 0,
        stage: 'question',
        narration: N(
          `Iska matlab humein ek hi number chahiye. Ye number batata hai ki ye teen vector kitna space gher rahe hain. Chalo ab basic se samjhte hain.`,
          `इसका मतलब हमें केवल एक संख्या चाहिए। यह संख्या बताती है कि ये तीन सदिश कितना स्थान घेरते हैं। अब बुनियादी से समझते हैं।`,
          `That means we need exactly one number. It tells us how much space these three vectors enclose. Now let us build the basics first.`,
        ),
        boardAppend: [L('find', String.raw`\text{Required: a single number } \Delta \in \mathbb{R}`, 'cyan')],
        focus: 'question',
        gesture: 'point',
        camera: 'board',
        animation: { kind: 'point_terms', operands: ['rows', 'columns'], label: 'What must be found' },
      },
    ],
    checkQuestion: {
      question: 'How many numbers are inside this determinant?',
      options: ['3', '6', '9', '27'],
      correctIndex: 2,
      explanation: `A 3×3 determinant has 3 rows × 3 columns = 9 entries.`,
    },
    remediation: {
      title: 'Rows and columns',
      explanation:
        'A matrix is read row by row (left to right) and column by column (top to bottom). Row 1 is the top line, column 1 is the left line.',
      easierExample: 'A 2×2 box has 2 rows and 2 columns, so 4 numbers in total.',
      easierExampleLatex: String.raw`\begin{pmatrix} 1 & 2 \\ 3 & 4 \end{pmatrix} \Rightarrow 2 \text{ rows}, 2 \text{ columns}`,
    },
  });

  /* ---------- STEP 2 : Basics ---------- */
  steps.push({
    title: 'Learn the Basics First (2×2 warm-up)',
    stage: 'basics',
    equation: String.raw`\begin{vmatrix} 1 & 2 \\ 3 & 4 \end{vmatrix} = (1)(4) - (2)(3) = 4 - 6 = -2`,
    operation: 'Explain the determinant idea with a tiny 2×2 example',
    whyNecessary: 'The 3×3 expansion is built entirely out of 2×2 determinants, so we master that first.',
    ruleUsed: '2×2 determinant: ad − bc',
    simplerExplanation: N(
      'Chhote box mein hum tirochhi line ke numbers multiply karte hain: pehli tirochhi line ka product, minus doosri tirochhi line ka product.',
      'छोटे बॉक्स में हम तिरछी रेखा की संख्याएँ गुणा करते हैं: पहली तिरछी रेखा का गुणनफल, इसमें से दूसरी तिरछी रेखा का गुणनफल घटाते हैं।',
      'In a small box we multiply along the diagonals: the first diagonal product minus the second diagonal product.',
    ),
    cues: [
      {
        id: 'd3-b1',
        stepIndex: 1,
        stage: 'basics',
        narration: N(
          `Pehle ek bahut chhota example karte hain, taaki concept pakka ho jaye. Do guna do ke box mein determinant nikalne ka rule hai: pehla diagonal minus doosra diagonal.`,
          `पहले एक बहुत छोटा उदाहरण करते हैं ताकि अवधारणा स्पष्ट हो जाए। 2x2 बॉक्स का नियम है: पहला विकर्ण घटाव दूसरा विकर्ण।`,
          `Let us take a very small example first so the idea becomes solid. For a 2 by 2 box the rule is: first diagonal minus second diagonal.`,
        ),
        boardAppend: [
          L('warm', String.raw`\text{Warm-up: } ${vmatrix2([[1, 2], [3, 4]])} = (1)(4) - (2)(3)`, 'chalk'),
        ],
        focus: 'formula',
        gesture: 'point',
        camera: 'board',
        animation: {
          kind: 'multiply',
          operands: ['1', '4'],
          result: '4',
          label: 'Main diagonal: 1 × 4',
          note: 'Multiply top-left with bottom-right',
        },
      },
      {
        id: 'd3-b2',
        stepIndex: 1,
        stage: 'basics',
        narration: N(
          `To four minus six hota hai minus two. Dekho, do numbers ka multiply karke hum ek number tak pahunche. Yehi kaam bade box mein bhi karna hai.`,
          `तो 4 में से 6 घटाने पर −2 आता है। देखो, दो संख्याओं को गुणा करके हम एक संख्या तक पहुँचे। यही काम बड़े बॉक्स में भी करना है।`,
          `So four minus six gives minus two. Notice we multiplied two numbers and reached one number. That is exactly what we will do in the big box.`,
        ),
        boardAppend: [L('warm2', String.raw`\phantom{=} = 4 - 6 = \mathbf{-2}`, 'emerald')],
        focus: 'formula',
        gesture: 'write',
        camera: 'board',
        animation: {
          kind: 'subtract',
          operands: ['4', '6'],
          result: '-2',
          label: '4 − 6 = −2',
          note: 'Subtract the second diagonal product',
          sign: 'negative',
        },
        minMs: 4600,
      },
    ],
    calculationLines: [
      { label: 'Warm-up 2×2 determinant', latex: '(1)(4)-(2)(3) = -2', note: 'ad − bc with a=1,b=2,c=3,d=4' },
    ],
    checkQuestion: {
      question: 'What is the value of the warm-up determinant | 1 2 ; 3 4 | ?',
      options: ['+2', '−2', '10', '−10'],
      correctIndex: 1,
      explanation: '(1)(4) − (2)(3) = 4 − 6 = −2.',
    },
    remediation: {
      title: 'Multiplying and subtracting integers',
      explanation:
        'Multiplication first, subtraction second (BODMAS). A minus sign in front of a bracket flips every sign inside it.',
      easierExample: '2 × 3 − 5 = 6 − 5 = 1',
      easierExampleLatex: String.raw`2 \times 3 - 5 = 6 - 5 = 1`,
    },
  });

  if (hasNegatives) {
    steps.push({
      title: 'Sign Rules You Must Not Miss',
      stage: 'basics',
      equation: String.raw`(-1)\times(-2) = +2, \qquad 0 - (+2) = -2, \qquad 3 - (-4) = 3 + 4 = 7`,
      operation: 'Explain negative-sign behaviour before any calculation',
      whyNecessary: 'Almost every wrong determinant answer comes from a sign slip, so we fix it in advance.',
      ruleUsed: 'Integer sign rules',
      simplerExplanation: N(
        'Minus ka minus plus hota hai. Aur bracket ke aage minus ho to bracket ke andar ke saare sign palat jaate hain.',
        'ऋणात्मक का ऋणात्मक धनात्मक होता है। और कोष्ठक के आगे ऋण हो तो अंदर के सभी चिह्न बदल जाते हैं।',
        'Negative times negative is positive. And a minus in front of a bracket flips every sign inside that bracket.',
      ),
      cues: [
        {
          id: 'd3-s1',
          stepIndex: 2,
          stage: 'basics',
          narration: N(
            `Ab dhyan se: is question mein negative numbers bhi hain. Yaad rakho, minus into minus barabar plus hota hai.`,
            `अब ध्यान से: इस प्रश्न में ऋणात्मक संख्याएँ भी हैं। याद रखो, ऋण गुणा ऋण बराबर धन होता है।`,
            `Now pay attention: this question contains negative numbers. Remember, negative multiplied by negative gives positive.`,
          ),
          boardAppend: [
            L('sign1', String.raw`\text{Sign rule 1: } (-)(-) = (+), \quad (+)(-) = (-)`, 'yellow'),
          ],
          focus: 'formula',
          gesture: 'emphasize',
          camera: 'board',
          animation: {
            kind: 'sign_flip',
            operands: ['-1', '-2'],
            result: '+2',
            label: 'Minus × Minus = Plus',
            sign: 'positive',
          },
        },
        {
          id: 'd3-s2',
          stepIndex: 2,
          stage: 'basics',
          narration: N(
            `Aur jab bracket ke saamne minus lagta hai, to bracket ke andar ka sign badal jata hai. Isliye zero minus do, ban jata hai minus two.`,
            `और जब कोष्ठक के सामने ऋण लगता है, तो अंदर का चिह्न बदल जाता है। इसलिए 0 − (+2) बन जाता है −2।`,
            `And when a minus sits in front of a bracket, the sign inside flips. That is why 0 − (+2) becomes −2.`,
          ),
          boardAppend: [
            L('sign2', String.raw`\text{Sign rule 2: } -(-k) = +k, \qquad 0 - (+2) = -2`, 'yellow'),
          ],
          focus: 'formula',
          gesture: 'emphasize',
          camera: 'board',
          animation: {
            kind: 'sign_flip',
            operands: ['0', '+2'],
            result: '-2',
            label: '0 − (+2) = −2',
            sign: 'negative',
          },
          minMs: 4600,
        },
      ],
      calculationLines: [
        { label: 'Sign rule', latex: '(-1)(-2)=+2', note: 'Product of two negatives' },
        { label: 'Bracket flip', latex: '0-(+2)=-2', note: 'Minus in front of a bracket' },
      ],
      checkQuestion: {
        question: 'What is 5 − (−3) ?',
        options: ['2', '8', '−8', '−2'],
        correctIndex: 1,
        explanation: 'Subtracting a negative adds: 5 + 3 = 8.',
      },
      remediation: {
        title: 'Minus in front of a bracket',
        explanation:
          '−(a − b) = −a + b. The minus multiplies everything inside the bracket, so each sign flips once.',
        easierExample: '−(4 − 6) = −4 + 6 = +2',
        easierExampleLatex: String.raw`-(4-6) = -4+6 = +2`,
      },
    });
  }

  /* ---------- STEP 3 : Formula ---------- */
  steps.push({
    title: 'Write the Formula on the Board',
    stage: 'formula',
    equation: String.raw`\Delta = a(ei - fh) - b(di - fg) + c(dh - eg)`,
    operation: 'Write the Laplace expansion formula and explain each block',
    whyNecessary: 'The formula converts one big problem into three tiny 2×2 problems.',
    ruleUsed: 'Laplace (cofactor) expansion along row 1',
    simplerExplanation: N(
      'Formula teen hisson ka bana hai. Pehle number, phir uske niche ki chhoti 2x2 value, aur beech mein plus-minus ka pattern plus, minus, plus.',
      'सूत्र तीन भागों का बना है। पहले संख्या, फिर उसके नीचे की छोटी 2x2 संख्या, और बीच में +, −, + का क्रम।',
      'The formula has three blocks. A top number, the small 2×2 value under it, and the sign pattern plus, minus, plus.',
    ),
    cues: [
      {
        id: 'd3-f1',
        stepIndex: steps.length,
        stage: 'formula',
        narration: N(
          `Ab main board par formula likhta hoon. Isse Laplace expansion kehte hain. Dhyan se dekho, beech wale term ke aage minus lagta hai.`,
          `अब मैं बोर्ड पर सूत्र लिखता हूँ। इसे लाप्लास विस्तार कहते हैं। ध्यान से देखिए, बीच वाले पद के आगे ऋण चिह्न है।`,
          `Now I write the formula on the board. This is called Laplace expansion. Look carefully: the middle term carries a minus sign.`,
        ),
        boardAppend: [
          L(
            'formula',
            String.raw`\Delta = a(ei-fh) - b(di-fg) + c(dh-eg)`,
            'yellow',
            'Laplace expansion',
          ),
        ],
        focus: 'formula',
        gesture: 'write',
        camera: 'board',
        animation: {
          kind: 'point_terms',
          operands: ['a(ei−fh)', '− b(di−fg)', '+ c(dh−eg)'],
          label: 'Three blocks',
          note: 'Signs are +, −, +',
        },
        minMs: 6200,
      },
      {
        id: 'd3-f2',
        stepIndex: steps.length,
        stage: 'formula',
        narration: N(
          `Har bade number ke saath uske niche ki chhoti 2x2 value multiply hoti hai. Yeh chhoti value nikaalne ke liye hum us number ki row aur column ko kaat dete hain.`,
          `प्रत्येक बड़ी संख्या के साथ उसके नीचे की छोटी 2x2 संख्या गुणी होती है। वह छोटी संख्या निकालने के लिए हम उस संख्या की पंक्ति और स्तंभ काट देते हैं।`,
          `Each top number is multiplied by the small 2×2 value below it. To get that small value we delete the row and column of that number.`,
        ),
        boardAppend: [
          L(
            'formula2',
            String.raw`\text{Minor} = \text{delete the row \& column of that element} \Rightarrow 2\times 2 \text{ box}`,
            'chalk',
          ),
        ],
        focus: 'formula',
        gesture: 'point',
        camera: 'board',
        highlightTerms: ['ei', 'fh', 'di', 'fg', 'dh', 'eg'],
        animation: {
          kind: 'point_terms',
          operands: ['ei', 'fh'],
          label: 'Inside each bracket: a 2×2 determinant',
        },
      },
    ],
    calculationLines: [
      { label: 'Formula', latex: String.raw`\Delta = a(ei-fh)-b(di-fg)+c(dh-eg)`, note: 'Signs +, −, +' },
    ],
    checkQuestion: {
      question: 'Which sign sits in front of the middle term b?',
      options: ['+ (plus)', '− (minus)', '× (multiply)', 'No sign'],
      correctIndex: 1,
      explanation: 'The cofactor sign pattern along row 1 is +, −, + so the b term is subtracted.',
    },
    remediation: {
      title: 'Checkerboard sign pattern',
      explanation:
        'Cofactor signs follow (−1)^(row+col). Row 1 therefore gives +, −, +. Forgetting this is the number one cause of wrong answers.',
      easierExample: 'For a 2×2: signs are + and −, giving ad − bc.',
      easierExampleLatex: String.raw`+\!\begin{vmatrix}a&b\\c&d\end{vmatrix}\;\Rightarrow\; ad-bc`,
    },
  });

  /* ---------- STEP 4 : Values ---------- */
  steps.push({
    title: 'Identify Every Value',
    stage: 'values',
    equation: String.raw`a=${p(a)},\ b=${p(b)},\ c=${p(c)},\ d=${p(d)},\ e=${p(e)},\ f=${p(f)},\ g=${p(g)},\ h=${p(h)},\ i=${p(i)}`,
    operation: 'Name each matrix entry before substituting',
    whyNecessary: 'Substituting a wrong position produces a wrong answer that looks correct.',
    ruleUsed: 'Position labelling a…i',
    simplerExplanation: N(
      'Pehli row ke numbers ko hum a, b, c bolte hain. Doosri row ko d, e, f. Teesri row ko g, h, i.',
      'पहली पंक्ति की संख्याओं को a, b, c कहते हैं। दूसरी पंक्ति को d, e, f। तीसरी पंक्ति को g, h, i।',
      'We call the first row entries a, b, c. The second row d, e, f. The third row g, h, i.',
    ),
    cues: [
      {
        id: 'd3-v1',
        stepIndex: steps.length,
        stage: 'values',
        narration: N(
          `Ab board par matrix ke saare numbers ko naam dete hain. Pehli row mein a barabar ${a}, b barabar ${b}, c barabar ${c}.`,
          `अब बोर्ड पर मैट्रिक्स की सभी संख्याओं को नाम देते हैं। पहली पंक्ति में a = ${a}, b = ${b}, c = ${c}।`,
          `Now let us name every entry on the board. In the first row we have a = ${a}, b = ${b} and c = ${c}.`,
        ),
        boardAppend: [
          L('vals1', String.raw`a=${p(a)},\quad b=${p(b)},\quad c=${p(c)}`, 'cyan', 'Row 1'),
        ],
        focus: 'values',
        gesture: 'point',
        camera: 'board',
        animation: { kind: 'substitute', operands: [`a=${a}`, `b=${b}`, `c=${c}`], label: 'Row 1 values' },
      },
      {
        id: 'd3-v2',
        stepIndex: steps.length,
        stage: 'values',
        narration: N(
          `Doosri row mein d barabar ${d}, e barabar ${e}, f barabar ${f}. Aur teesri row mein g barabar ${g}, h barabar ${h}, i barabar ${i}.`,
          `दूसरी पंक्ति में d = ${d}, e = ${e}, f = ${f}। और तीसरी पंक्ति में g = ${g}, h = ${h}, i = ${i}।`,
          `In the second row d = ${d}, e = ${e}, f = ${f}. And in the third row g = ${g}, h = ${h}, i = ${i}.`,
        ),
        boardAppend: [
          L('vals2', String.raw`d=${p(d)},\quad e=${p(e)},\quad f=${p(f)}`, 'cyan', 'Row 2'),
          L('vals3', String.raw`g=${p(g)},\quad h=${p(h)},\quad i=${p(i)}`, 'cyan', 'Row 3'),
        ],
        focus: 'values',
        gesture: 'point',
        camera: 'board',
        animation: {
          kind: 'substitute',
          operands: [`d=${d}`, `e=${e}`, `f=${f}`, `g=${g}`, `h=${h}`, `i=${i}`],
          label: 'Row 2 and Row 3 values',
        },
      },
    ],
    calculationLines: [
      { label: 'Row 1', latex: `a=${p(a)},\\ b=${p(b)},\\ c=${p(c)}`, note: 'Carries signs +, −, +' },
      { label: 'Row 2', latex: `d=${p(d)},\\ e=${p(e)},\\ f=${p(f)}`, note: 'Inside the minors' },
      { label: 'Row 3', latex: `g=${p(g)},\\ h=${p(h)},\\ i=${p(i)}`, note: 'Inside the minors' },
    ],
    checkQuestion: {
      question: 'Which letter holds the value in row 2, column 3?',
      options: ['e', 'f', 'h', 'i'],
      correctIndex: 1,
      explanation: `Row 2 is d, e, f so row 2 column 3 is f = ${f}.`,
    },
    remediation: {
      title: 'Reading positions',
      explanation: 'Always say the row first, then the column. Row 2 column 3 means second line, third number.',
      easierExample: 'In [[7,8],[9,10]], row 2 column 1 is 9.',
      easierExampleLatex: String.raw`\begin{pmatrix}7&8\\9&10\end{pmatrix}\Rightarrow r_2c_1 = 9`,
    },
  });

  /* ---------- STEP 5 : Substitute ---------- */
  steps.push({
    title: 'Substitute the Values into the Formula',
    stage: 'solve',
    equation: String.raw`\Delta = ${p(a)}(${p(e)}${p(i)} - ${p(f)}${p(h)}) - ${p(b)}(${p(d)}${p(i)} - ${p(f)}${p(g)}) + ${p(c)}(${p(d)}${p(h)} - ${p(e)}${p(g)})`,
    operation: 'Replace every letter with its number',
    whyNecessary: 'Substitution must be perfect; a single misplaced number ruins the whole expansion.',
    ruleUsed: 'Direct substitution',
    simplerExplanation: N(
      'Ab har letter ki jagah uska number rakh dete hain. Kuch bhi calculate nahi karna, sirf replace karna hai.',
      'अब हर अक्षर के स्थान पर उसकी संख्या रख देते हैं। अभी कुछ भी हल नहीं करना, केवल प्रतिस्थापित करना है।',
      `Now we place each number in place of its letter. No calculating yet, only replacing.`,
    ),
    cues: [
      {
        id: 'd3-su1',
        stepIndex: steps.length,
        stage: 'solve',
        narration: N(
          `Ab dhyan se substitution karte hain. Har letter ki jagah uska number rakh do. Kuch calculate mat karo, sirf replace karo.`,
          `अब ध्यान से प्रतिस्थापन करते हैं। हर अक्षर के स्थान पर उसकी संख्या रख दो। अभी गणना नहीं करनी, केवल बदलना है।`,
          `Now substitute carefully. Put each number in place of its letter. Do not calculate yet, only replace.`,
        ),
        boardAppend: [
          L(
            'sub',
            String.raw`\Delta = ${p(a)}{\color{#fbbf24}(${p(e)}\cdot${p(i)} - ${p(f)}\cdot${p(h)})} - ${p(b)}{\color{#60a5fa}(${p(d)}\cdot${p(i)} - ${p(f)}\cdot${p(g)})} + ${p(c)}{\color{#4ade80}(${p(d)}\cdot${p(h)} - ${p(e)}\cdot${p(g)})}`,
            'chalk',
            'Substitution',
          ),
        ],
        focus: 'solve',
        gesture: 'write',
        camera: 'board',
        animation: {
          kind: 'substitute',
          operands: [`a→${a}`, `e→${e}`, `i→${i}`, `b→${b}`, `d→${d}`, `f→${f}`, `g→${g}`, `h→${h}`],
          label: 'Replacing letters with numbers',
        },
        minMs: 6400,
      },
    ],
    calculationLines: [
      {
        label: 'Substituted expression',
        latex: String.raw`\Delta = ${p(a)}(${p(e)}${p(i)} - ${p(f)}${p(h)}) - ${p(b)}(${p(d)}${p(i)} - ${p(f)}${p(g)}) + ${p(c)}(${p(d)}${p(h)} - ${p(e)}${p(g)})`,
        note: 'Three coloured blocks = three minors',
      },
    ],
    checkQuestion: {
      question: 'In the substituted line, which pair sits inside the first bracket?',
      options: [`${d} and ${f}`, `${e} and ${i}`, `${g} and ${h}`, `${b} and ${c}`],
      correctIndex: 1,
      explanation: `The first minor uses e and i with f and h, i.e. ${e},${i},${f},${h}.`,
    },
    remediation: {
      title: 'Substitution discipline',
      explanation: 'Replace one letter at a time and keep every number inside its own bracket. Never merge brackets early.',
      easierExample: 'If a=2, e=3, i=4, f=1 then a(ei−fh) = 2(3×4 − 1×1).',
      easierExampleLatex: String.raw`2(3\cdot4 - 1\cdot1) = 2(12-1)`,
    },
  });

  /* ---------- MINOR STEPS ---------- */
  const minorStep = (
    stepIndexHint: number,
    which: 1 | 2 | 3,
    coeff: number,
    sign: '+' | '-',
    innerLatex: string,
    minorValue: number,
    termValue: number,
    label: string,
    operands: string[],
  ): StepSpec => {
    const signNote =
      sign === '-'
        ? N(
            `Dhyan do, is term ke aage minus lagta hai, isliye ${p(coeff)} ko minus ke saath likhenge.`,
            `ध्यान दो, इस पद के आगे ऋण है, इसलिए ${p(coeff)} को ऋण के साथ लिखेंगे।`,
            `Be careful: this term carries a minus, so we write ${coeff} with a negative sign.`,
          )
        : N(
            `Is term ke aage plus hai, to sign nahi badlega.`,
            `इस पद के आगे धन है, तो चिह्न नहीं बदलेगा।`,
            `This term carries a plus, so the sign will not change.`,
          );

    return {
      title: `${label}: compute the 2×2 minor, then multiply`,
      stage: 'solve',
      equation: `${sign === '-' ? '-' : ''}${p(coeff)}${innerLatex} = ${p(termValue)}`,
      operation: `Minor ${which}: ${innerLatex.replace(/\\[a-z]+/g, '')} then multiply by ${coeff}`,
      whyNecessary:
        'Each minor is an independent 2×2 calculation. Doing them one at a time prevents sign chaos.',
      ruleUsed: '2×2 determinant ad − bc, then scalar multiplication',
      simplerExplanation: N(
        'Chhote box ke char numbers ko cross multiply karo: pehla pair ka product minus doosre pair ka product.',
        'छोटे बॉक्स की चार संख्याओं को क्रॉस गुणा करो: पहले जोड़े का गुणनफल घटाव दूसरे जोड़े का गुणनफल।',
        'Cross multiply the four numbers of the small box: first pair product minus second pair product.',
      ),
      cues: [
        {
          id: `d3-m${which}-a`,
          stepIndex: stepIndexHint,
          stage: 'solve',
          narration: N(
            `Ab pehla minor. Chhote box ke cross products: ${innerLatex.replace(/\\/g, '')}. Iska answer ${minorValue} aata hai.`,
            `अब यह माइनर। छोटे बॉक्स के क्रॉस गुणनफल देखिए। इसका उत्तर ${minorValue} आता है।`,
            `Now this minor. Cross multiply inside the small box. Its value comes out to ${minorValue}.`,
          ),
          boardAppend: [
            L(
              `minor${which}`,
              String.raw`M_{${which}} = ${innerLatex} = ${p(minorValue)}`,
              'chalk',
              `Minor ${which}`,
            ),
          ],
          focus: 'solve',
          gesture: 'write',
          camera: 'board',
          animation: {
            kind: 'multiply',
            operands,
            result: String(minorValue),
            label: `Minor ${which} = ${minorValue}`,
            note: 'Cross multiply then subtract',
            sign: minorValue < 0 ? 'negative' : 'positive',
          },
          minMs: 5600,
        },
        {
          id: `d3-m${which}-b`,
          stepIndex: stepIndexHint,
          stage: 'solve',
          narration: signNote,
          boardAppend: [
            L(
              `term${which}`,
              String.raw`\text{Term }${which} = ${sign === '-' ? '-' : ''}${p(coeff)} \times ${p(minorValue)} = ${p(termValue)}`,
              minorValue < 0 || sign === '-' ? 'rose' : 'emerald',
              `Term ${which}`,
            ),
          ],
          focus: 'solve',
          gesture: 'emphasize',
          camera: 'board',
          animation: {
            kind: 'multiply',
            operands: [`${sign === '-' ? '−' : ''}${coeff}`, String(minorValue)],
            result: String(termValue),
            label: `Term ${which} = ${termValue}`,
            note: sign === '-' ? 'Minus sign applied' : 'Plus sign kept',
            sign: termValue < 0 ? 'negative' : 'positive',
          },
          minMs: 5200,
        },
      ],
      calculationLines: [
        { label: `Minor ${which}`, latex: innerLatex + ` = ${p(minorValue)}`, note: '2×2 expansion' },
        {
          label: `Term ${which}`,
          latex: `${sign === '-' ? '-' : ''}${p(coeff)}\\times${p(minorValue)} = ${p(termValue)}`,
          note: sign === '-' ? 'Negative cofactor sign' : 'Positive cofactor sign',
          highlightColor: minorValue < 0 || sign === '-' ? '#f87171' : '#4ade80',
        },
      ],
      checkQuestion: {
        question: `What is the value of minor ${which}?`,
        options: [String(minorValue), String(-minorValue), String(coeff), String(termValue)],
        correctIndex: 0,
        explanation: `${innerLatex.replace(/\\/g, '')} = ${minorValue}.`,
      },
      remediation: {
        title: 'Computing a 2×2 minor',
        explanation: 'For a small box [[p, q],[r, s]] the value is p×s − q×r. Multiply the corners first, then subtract.',
        easierExample: '[[2, 3],[1, 5]] → 2×5 − 3×1 = 10 − 3 = 7.',
        easierExampleLatex: String.raw`\begin{vmatrix}2&3\\1&5\end{vmatrix} = 2\cdot5 - 3\cdot1 = 7`,
      },
    };
  };

  steps.push(
    minorStep(
      steps.length,
      1,
      a,
      '+',
      String.raw`(${p(e)}${p(i)} - ${p(f)}${p(h)})`,
      minor11,
      term1,
      `First term (a = ${a})`,
      [`${e}×${i}`, `${f}×${h}`],
    ),
  );

  steps.push(
    minorStep(
      steps.length + 1,
      2,
      b,
      '-',
      String.raw`(${p(d)}${p(i)} - ${p(f)}${p(g)})`,
      minor12,
      term2,
      `Second term (b = ${b})`,
      [`${d}×${i}`, `${f}×${g}`],
    ),
  );

  steps.push(
    minorStep(
      steps.length + 2,
      3,
      c,
      '+',
      String.raw`(${p(d)}${p(h)} - ${p(e)}${p(g)})`,
      minor13,
      term3,
      `Third term (c = ${c})`,
      [`${d}×${h}`, `${e}×${g}`],
    ),
  );

  /* ---------- Combine ---------- */
  const sumLatex = `${p(term1)} ${term2 < 0 ? '-' : '+'} ${Math.abs(term2)} ${term3 < 0 ? '-' : '+'} ${Math.abs(term3)}`;
  const running1 = term1;
  const running2 = term1 - term2;
  const running3 = running2 + term3;

  steps.push({
    title: 'Combine the Three Terms',
    stage: 'solve',
    equation: String.raw`\Delta = ${sumLatex} = ${det}`,
    operation: `Add the signed terms: ${term1}, ${term2}, ${term3}`,
    whyNecessary: 'Only now do we add, because every term already carries its own sign.',
    ruleUsed: 'Addition of signed integers',
    simplerExplanation: N(
      'Teeno terms ko apne apne sign ke saath jodo. Bas itna hi — determinant mil gaya.',
      'तीनों पदों को अपने-अपने चिह्न के साथ जोड़ो। बस इतना ही — सारणिक मिल गया।',
      'Add the three terms with their own signs. That is all — the determinant is ready.',
    ),
    cues: [
      {
        id: 'd3-c1',
        stepIndex: steps.length,
        stage: 'solve',
        narration: N(
          `Ab teeno terms ko jodte hain: ${term1}, phir ${term2}, phir ${term3}. Har number apna sign lekar aayega.`,
          `अब तीनों पदों को जोड़ते हैं: ${term1}, फिर ${term2}, फिर ${term3}। हर संख्या अपना चिह्न लेकर आएगी।`,
          `Now add the three terms: ${term1}, then ${term2}, then ${term3}. Each number brings its own sign.`,
        ),
        boardAppend: [
          L('sum1', String.raw`\Delta = ${p(term1)} ${term2 < 0 ? '-' : '+'} ${Math.abs(term2)} ${term3 < 0 ? '-' : '+'} ${Math.abs(term3)}`, 'chalk', 'Combine'),
          L('sum2', String.raw`\phantom{\Delta} = ${p(running1)} ${term2 < 0 ? '-' : '+'} ${Math.abs(term2)} = ${p(running2)}`, 'chalk'),
        ],
        focus: 'solve',
        gesture: 'write',
        camera: 'board',
        animation: {
          kind: 'sum',
          operands: [String(term1), String(term2)],
          result: String(running2),
          label: `${term1} ${term2 < 0 ? '−' : '+'} ${Math.abs(term2)} = ${running2}`,
        },
        minMs: 5400,
      },
      {
        id: 'd3-c2',
        stepIndex: steps.length,
        stage: 'solve',
        narration: N(
          `Aur ${running2} mein se ${Math.abs(term3)} ${term3 < 0 ? 'ghatane' : 'jodne'} par final answer ${det} milta hai.`,
          `और ${running2} में ${Math.abs(term3)} ${term3 < 0 ? 'घटाने' : 'जोड़ने'} पर अंतिम उत्तर ${det} मिलता है।`,
          `And ${running2} ${term3 < 0 ? 'minus' : 'plus'} ${Math.abs(term3)} gives the final answer ${det}.`,
        ),
        boardAppend: [
          L('sum3', String.raw`\phantom{\Delta} = ${p(running2)} ${term3 < 0 ? '-' : '+'} ${Math.abs(term3)} = \mathbf{${p(det)}}`, 'emerald'),
        ],
        focus: 'solve',
        gesture: 'emphasize',
        camera: 'board',
        animation: {
          kind: 'reveal_answer',
          operands: [String(running2), String(term3)],
          result: String(det),
          label: `Determinant = ${det}`,
          sign: det < 0 ? 'negative' : 'positive',
        },
        minMs: 5600,
      },
    ],
    calculationLines: [
      { label: 'Signed sum', latex: sumLatex, note: 'Terms already carry their signs' },
      { label: 'Step 1', latex: `${p(running1)} ${term2 < 0 ? '-' : '+'} ${Math.abs(term2)} = ${p(running2)}`, note: 'First two terms' },
      { label: 'Final', latex: `${p(running2)} ${term3 < 0 ? '-' : '+'} ${Math.abs(term3)} = ${p(det)}`, note: 'Determinant value', isResult: true, highlightColor: '#4ade80' },
    ],
    checkQuestion: {
      question: `What is ${term1} ${term2 < 0 ? '−' : '+'} ${Math.abs(term2)} ${term3 < 0 ? '−' : '+'} ${Math.abs(term3)} ?`,
      options: [String(det), String(-det), String(term1 + term2), String(term3)],
      correctIndex: 0,
      explanation: `${running1} → ${running2} → ${running3} = ${det}.`,
    },
    remediation: {
      title: 'Adding signed numbers',
      explanation: 'Same signs add and keep the sign. Different signs subtract and keep the sign of the bigger number.',
      easierExample: '−4 − 21 = −25, then −25 − 2 = −27.',
      easierExampleLatex: String.raw`-4-21-2 = -27`,
    },
  });

  /* ---------- Verify ---------- */
  steps.push({
    title: 'Verify With an Independent Method (Sarrus Rule)',
    stage: 'verify',
    equation: String.raw`\Delta_{\text{Sarrus}} = ${sarrusDet} = \Delta_{\text{cofactor}} \;\checkmark`,
    operation: 'Recompute using the Sarrus rule and compare',
    whyNecessary: 'Two different methods agreeing is the strongest evidence the answer is correct.',
    ruleUsed: 'Sarrus rule (diagonal products)',
    simplerExplanation: N(
      'Sarrus rule mein hum teen tirochhi line ka product jodte hain aur doosri tirochhi line ka product minus karte hain. Dono ka answer same aana chahiye.',
      'सैरस नियम में हम तीन तिरछी रेखाओं के गुणनफल जोड़ते हैं और दूसरी दिशा के गुणनफल घटाते हैं। दोनों उत्तर समान होने चाहिए।',
      'In the Sarrus rule we add the three downward diagonal products and subtract the three upward ones. Both methods must agree.',
    ),
    cues: [
      {
        id: 'd3-ver1',
        stepIndex: steps.length,
        stage: 'verify',
        narration: N(
          `Ab hum answer ko doosre method se check karenge — Sarrus rule. Achhi aadat hai, kyunki calculation ka mistake turant pakda jata hai.`,
          `अब हम उत्तर को दूसरी विधि से जाँचेंगे — सैरस नियम। यह अच्छी आदत है क्योंकि गणना की गलती तुरंत पकड़ में आ जाती है।`,
          `Now we check the answer with a second method — the Sarrus rule. It is a good habit because arithmetic slips get caught immediately.`,
        ),
        boardAppend: [
          L('ver0', String.raw`\textbf{Verification (Sarrus rule):}`, 'yellow'),
          L('ver1', String.raw`\Delta = aei + bfg + cdh - ceg - bdi - afh`, 'chalk'),
        ],
        focus: 'verify',
        gesture: 'write',
        camera: 'board',
        animation: { kind: 'point_terms', operands: ['aei', 'bfg', 'cdh'], label: 'Downward diagonals' },
        minMs: 5400,
      },
      {
        id: 'd3-ver2',
        stepIndex: steps.length,
        stage: 'verify',
        narration: N(
          `Dono methods se ${sarrusDet} hi aaya. Matlab hamara answer ${det} bilkul sahi hai. Great work beta!`,
          `दोनों विधियों से ${sarrusDet} ही आया। इसका मतलब हमारा उत्तर ${det} बिल्कुल सही है। बहुत बढ़िया!`,
          `Both methods give ${sarrusDet}. That confirms our answer ${det} is correct. Excellent work!`,
        ),
        boardAppend: [
          L('ver2', sarrusVerificationLatex(B), 'chalk'),
          L(
            'ver3',
            verified
              ? String.raw`\therefore \Delta = ${p(det)} \quad \text{(verified by 2 independent methods)} \;\checkmark`
              : String.raw`\text{Methods disagree — recheck required!}`,
            'emerald',
          ),
        ],
        focus: 'verify',
        gesture: 'emphasize',
        camera: 'teacher',
        animation: {
          kind: 'reveal_answer',
          operands: [String(det), String(sarrusDet)],
          result: verified ? 'MATCH ✓' : 'MISMATCH',
          label: verified ? `Verified: Δ = ${det}` : 'Verification failed',
          sign: det < 0 ? 'negative' : 'positive',
        },
        minMs: 6200,
      },
    ],
    calculationLines: [
      { label: 'Sarrus positive', latex: `${p(a)}${p(e)}${p(i)} + ${p(b)}${p(f)}${p(g)} + ${p(c)}${p(d)}${p(h)}`, note: 'Downward diagonals' },
      { label: 'Sarrus negative', latex: `${p(c)}${p(e)}${p(g)} + ${p(b)}${p(d)}${p(i)} + ${p(a)}${p(f)}${p(h)}`, note: 'Upward diagonals' },
      { label: 'Comparison', latex: `${sarrusDet} = ${det}`, note: verified ? 'Independent methods agree' : 'Mismatch — must recheck', isResult: true, highlightColor: '#4ade80' },
    ],
    checkQuestion: {
      question: 'Why do we verify with a second method?',
      options: [
        'To make the lesson longer',
        'Because a second independent method confirms the arithmetic is correct',
        'Because Sarrus rule is always easier',
        'It is not necessary at all',
      ],
      correctIndex: 1,
      explanation: 'Independent verification is the only reliable way to be sure no arithmetic slip occurred.',
    },
    remediation: {
      title: 'Why verify?',
      explanation:
        'A single long calculation can hide one sign slip. A second, structurally different method gives independent evidence.',
      easierExample: 'Check 24 ÷ 6 by multiplying back: 6 × 4 = 24 ✓.',
      easierExampleLatex: String.raw`24 \div 6 = 4 \;\Rightarrow\; 6 \times 4 = 24 \;\checkmark`,
    },
  });

  /* ---------- Practice ---------- */
  const pm: number[][] = [
    [matrix[0][0] + 1, matrix[0][1], matrix[0][2]],
    [matrix[1][0], matrix[1][1] + 2, matrix[1][2]],
    [matrix[2][0], matrix[2][1], matrix[2][2] + 1],
  ];
  const pDet = det3Breakdown(pm).det;

  steps.push({
    title: 'Your Turn — Solve a Similar Question',
    stage: 'practice',
    equation: String.raw`\Delta = ${vmatrix3(pm)} = \ ?`,
    operation: 'Independent practice with the same method',
    whyNecessary: 'Understanding is only proven when the student can repeat the method alone.',
    ruleUsed: 'Same Laplace expansion method',
    simplerExplanation: N(
      'Ab tum khud karo. Pehle minor nikaalo, phir sign lagao, phir jodo. Main hint dunga, answer nahi.',
      'अब तुम स्वयं करो। पहले माइनर निकालो, फिर चिह्न लगाओ, फिर जोड़ो। मैं संकेत दूंगा, उत्तर नहीं।',
      'Now you try it yourself. First the minors, then the signs, then the sum. I will give hints, not the answer.',
    ),
    cues: [
      {
        id: 'd3-pr1',
        stepIndex: steps.length,
        stage: 'practice',
        narration: N(
          `Ab tumhari baari. Ye naya determinant board par likha hai. Pehle teen minors nikaalo, phir signs lagao, phir jodo. Jab answer aa jaye, Practice button daba kar check karna.`,
          `अब तुम्हारी बारी। यह नया सारणिक बोर्ड पर लिखा है। पहले तीन माइनर निकालो, फिर चिह्न लगाओ, फिर जोड़ो। उत्तर आने पर Practice बटन दबाकर जाँच करो।`,
          `Now it is your turn. This new determinant is on the board. Find the three minors, apply the signs, then add. Check yourself with the Practice button.`,
        ),
        boardAppend: [
          L('practice', String.raw`\textbf{Your turn: } \Delta = ${vmatrix3(pm)}`, 'yellow'),
          L('practice2', String.raw`\text{Hint: signs are } +,\ -,\ + \text{ and minors are } 2\times2 \text{ boxes}`, 'chalk'),
        ],
        focus: 'practice',
        gesture: 'wave',
        camera: 'students',
        animation: {
          kind: 'point_terms',
          operands: ['Minor 1', 'Minor 2', 'Minor 3'],
          label: 'Same method, new numbers',
        },
        minMs: 6200,
      },
    ],
    calculationLines: [{ label: 'Practice question', latex: String.raw`\Delta = ${vmatrix3(pm)}`, note: 'Use the same method' }],
  });

  const practiceLatex = String.raw`\Delta = ${vmatrix3(pm)}`;

  return assemble({
    id: `det3-${matrix.flat().join('-')}`,
    title: '3×3 Determinant — Full Classroom Lesson',
    topic: 'Matrices and Determinants',
    subtopic: 'Laplace expansion along row 1, sign handling and independent verification',
    difficulty: 'Intermediate',
    originalQuestion: `Find the value of the determinant ${matrix.map((r) => `[${r.join(', ')}]`).join(' ')}`,
    latexExpression: String.raw`\Delta = ${vmatrix3(matrix)}`,
    boardTitle: 'Determinant of a 3×3 Matrix',
    teacherIntro: N(
      'Namaste beta! Aaj hum determinant ka poora concept board par samjhenge. Main ek-ek line likhkar bataunga ki wo kyun likhi.',
      'नमस्ते बच्चों! आज हम सारणिक की पूरी अवधारणा बोर्ड पर समझेंगे। मैं एक-एक पंक्ति लिखकर बताऊँगा कि वह क्यों लिखी।',
      'Hello! Today we will build the whole determinant concept on the board. I will write each line and explain why it is written.',
    ),
    quickReminder: {
      formulaName: 'Laplace Expansion along Row 1',
      formulaLatex: String.raw`\det(A) = a(ei-fh) - b(di-fg) + c(dh-eg)`,
      coloredFormulaLatex: String.raw`\Delta = {\color{#fbbf24}a(ei-fh)} - {\color{#60a5fa}b(di-fg)} + {\color{#4ade80}c(dh-eg)}`,
      symbols: [
        { symbol: 'a, b, c', meaning: 'Row 1 entries — they carry the signs +, −, +', color: '#fbbf24', position: 'Row 1' },
        { symbol: 'd, e, f', meaning: 'Row 2 entries — used inside the minors', color: '#60a5fa', position: 'Row 2' },
        { symbol: 'g, h, i', meaning: 'Row 3 entries — used inside the minors', color: '#4ade80', position: 'Row 3' },
        { symbol: 'ei − fh', meaning: `First 2×2 minor = ${minor11}`, color: '#f59e0b', position: 'Minor M₁₁' },
      ],
      signRules: [
        { rule: 'Cofactor signs', example: '+ a, − b, + c', note: 'Checkerboard pattern (−1)^(row+col)' },
        { rule: 'Minus of a negative', example: '−(−k) = +k', note: 'Bracket minus flips the sign inside' },
        { rule: 'Negative × Negative', example: '(−1)×(−2) = +2', note: 'Product of two negatives is positive' },
      ],
    },
    prerequisites: [
      '2×2 determinant rule: ad − bc',
      'Sign rules for multiplying and subtracting integers',
      'Reading matrix positions as row, column',
    ],
    formulas: [
      {
        name: 'Laplace expansion along row 1',
        latex: String.raw`\det(A) = a\begin{vmatrix}e&f\\h&i\end{vmatrix} - b\begin{vmatrix}d&f\\g&i\end{vmatrix} + c\begin{vmatrix}d&e\\g&h\end{vmatrix}`,
        note: 'Delete the row and column of each element to obtain its 2×2 minor.',
      },
      {
        name: 'Sarrus rule (verification)',
        latex: String.raw`\Delta = aei + bfg + cdh - ceg - bdi - afh`,
        note: 'Independent second method used to confirm the cofactor result.',
      },
    ],
    steps,
    finalAnswerSummary: {
      resultLatex: String.raw`\Delta = ${p(det)}`,
      resultValue: String(det),
      verificationNote: verified
        ? `Cofactor expansion and the independent Sarrus rule both give ${det}, so the result is confirmed.`
        : 'The two methods disagreed, so this result must be rechecked before it is trusted.',
      verificationLatex: String.raw`${p(det)} = ${p(sarrusDet)} \;\checkmark`,
    },
    verification: {
      method: 'Sarrus rule (independent of cofactor expansion)',
      latex: sarrusVerificationLatex(B),
      isVerified: verified,
      explanation: verified
        ? `Both methods return ${det}; the arithmetic is confirmed.`
        : `Cofactor gives ${det} but Sarrus gives ${sarrusDet}; the discrepancy must be resolved.`,
      sanityCheck: `Terms: ${term1}, ${term2}, ${term3}. Minors: ${minor11}, ${minor12}, ${minor13}.`,
    },
    animationType: 'matrix_determinant_3x3',
    animationInitialParams: { matrix, step: 1 },
    commonMistakes: [
      `Writing + ${p(b)}(...) instead of − ${p(b)}(...) — the middle cofactor sign is negative.`,
      `Sign slip inside a minor, e.g. writing ${minor11Latex} = ${-minor11} instead of ${minor11}.`,
      'Adding the three terms before each term has been multiplied by its own cofactor sign.',
    ],
    importantSignRules: [
      { rule: 'Cofactor pattern', example: '+, −, +', note: 'Row 1 signs' },
      { rule: 'Minus × Minus', example: `(${p(e)})×(${p(i)})`, note: 'Watch the actual signs in this question' },
      { rule: 'Bracket minus', example: `0 − (+2) = −2`, note: 'The minus flips the bracket' },
    ],
    revisionSummary: [
      'Determinant of a 3×3 expands into three 2×2 minors.',
      'Row 1 entries carry cofactor signs +, −, +.',
      'Each minor is computed as (corner product) − (other corner product).',
      'Add the three signed terms only at the end.',
      'Always verify with Sarrus rule or a different row/column expansion.',
    ],
    practiceQuestions: [
      {
        id: 'pq-det3-a',
        question: 'Evaluate the practice determinant shown on the board.',
        latex: practiceLatex,
        hints: [
          'Write the three 2×2 minors first, without multiplying by a, b, c yet.',
          'Apply the cofactor signs +, −, + to the three terms.',
          'Add the signed terms only at the very end.',
        ],
        finalAnswer: String(pDet),
        explanation: `Using the same Laplace expansion on the new matrix gives Δ = ${pDet}.`,
      },
      {
        id: 'pq-det3-b',
        question: `If every entry of the original matrix is multiplied by 2, what happens to the determinant?`,
        latex: String.raw`\det(2A) = 2^3\det(A)`,
        hints: ['A 3×3 matrix has 3 rows.', 'Each row multiplication contributes a factor of 2.'],
        finalAnswer: String(8 * det),
        explanation: `det(2A) = 2³·det(A) = 8 × ${det} = ${8 * det}.`,
      },
    ],
    masteryQuiz: [
      {
        id: 'qz-det3-a',
        question: 'What is the correct sign pattern when expanding along row 1?',
        options: ['+, +, +', '+, −, +', '−, +, −', '+, −, −'],
        correctAnswer: 1,
        explanation: 'Cofactor signs follow (−1)^(row+col), giving +, −, + in row 1.',
      },
      {
        id: 'qz-det3-b',
        question: `The first minor of this matrix equals which value?`,
        options: [String(minor11), String(-minor11), String(minor12), String(a)],
        correctAnswer: 0,
        explanation: `${minor11Latex} = ${minor11}.`,
      },
      {
        id: 'qz-det3-c',
        question: `Why is verification by Sarrus rule valuable here?`,
        options: [
          'It is faster than cofactor expansion',
          'It is a structurally different method, so agreement confirms the arithmetic',
          'It removes the need for signs',
          'It always gives a positive answer',
        ],
        correctAnswer: 1,
        explanation: 'Agreement between two different methods is strong evidence of correctness.',
      },
    ],
  });
};

/* ------------------------------------------------------------------ */
/* 2×2 DETERMINANT LESSON                                              */
/* ------------------------------------------------------------------ */

export const buildDeterminant2Lesson = (matrix: number[][]): Lesson => {
  const a = matrix[0][0], b = matrix[0][1], c = matrix[1][0], d = matrix[1][1];
  const ad = a * d;
  const bc = b * c;
  const det = det2(matrix);
  const verified = det === ad - bc;

  const steps: StepSpec[] = [
    {
      title: 'Understand the Question',
      stage: 'question',
      equation: String.raw`\Delta = ${vmatrix2(matrix)}`,
      operation: 'Read the question and identify what is required',
      whyNecessary: 'Know the target before applying any rule.',
      ruleUsed: 'Problem comprehension',
      cues: [
        {
          id: 'd2-q1',
          stepIndex: 0,
          stage: 'question',
          narration: N(
            `Chalo beta, board par ek do guna do ka determinant bana hai. Humein iski ek hi value nikalni hai.`,
            `चलो बच्चों, बोर्ड पर 2x2 का सारणिक बना है। हमें इसकी एक ही संख्या निकालनी है।`,
            `Let us begin. On the board there is a two by two determinant. We must find its single value.`,
          ),
          boardAppend: [
            L('t', String.raw`\textbf{Topic: Determinant of a } 2\times2 \textbf{ matrix}`, 'yellow'),
            L('q', String.raw`Q.\ \Delta = ${vmatrix2(matrix)}`, 'chalk', 'Question'),
          ],
          focus: 'question',
          gesture: 'explain',
          camera: 'teacher',
          animation: { kind: 'point_terms', operands: ['2 × 2'], label: 'Four entries, one answer' },
          minMs: 5000,
        },
      ],
      checkQuestion: {
        question: 'How many entries does this determinant have?',
        options: ['2', '4', '6', '8'],
        correctIndex: 1,
        explanation: 'A 2×2 matrix has four entries.',
      },
    },
    {
      title: 'Basics: Diagonals of a 2×2',
      stage: 'basics',
      equation: String.raw`\Delta = ad - bc`,
      operation: 'Explain the two diagonals',
      whyNecessary: 'The whole rule is two diagonal products and one subtraction.',
      ruleUsed: 'ad − bc',
      simplerExplanation: N(
        'Ek tirchhi line top-left se bottom-right tak jaati hai, doosri top-right se bottom-left tak.',
        'एक तिरछी रेखा ऊपर-बाएँ से नीचे-दाएँ जाती है, दूसरी ऊपर-दाएँ से नीचे-बाएँ।',
        'One diagonal runs top-left to bottom-right, the other top-right to bottom-left.',
      ),
      cues: [
        {
          id: 'd2-b1',
          stepIndex: 1,
          stage: 'basics',
          narration: N(
            `Pehle rule samjho: pehla diagonal multiply karo, usme se doosra diagonal minus kar do.`,
            `पहले नियम समझो: पहला विकर्ण गुणा करो, उसमें से दूसरा विकर्ण घटा दो।`,
            `First the rule: multiply the main diagonal, then subtract the other diagonal.`,
          ),
          boardAppend: [L('f', String.raw`\Delta = ad - bc`, 'yellow', 'Rule')],
          focus: 'formula',
          gesture: 'point',
          camera: 'board',
          animation: { kind: 'point_terms', operands: ['ad', 'bc'], label: 'Two diagonal products' },
          minMs: 4800,
        },
      ],
      checkQuestion: {
        question: 'In ad − bc, which entries form the second product?',
        options: ['a and d', 'b and c', 'a and b', 'c and d'],
        correctIndex: 1,
        explanation: 'The anti-diagonal uses b (top-right) and c (bottom-left).',
      },
      remediation: {
        title: 'Diagonals',
        explanation: 'Main diagonal: top-left to bottom-right. Anti-diagonal: top-right to bottom-left.',
        easierExample: 'In [[1,2],[3,4]]: main diagonal 1,4 and anti-diagonal 2,3.',
        easierExampleLatex: String.raw`\begin{vmatrix}1&2\\3&4\end{vmatrix} \Rightarrow 1\cdot4 - 2\cdot3`,
      },
    },
    {
      title: 'Substitute the Values',
      stage: 'values',
      equation: String.raw`\Delta = ${p(a)}\times${p(d)} - ${p(b)}\times${p(c)}`,
      operation: 'Name a, b, c, d and substitute',
      whyNecessary: 'Correct mapping prevents diagonal mix-ups.',
      ruleUsed: 'Position labelling',
      cues: [
        {
          id: 'd2-v1',
          stepIndex: 2,
          stage: 'values',
          narration: N(
            `Yahan a barabar ${a}, b barabar ${b}, c barabar ${c} aur d barabar ${d} hai.`,
            `यहाँ a = ${a}, b = ${b}, c = ${c} और d = ${d} है।`,
            `Here a = ${a}, b = ${b}, c = ${c} and d = ${d}.`,
          ),
          boardAppend: [
            L('v', String.raw`a=${p(a)},\ b=${p(b)},\ c=${p(c)},\ d=${p(d)}`, 'cyan'),
            L('s', String.raw`\Delta = ${p(a)}\times${p(d)} - ${p(b)}\times${p(c)}`, 'chalk', 'Substituted'),
          ],
          focus: 'values',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'substitute', operands: [`a=${a}`, `b=${b}`, `c=${c}`, `d=${d}`], label: 'Substitution' },
        },
      ],
      calculationLines: [{ label: 'Substitution', latex: `${p(a)}\\times${p(d)} - ${p(b)}\\times${p(c)}`, note: 'Replace letters' }],
    },
    {
      title: 'Calculate Both Products',
      stage: 'solve',
      equation: String.raw`${p(a)}\times${p(d)} = ${p(ad)}, \qquad ${p(b)}\times${p(c)} = ${p(bc)}`,
      operation: 'Compute the two diagonal products separately',
      whyNecessary: 'Separate products make the subtraction unambiguous.',
      ruleUsed: 'Integer multiplication',
      cues: [
        {
          id: 'd2-s1',
          stepIndex: 3,
          stage: 'solve',
          narration: N(
            `Pehla product: ${a} into ${d} barabar ${ad}.`,
            `पहला गुणनफल: ${a} × ${d} = ${ad}।`,
            `The first product: ${a} times ${d} equals ${ad}.`,
          ),
          boardAppend: [L('p1', String.raw`${p(a)}\times${p(d)} = ${p(ad)}`, 'emerald', 'Main diagonal')],
          focus: 'solve',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'multiply', operands: [String(a), String(d)], result: String(ad), label: `${a} × ${d} = ${ad}` },
        },
        {
          id: 'd2-s2',
          stepIndex: 3,
          stage: 'solve',
          narration: N(
            `Doosra product: ${b} into ${c} barabar ${bc}.`,
            `दूसरा गुणनफल: ${b} × ${c} = ${bc}।`,
            `The second product: ${b} times ${c} equals ${bc}.`,
          ),
          boardAppend: [L('p2', String.raw`${p(b)}\times${p(c)} = ${p(bc)}`, 'rose', 'Anti-diagonal')],
          focus: 'solve',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'multiply', operands: [String(b), String(c)], result: String(bc), label: `${b} × ${c} = ${bc}`, sign: bc < 0 ? 'negative' : 'positive' },
        },
      ],
      calculationLines: [
        { label: 'Main diagonal', latex: `${p(a)}\\times${p(d)}=${p(ad)}`, note: 'ad' },
        { label: 'Anti-diagonal', latex: `${p(b)}\\times${p(c)}=${p(bc)}`, note: 'bc' },
      ],
    },
    {
      title: 'Subtract and Finish',
      stage: 'solve',
      equation: String.raw`\Delta = ${p(ad)} - (${p(bc)}) = ${p(det)}`,
      operation: `Subtract: ${ad} − (${bc}) = ${det}`,
      whyNecessary: 'The bracket keeps the sign of the second product explicit.',
      ruleUsed: 'Subtraction of signed numbers',
      cues: [
        {
          id: 'd2-f1',
          stepIndex: 4,
          stage: 'solve',
          narration: N(
            `Ab ${ad} mein se ${p(bc)} minus karte hain. Answer aata hai ${det}.`,
            `अब ${ad} में से ${p(bc)} घटाते हैं। उत्तर आता है ${det}।`,
            `Now subtract ${bc} from ${ad}. The answer is ${det}.`,
          ),
          boardAppend: [
            L('r1', String.raw`\Delta = ${p(ad)} - (${p(bc)}) = ${p(ad - bc)}`, 'chalk'),
            L('r2', String.raw`\phantom{\Delta} = \mathbf{${p(det)}}`, 'emerald'),
          ],
          focus: 'solve',
          gesture: 'emphasize',
          camera: 'board',
          animation: { kind: 'subtract', operands: [String(ad), String(bc)], result: String(det), label: `${ad} − (${bc}) = ${det}`, sign: det < 0 ? 'negative' : 'positive' },
          minMs: 5200,
        },
      ],
      calculationLines: [
        { label: 'Subtraction', latex: `${p(ad)}-(${p(bc)})=${p(det)}`, note: 'Final determinant', isResult: true, highlightColor: '#4ade80' },
      ],
    },
    {
      title: 'Verify and Practise',
      stage: 'verify',
      equation: String.raw`${p(ad - bc)} = ${p(det)} \;\checkmark`,
      operation: 'Recompute the same value directly',
      whyNecessary: 'A one-line recheck catches almost every arithmetic slip.',
      ruleUsed: 'Arithmetic recheck',
      cues: [
        {
          id: 'd2-ver',
          stepIndex: 5,
          stage: 'verify',
          narration: N(
            `Recheck: ${a} into ${d} minus ${b} into ${c} phir se ${det} deta hai. Ab tum similar question khud try karo.`,
            `पुनः जाँच: ${a}×${d} − ${b}×${c} पुनः ${det} देता है। अब तुम समान प्रश्न स्वयं हल करो।`,
            `Recheck: ${a}×${d} − ${b}×${c} again gives ${det}. Now try a similar question yourself.`,
          ),
          boardAppend: [
            L('vc', String.raw`\text{Recheck: } ${p(a)}\cdot${p(d)} - ${p(b)}\cdot${p(c)} = ${p(det)} \;\checkmark`, 'emerald'),
            L('pr', String.raw`\textbf{Your turn: } ${vmatrix2([[a + 1, b], [c, d + 2]])}`, 'yellow'),
          ],
          focus: 'practice',
          gesture: 'wave',
          camera: 'students',
          animation: { kind: 'reveal_answer', operands: [String(det)], result: verified ? '✓' : '?', label: `Δ = ${det}` },
          minMs: 5600,
        },
      ],
    },
  ];

  const pMatrix = [[a + 1, b], [c, d + 2]];
  const pDet = det2(pMatrix);

  return assemble({
    id: `det2-${matrix.flat().join('-')}`,
    title: '2×2 Determinant — Full Classroom Lesson',
    topic: 'Matrices and Determinants',
    subtopic: 'Diagonal products, subtraction and area meaning',
    difficulty: 'Beginner',
    originalQuestion: `Find the value of the determinant [${a}, ${b}], [${c}, ${d}]`,
    latexExpression: String.raw`\Delta = ${vmatrix2(matrix)}`,
    boardTitle: 'Determinant of a 2×2 Matrix',
    teacherIntro: N(
      'Namaste! Aaj hum do guna do determinant board par step by step nikalenge.',
      'नमस्ते! आज हम 2x2 सारणिक बोर्ड पर चरणबद्ध निकालेंगे।',
      'Hello! Today we evaluate a two by two determinant step by step on the board.',
    ),
    quickReminder: {
      formulaName: '2×2 Determinant',
      formulaLatex: String.raw`\begin{vmatrix}a&b\\c&d\end{vmatrix} = ad - bc`,
      coloredFormulaLatex: String.raw`\Delta = {\color{#4ade80}ad} - {\color{#fbbf24}bc}`,
      symbols: [
        { symbol: 'a, d', meaning: 'Main diagonal product', color: '#4ade80', position: 'Top-left, bottom-right' },
        { symbol: 'b, c', meaning: 'Anti-diagonal product (subtracted)', color: '#fbbf24', position: 'Top-right, bottom-left' },
      ],
      signRules: [
        { rule: 'Subtraction', example: `${ad} − (${bc}) = ${det}`, note: 'Keep the bracket to preserve the sign' },
      ],
    },
    prerequisites: ['Integer multiplication', 'Position naming a, b, c, d'],
    formulas: [{ name: '2×2 determinant', latex: String.raw`ad - bc`, note: 'Main diagonal minus anti-diagonal' }],
    steps,
    finalAnswerSummary: {
      resultLatex: String.raw`\Delta = ${p(det)}`,
      resultValue: String(det),
      verificationNote: `Direct recompute confirms ${det}.`,
      verificationLatex: String.raw`${p(ad)}-(${p(bc)}) = ${p(det)} \;\checkmark`,
    },
    verification: { method: 'Direct recompute', latex: String.raw`${p(ad)}-(${p(bc)})=${p(det)}`, isVerified: verified, explanation: 'Arithmetic recheck.' },
    animationType: 'matrix_determinant_2x2',
    animationInitialParams: { matrix },
    commonMistakes: [`Writing ${p(ad)} + ${p(bc)} instead of subtracting.`, 'Mixing up the anti-diagonal order.'],
    importantSignRules: [{ rule: 'Bracket minus', example: `${ad} − (${bc})`, note: 'Bracket preserves the sign' }],
    revisionSummary: ['Multiply the main diagonal', 'Multiply the anti-diagonal', 'Subtract the second from the first'],
    practiceQuestions: [
      {
        id: 'pq-d2',
        question: 'Evaluate the practice determinant on the board.',
        latex: String.raw`${vmatrix2(pMatrix)}`,
        hints: ['Main diagonal first.', 'Then the anti-diagonal.', 'Subtract.'],
        finalAnswer: String(pDet),
        explanation: `${pMatrix[0][0]}×${pMatrix[1][1]} − ${pMatrix[0][1]}×${pMatrix[1][0]} = ${pDet}.`,
      },
    ],
    masteryQuiz: [
      {
        id: 'qz-d2',
        question: 'The 2×2 determinant rule is:',
        options: ['ad + bc', 'ad − bc', 'ab − cd', 'ac − bd'],
        correctAnswer: 1,
        explanation: 'Main diagonal minus anti-diagonal.',
      },
    ],
  });
};

/* ------------------------------------------------------------------ */
/* LINEAR EQUATION LESSON                                              */
/* ------------------------------------------------------------------ */

export const buildLinearLesson = (a: number, b: number, c: number): Lesson => {
  const S = solveLinear(a, b, c);
  const xDisp = S.isExact ? String(S.x) : S.x.toFixed(3);
  const xLatex = S.isExact ? String(S.x) : S.x.toFixed(3);

  const steps: StepSpec[] = [
    {
      title: 'Understand the Question',
      stage: 'question',
      equation: String.raw`${p(a)}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(c)}`,
      operation: 'Identify that x must be isolated',
      whyNecessary: 'Solving means finding the value of x that makes the statement true.',
      ruleUsed: 'Equation reading',
      cues: [
        {
          id: 'lin-q1',
          stepIndex: 0,
          stage: 'question',
          narration: N(
            `Chalo beta, board par ek equation hai. Humein x ki wo value nikalni hai jisse ye barabar sahi ho jaye.`,
            `चलो बच्चों, बोर्ड पर एक समीकरण है। हमें x का वह मान निकालना है जिससे यह सही हो जाए।`,
            `Let us begin. On the board is an equation. We need the value of x that makes it true.`,
          ),
          boardAppend: [
            L('t', String.raw`\textbf{Topic: Solving a linear equation}`, 'yellow'),
            L('q', String.raw`${p(a)}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(c)}`, 'chalk', 'Question'),
          ],
          focus: 'question',
          gesture: 'explain',
          camera: 'teacher',
          animation: { kind: 'point_terms', operands: [`${a}x`, `${b}`, `${c}`], label: 'Three parts' },
          minMs: 5000,
        },
      ],
      checkQuestion: {
        question: 'What does "solve" mean here?',
        options: ['Make x equal to zero', 'Find the value of x that satisfies the equation', 'Remove all numbers', 'Square both sides'],
        correctIndex: 1,
        explanation: 'Solving means finding the value of x that makes the equality true.',
      },
    },
    {
      title: 'Basics: The Balance Idea',
      stage: 'basics',
      equation: String.raw`x + 3 = 5 \Rightarrow x = 2`,
      operation: 'Show the balance concept with a tiny example',
      whyNecessary: 'Equality is a balance: whatever you do to one side you must do to the other.',
      ruleUsed: 'Properties of equality',
      simplerExplanation: N(
        'Equation ko taraju samjho. Dono taraf se ek hi cheez hatao to taraju bana rehta hai.',
        'समीकरण को तराजू समझो। दोनों तरफ से एक ही चीज़ हटाओ तो तराजू संतुलित रहता है।',
        'Think of the equation as a balance scale. Remove the same thing from both sides and it stays balanced.',
      ),
      cues: [
        {
          id: 'lin-b1',
          stepIndex: 1,
          stage: 'basics',
          narration: N(
            `Ek chhota example lo: x plus three barabar five. Dono taraf se three hatane par x barabar two milta hai.`,
            `एक छोटा उदाहरण लो: x + 3 = 5। दोनों तरफ से 3 हटाने पर x = 2 मिलता है।`,
            `Take a small example: x plus three equals five. Removing three from both sides gives x equals two.`,
          ),
          boardAppend: [
            L('w1', String.raw`\text{Warm-up: } x + 3 = 5`, 'chalk'),
            L('w2', String.raw`x + 3 - 3 = 5 - 3 \Rightarrow x = 2`, 'emerald'),
          ],
          focus: 'formula',
          gesture: 'point',
          camera: 'board',
          animation: { kind: 'isolate', operands: ['x + 3', '5'], result: 'x = 2', label: 'Balance both sides' },
          minMs: 5200,
        },
      ],
      checkQuestion: {
        question: 'In x + 3 = 5, why do we subtract 3 from both sides?',
        options: ['To make numbers smaller', 'To keep the balance while removing the +3', 'Because 3 is odd', 'It is optional'],
        correctIndex: 1,
        explanation: 'Subtracting on both sides removes the +3 while preserving equality.',
      },
      remediation: {
        title: 'Balance property',
        explanation: 'A = B means A − k = B − k. The equality survives identical operations on both sides.',
        easierExample: 'If 6 = 6 then 6 − 2 = 6 − 2.',
        easierExampleLatex: String.raw`6=6 \Rightarrow 6-2=6-2`,
      },
    },
    {
      title: 'Subtract the Constant',
      stage: 'solve',
      equation: String.raw`${p(a)}x = ${p(S.afterSubtract)}`,
      operation: `${b >= 0 ? 'Subtract' : 'Add'} ${Math.abs(b)} on both sides`,
      whyNecessary: 'Isolate the x-term before dividing.',
      ruleUsed: 'Addition/subtraction property of equality',
      cues: [
        {
          id: 'lin-s1',
          stepIndex: 2,
          stage: 'solve',
          narration: N(
            `Ab dono taraf se ${b >= 0 ? `${b} minus` : `${Math.abs(b)} plus`} karte hain, taaki sirf ${a}x bacha rahe.`,
            `अब दोनों तरफ ${b >= 0 ? `${b} घटाते` : `${Math.abs(b)} जोड़ते`} हैं, ताकि केवल ${a}x बचे।`,
            `Now ${b >= 0 ? 'subtract' : 'add'} ${Math.abs(b)} on both sides so that only ${a}x remains.`,
          ),
          boardAppend: [
            L('l1', String.raw`${p(a)}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)} ${b >= 0 ? '-' : '+'} ${Math.abs(b)} = ${p(c)} ${b >= 0 ? '-' : '+'} ${Math.abs(b)}`, 'chalk'),
            L('l2', String.raw`${p(a)}x = ${p(S.afterSubtract)}`, 'emerald', 'Isolated'),
          ],
          focus: 'solve',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'isolate', operands: [`${a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}`, String(c)], result: `${a}x = ${S.afterSubtract}`, label: 'Constant removed' },
          minMs: 5200,
        },
      ],
      calculationLines: [
        { label: 'Subtract on both sides', latex: `${p(c)} ${b >= 0 ? '-' : '+'} ${Math.abs(b)} = ${p(S.afterSubtract)}`, note: 'RHS value' },
        { label: 'Remaining', latex: `${p(a)}x = ${p(S.afterSubtract)}`, note: 'Ready to divide', isResult: true },
      ],
    },
    {
      title: 'Divide by the Coefficient',
      stage: 'solve',
      equation: String.raw`x = ${S.isExact ? String(S.x) : String.raw`\frac{${S.afterSubtract}}{${a}}`}`,
      operation: `Divide both sides by ${a}`,
      whyNecessary: 'The coefficient must become 1 to reveal x.',
      ruleUsed: 'Division property of equality',
      cues: [
        {
          id: 'lin-s2',
          stepIndex: 3,
          stage: 'solve',
          narration: N(
            `Ab dono taraf ko ${a} se divide karo. To x barabar ${xDisp} milta hai.`,
            `अब दोनों तरफ को ${a} से भाग दो। x = ${xDisp} प्राप्त होता है।`,
            `Now divide both sides by ${a}. We get x = ${xDisp}.`,
          ),
          boardAppend: [
            L('l3', String.raw`\frac{${p(a)}x}{${a}} = \frac{${p(S.afterSubtract)}}{${a}}`, 'chalk'),
            L('l4', String.raw`x = ${S.isExact ? String(S.x) : String.raw`\frac{${S.afterSubtract}}{${a}} \approx ${xLatex}`}`, 'emerald'),
          ],
          focus: 'solve',
          gesture: 'emphasize',
          camera: 'board',
          animation: { kind: 'reveal_answer', operands: [String(S.afterSubtract), String(a)], result: xDisp, label: `x = ${xDisp}`, sign: S.x < 0 ? 'negative' : 'positive' },
          minMs: 5200,
        },
      ],
      calculationLines: [{ label: 'Solution', latex: `x = ${xLatex}`, note: 'Exact' + (S.isExact ? '' : ' decimal approximation'), isResult: true, highlightColor: '#4ade80' }],
    },
    {
      title: 'Verify by Substitution',
      stage: 'verify',
      equation: String.raw`${p(a)}(${xLatex}) ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(c)} \;\checkmark`,
      operation: 'Put x back into the original equation',
      whyNecessary: 'Substitution proves the answer, it does not just assert it.',
      ruleUsed: 'Substitution check',
      cues: [
        {
          id: 'lin-v1',
          stepIndex: 4,
          stage: 'verify',
          narration: N(
            `Ab x ka value wapas rakh kar check karte hain. LHS ${S.substituteValue} aata hai, RHS bhi ${c} hai. Matlab answer sahi hai.`,
            `अब x का मान वापस रखकर जाँच करते हैं। बायाँ पक्ष ${S.substituteValue} आता है, दायाँ पक्ष भी ${c} है। अतः उत्तर सही है।`,
            `Now substitute x back. The left side gives ${S.substituteValue} and the right side is ${c}. The answer is confirmed.`,
          ),
          boardAppend: [
            L('l5', String.raw`LHS = ${p(a)}(${xLatex}) ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(S.substituteValue)}`, 'chalk'),
            L('l6', String.raw`RHS = ${p(c)} \Rightarrow LHS = RHS \;\checkmark`, 'emerald'),
          ],
          focus: 'verify',
          gesture: 'point',
          camera: 'teacher',
          animation: { kind: 'reveal_answer', operands: [String(S.substituteValue), String(c)], result: 'MATCH ✓', label: 'Verified' },
          minMs: 5600,
        },
      ],
      calculationLines: [{ label: 'Verification', latex: `${p(a)}(${xLatex}) ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(S.substituteValue)}`, note: `RHS = ${c}`, isResult: true, highlightColor: '#4ade80' }],
    },
    {
      title: 'Your Turn',
      stage: 'practice',
      equation: String.raw`${p(a)}x + 2 = ${p(a * 3 + 2)}`,
      operation: 'Independent practice',
      whyNecessary: 'Mastery requires solo execution.',
      ruleUsed: 'Same method',
      cues: [
        {
          id: 'lin-p1',
          stepIndex: 5,
          stage: 'practice',
          narration: N(
            `Ab tum ye equation khud solve karo. Pehle constant hatao, phir divide karo.`,
            `अब तुम यह समीकरण स्वयं हल करो। पहले अचर हटाओ, फिर भाग करो।`,
            `Now solve this one yourself. Remove the constant first, then divide.`,
          ),
          boardAppend: [
            L('lp', String.raw`\textbf{Your turn: } ${p(a)}x + 2 = ${p(a * 3 + 2)}`, 'yellow'),
          ],
          focus: 'practice',
          gesture: 'wave',
          camera: 'students',
          animation: { kind: 'point_terms', operands: ['isolate', 'divide'], label: 'Same two moves' },
        },
      ],
    },
  ];

  return assemble({
    id: `lin-${a}-${b}-${c}`,
    title: `Solve ${a}x ${b >= 0 ? '+' : '−'} ${Math.abs(b)} = ${c}`,
    topic: 'Algebra',
    subtopic: 'Balancing linear equations with inverse operations',
    difficulty: 'Beginner',
    originalQuestion: `Solve for x: ${a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${c}`,
    latexExpression: String.raw`${p(a)}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(c)}`,
    boardTitle: 'Solving a Linear Equation',
    teacherIntro: N(
      'Namaste! Aaj hum equation ko taraju ki tarah balance karke solve karenge.',
      'नमस्ते! आज हम समीकरण को तराजू की तरह संतुलित करके हल करेंगे।',
      'Hello! Today we solve an equation by keeping both sides perfectly balanced.',
    ),
    quickReminder: {
      formulaName: 'Inverse operations',
      formulaLatex: String.raw`ax + b = c \Rightarrow x = \frac{c-b}{a}`,
      coloredFormulaLatex: String.raw`{\color{#60a5fa}${p(a)}x} ${b >= 0 ? '+' : '-'} {\color{#fbbf24}${Math.abs(b)}} = {\color{#4ade80}${p(c)}}`,
      symbols: [
        { symbol: 'x', meaning: 'The unknown we are solving for', color: '#60a5fa' },
        { symbol: String(Math.abs(b)), meaning: 'Constant removed first', color: '#fbbf24' },
        { symbol: String(a), meaning: 'Coefficient divided at the end', color: '#4ade80' },
      ],
      signRules: [{ rule: 'Move across equals', example: `+${b} becomes −${b}`, note: 'Same as subtracting on both sides' }],
    },
    prerequisites: ['Inverse operations', 'Keeping both sides balanced'],
    formulas: [{ name: 'Linear solution', latex: String.raw`x = \frac{c-b}{a}`, note: 'Isolate then divide' }],
    steps,
    finalAnswerSummary: {
      resultLatex: `x = ${xLatex}`,
      resultValue: xDisp,
      verificationNote: S.verified
        ? `Substituting x = ${xDisp} returns ${c}, so the solution is confirmed.`
        : 'Substitution did not return the original constant, so this must be rechecked.',
      verificationLatex: String.raw`${p(a)}(${xLatex}) ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${p(c)} \;\checkmark`,
    },
    verification: { method: 'Substitution', latex: S.substituteLatex, isVerified: S.verified, explanation: 'Substituting the solution back into the equation.' },
    animationType: 'equation_balance',
    animationInitialParams: { constantA: a, constantB: b, constantC: c },
    commonMistakes: ['Operating on only one side', 'Dividing before removing the constant'],
    importantSignRules: [{ rule: 'Move across equals', example: `+${b} → −${b}`, note: 'Inverse operation' }],
    revisionSummary: ['Remove the constant first', 'Divide by the coefficient', 'Always substitute to verify'],
    practiceQuestions: [
      {
        id: 'pq-lin',
        question: `Solve ${a}x + 2 = ${a * 3 + 2}`,
        latex: String.raw`${p(a)}x + 2 = ${p(a * 3 + 2)}`,
        hints: ['Subtract 2 from both sides.', `Divide by ${a}.`],
        finalAnswer: '3',
        explanation: `${a}x = ${a * 3}, so x = 3.`,
      },
    ],
    masteryQuiz: [
      {
        id: 'qz-lin',
        question: 'What is the first step in solving ax + b = c?',
        options: ['Subtract b from both sides', 'Divide by a', 'Multiply by a', 'Add c'],
        correctAnswer: 0,
        explanation: 'Remove the constant before dividing.',
      },
    ],
  });
};

/* ------------------------------------------------------------------ */
/* QUADRATIC LESSON                                                    */
/* ------------------------------------------------------------------ */

export const buildQuadraticLesson = (a: number, b: number, c: number): Lesson => {
  const S = solveQuadratic(a, b, c);
  const r1 = S.factorable ? Math.round(S.root1) : Number(S.root1.toFixed(3));
  const r2 = S.factorable ? Math.round(S.root2) : Number(S.root2.toFixed(3));
  const r1Latex = S.isExact ? String(r1) : String.raw`\frac{${-b} - \sqrt{${S.discriminant}}}{${2 * a}}`;
  const r2Latex = S.isExact ? String(r2) : String.raw`\frac{${-b} + \sqrt{${S.discriminant}}}{${2 * a}}`;

  const steps: StepSpec[] = [
    {
      title: 'Understand the Question',
      stage: 'question',
      equation: String.raw`${p(a)}x^2 ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`,
      operation: 'Recognise a quadratic and its two roots',
      whyNecessary: 'A quadratic has two solutions; we look for both from the start.',
      ruleUsed: 'Standard form recognition',
      cues: [
        {
          id: 'quad-q1',
          stepIndex: 0,
          stage: 'question',
          narration: N(
            `Chalo beta, ye quadratic equation hai. Iske do roots hote hain — matlab graph x-axis ko do baar kaat sakta hai.`,
            `चलो बच्चों, यह द्विघात समीकरण है। इसकी दो मूलें होती हैं — आलेख x-अक्ष को दो बार काट सकता है।`,
            `Let us begin. This is a quadratic equation. It has two roots — the graph can cross the x-axis twice.`,
          ),
          boardAppend: [
            L('t', String.raw`\textbf{Topic: Quadratic equation}`, 'yellow'),
            L('q', String.raw`${p(a)}x^2 ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`, 'chalk', 'Question'),
          ],
          focus: 'question',
          gesture: 'explain',
          camera: 'teacher',
          animation: { kind: 'point_terms', operands: [`${a}x²`, `${b}x`, `${c}`], label: 'a, b, c' },
          minMs: 5200,
        },
      ],
      checkQuestion: { question: 'How many roots does a quadratic have (over the reals, when D ≥ 0)?', options: ['1', '2', '3', 'Infinite'], correctIndex: 1, explanation: 'Degree 2 means at most two real roots.' },
    },
    {
      title: 'Identify a, b and c',
      stage: 'values',
      equation: String.raw`a=${p(a)},\quad b=${p(b)},\quad c=${p(c)}`,
      operation: 'Read coefficients with their signs',
      whyNecessary: 'The sign of b is the most common source of error.',
      ruleUsed: 'Standard form ax² + bx + c',
      cues: [
        {
          id: 'quad-v1',
          stepIndex: 1,
          stage: 'values',
          narration: N(
            `Dhyan se signs dekho: a barabar ${a}, b barabar ${b} aur c barabar ${c}. Sign ke saath likhna zaroori hai.`,
            `चिह्न ध्यान से देखो: a = ${a}, b = ${b} और c = ${c}। चिह्न सहित लिखना आवश्यक है।`,
            `Watch the signs carefully: a = ${a}, b = ${b} and c = ${c}. Signs must be carried along.`,
          ),
          boardAppend: [L('v', String.raw`a=${p(a)},\quad b=${p(b)},\quad c=${p(c)}`, 'cyan')],
          focus: 'values',
          gesture: 'point',
          camera: 'board',
          animation: { kind: 'substitute', operands: [`a=${a}`, `b=${b}`, `c=${c}`], label: 'Coefficients' },
        },
      ],
      calculationLines: [{ label: 'Coefficients', latex: `a=${p(a)},\\ b=${p(b)},\\ c=${p(c)}`, note: 'With signs' }],
    },
    {
      title: 'Discriminant',
      stage: 'formula',
      equation: String.raw`D = b^2 - 4ac = ${p(S.discriminant)}`,
      operation: 'Compute the discriminant',
      whyNecessary: 'D tells us how many real roots exist before we compute them.',
      ruleUsed: 'Discriminant D = b² − 4ac',
      cues: [
        {
          id: 'quad-f1',
          stepIndex: 2,
          stage: 'formula',
          narration: N(
            `Pehle discriminant nikaalte hain: b square minus four a c. Yahan ${p(b)} square minus four into ${p(a)} into ${p(c)} barabar ${S.discriminant}.`,
            `पहले विविक्तकर निकालते हैं: b² − 4ac। यहाँ ${p(b)}² − 4×${p(a)}×${p(c)} = ${S.discriminant}।`,
            `First the discriminant: b squared minus four a c. Here that is ${S.discriminant}.`,
          ),
          boardAppend: [
            L('f', String.raw`D = b^2 - 4ac = ${p(b)}^2 - 4(${p(a)})(${p(c)}) = ${p(S.discriminant)}`, 'yellow', 'Discriminant'),
            L(
              'fn',
              String.raw`D ${S.discriminant > 0 ? '> 0 \\Rightarrow two distinct real roots' : S.discriminant === 0 ? '= 0 \\Rightarrow one repeated root' : '< 0 \\Rightarrow no real roots'}`,
              'chalk',
            ),
          ],
          focus: 'formula',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'multiply', operands: [String(4 * a * c), String(b * b)], result: String(S.discriminant), label: `D = ${S.discriminant}` },
          minMs: 5600,
        },
      ],
      calculationLines: [{ label: 'Discriminant', latex: `D = ${p(S.discriminant)}`, note: S.discriminant > 0 ? 'Two real roots' : 'Check root type' }],
    },
    {
      title: 'Apply the Quadratic Formula',
      stage: 'solve',
      equation: String.raw`x = \frac{-b \pm \sqrt{D}}{2a}`,
      operation: 'Substitute into the formula',
      whyNecessary: 'The formula works for every quadratic, factorable or not.',
      ruleUsed: 'Quadratic formula',
      cues: [
        {
          id: 'quad-s1',
          stepIndex: 3,
          stage: 'solve',
          narration: N(
            `Ab formula lagate hain: x barabar minus b plus minus root D, divided by two a.`,
            `अब सूत्र लगाते हैं: x = (−b ± √D) / 2a।`,
            `Now apply the formula: x equals minus b plus or minus root D, all over two a.`,
          ),
          boardAppend: [
            L('s1', String.raw`x = \frac{-(${p(b)}) \pm \sqrt{${p(S.discriminant)}}}{2(${p(a)})}`, 'chalk'),
            L(
              's2',
              String.raw`x_1 = ${r1Latex}${S.isExact ? '' : ` \\approx ${r1}`}, \qquad x_2 = ${r2Latex}${S.isExact ? '' : ` \\approx ${r2}`}`,
              'emerald',
              'Roots',
            ),
          ],
          focus: 'solve',
          gesture: 'write',
          camera: 'board',
          animation: { kind: 'reveal_answer', operands: [r1Latex, r2Latex], result: `x = ${r1}, ${r2}`, label: 'Both roots' },
          minMs: 6000,
        },
      ],
      calculationLines: [
        { label: 'Root 1', latex: `x_1 = ${S.isExact ? r1 : r1.toFixed(3)}`, note: 'Minus branch', isResult: true, highlightColor: '#4ade80' },
        { label: 'Root 2', latex: `x_2 = ${S.isExact ? r2 : r2.toFixed(3)}`, note: 'Plus branch', isResult: true, highlightColor: '#60a5fa' },
      ],
    },
    {
      title: 'Verify Both Roots',
      stage: 'verify',
      equation: String.raw`f(${S.isExact ? r1 : r1.toFixed(2)}) = 0,\quad f(${S.isExact ? r2 : r2.toFixed(2)}) = 0 \;\checkmark`,
      operation: 'Substitute both roots back',
      whyNecessary: 'Both roots must satisfy the equation exactly.',
      ruleUsed: 'Substitution check',
      cues: [
        {
          id: 'quad-vf',
          stepIndex: 4,
          stage: 'verify',
          narration: N(
            `Dono roots ko wapas rakh kar check karte hain. Dono baar zero aata hai, matlab answer verified hai.`,
            `दोनों मूलों को वापस रखकर जाँचते हैं। दोनों बार शून्य आता है, अतः उत्तर सत्यापित है।`,
            `Substitute both roots back. Both give zero, so the answer is verified.`,
          ),
          boardAppend: [
            L('vf', String.raw`f(${S.isExact ? r1 : r1.toFixed(2)}) = 0 \;\checkmark, \qquad f(${S.isExact ? r2 : r2.toFixed(2)}) = 0 \;\checkmark`, 'emerald'),
          ],
          focus: 'verify',
          gesture: 'point',
          camera: 'teacher',
          animation: { kind: 'reveal_answer', operands: ['0', '0'], result: 'VERIFIED ✓', label: 'Both roots check out' },
          minMs: 5400,
        },
      ],
      calculationLines: [{ label: 'Verification', latex: `f(${r1})=0,\\ f(${r2})=0`, note: 'Substitution', isResult: true, highlightColor: '#4ade80' }],
    },
    {
      title: 'Your Turn',
      stage: 'practice',
      equation: String.raw`x^2 - 7x + 12 = 0`,
      operation: 'Independent practice',
      whyNecessary: 'Repetition converts understanding into skill.',
      ruleUsed: 'Same method',
      cues: [
        {
          id: 'quad-p1',
          stepIndex: 5,
          stage: 'practice',
          narration: N(
            `Ab tum ye practice question karo: x square minus seven x plus twelve barabar zero.`,
            `अब तुम यह अभ्यास प्रश्न करो: x² − 7x + 12 = 0।`,
            `Now try this practice question: x squared minus seven x plus twelve equals zero.`,
          ),
          boardAppend: [L('pr', String.raw`\textbf{Your turn: } x^2 - 7x + 12 = 0`, 'yellow')],
          focus: 'practice',
          gesture: 'wave',
          camera: 'students',
          animation: { kind: 'point_terms', operands: ['D', 'roots'], label: 'Same two moves' },
        },
      ],
    },
  ];

  return assemble({
    id: `quad-${a}-${b}-${c}`,
    title: `Solve ${a}x² ${b >= 0 ? '+' : '−'} ${Math.abs(b)}x ${c >= 0 ? '+' : '−'} ${Math.abs(c)} = 0`,
    topic: 'Quadratic Equations',
    subtopic: 'Discriminant, quadratic formula and verification',
    difficulty: 'Intermediate',
    originalQuestion: `Solve ${a}x² ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`,
    latexExpression: String.raw`${p(a)}x^2 ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`,
    boardTitle: 'Quadratic Equation',
    teacherIntro: N(
      'Namaste! Aaj hum quadratic formula se dono roots nikaalenge aur verify karenge.',
      'नमस्ते! आज हम द्विघात सूत्र से दोनों मूल निकालेंगे और सत्यापित करेंगे।',
      'Hello! Today we find both roots with the quadratic formula and verify them.',
    ),
    quickReminder: {
      formulaName: 'Quadratic formula',
      formulaLatex: String.raw`x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}`,
      coloredFormulaLatex: String.raw`x = \frac{-{\color{#fbbf24}b} \pm \sqrt{{\color{#fbbf24}b}^2 - 4{\color{#60a5fa}a}{\color{#4ade80}c}}}{2{\color{#60a5fa}a}}`,
      symbols: [
        { symbol: 'a', meaning: 'Coefficient of x²', color: '#60a5fa' },
        { symbol: 'b', meaning: 'Coefficient of x (sign matters!)', color: '#fbbf24' },
        { symbol: 'c', meaning: 'Constant term', color: '#4ade80' },
      ],
      signRules: [{ rule: '−b with negative b', example: `−(${p(b)}) = ${-b}`, note: 'Double negative becomes plus' }],
    },
    prerequisites: ['Square roots', 'Substitution', 'Order of operations'],
    formulas: [
      { name: 'Quadratic formula', latex: String.raw`x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}`, note: 'Works for every quadratic' },
      { name: 'Discriminant', latex: String.raw`D = b^2 - 4ac`, note: 'D > 0: two roots, D = 0: one root, D < 0: no real roots' },
    ],
    steps,
    finalAnswerSummary: {
      resultLatex: String.raw`x = ${S.isExact ? `${r1},\\ ${r2}` : `${r1.toFixed(3)},\\ ${r2.toFixed(3)} \\text{ (approx.)}`}`,
      resultValue: S.isExact ? `${r1}, ${r2}` : `${r1.toFixed(3)}, ${r2.toFixed(3)}`,
      verificationNote: S.verified
        ? 'Both roots satisfy the equation exactly.'
        : 'Roots are approximate decimals; exact values are kept in surd form on the board.',
      verificationLatex: String.raw`f(${S.isExact ? r1 : r1.toFixed(2)}) = 0, \quad f(${S.isExact ? r2 : r2.toFixed(2)}) = 0`,
    },
    verification: { method: 'Substitution of both roots', latex: String.raw`f(${r1})=0,\ f(${r2})=0`, isVerified: S.verified, explanation: 'Both roots substituted back into the equation.' },
    animationType: 'quadratic_parabola',
    animationInitialParams: { a, b, c, root1: r1, root2: r2 },
    commonMistakes: ['Dropping the ± sign', 'Forgetting the negative sign in −b'],
    importantSignRules: [{ rule: '−b', example: `−(${p(b)}) = ${-b}`, note: 'Sign of b carries through' }],
    revisionSummary: ['Compute D', 'Apply the formula with ±', 'Substitute both roots to verify'],
    practiceQuestions: [
      { id: 'pq-quad', question: 'Solve x² − 7x + 12 = 0', latex: String.raw`x^2-7x+12=0`, hints: ['D = 49 − 48 = 1', '√D = 1', 'Apply the formula'], finalAnswer: '3, 4', explanation: 'x = (7 ± 1)/2 = 3, 4.' },
    ],
    masteryQuiz: [
      { id: 'qz-quad', question: 'If D = 0, the quadratic has:', options: ['Two distinct roots', 'One repeated root', 'No real roots', 'Infinite roots'], correctAnswer: 1, explanation: 'D = 0 gives a single repeated root.' },
    ],
  });
};

/* ------------------------------------------------------------------ */
/* PUBLIC ENTRY: parse any uploaded question into a lesson             */
/* ------------------------------------------------------------------ */

const numberFrom = (s: string | undefined, fallback = 0) => {
  if (!s) return fallback;
  const n = Number.parseFloat(s);
  return Number.isFinite(n) ? n : fallback;
};

export const parseQuestionToLesson = (questionText: string, latex: string): Lesson => {
  const raw = `${questionText} ${latex}`;
  const lower = raw.toLowerCase();

  // 3×3 determinant
  const m3 = latex.match(
    /begin\{vmatrix\}\s*([-\d.]+)\s*&\s*([-\d.]+)\s*&\s*([-\d.]+)\s*\\\\\s*([-\d.]+)\s*&\s*([-\d.]+)\s*&\s*([-\d.]+)\s*\\\\\s*([-\d.]+)\s*&\s*([-\d.]+)\s*&\s*([-\d.]+)\s*\\end\{vmatrix\}/,
  );
  if (m3) {
    const m = [
      [numberFrom(m3[1]), numberFrom(m3[2]), numberFrom(m3[3])],
      [numberFrom(m3[4]), numberFrom(m3[5]), numberFrom(m3[6])],
      [numberFrom(m3[7]), numberFrom(m3[8]), numberFrom(m3[9])],
    ];
    return buildDeterminant3Lesson(m);
  }

  // 2×2 determinant
  const m2 = latex.match(
    /begin\{vmatrix\}\s*([-\d.]+)\s*&\s*([-\d.]+)\s*\\\\\s*([-\d.]+)\s*&\s*([-\d.]+)\s*\\end\{vmatrix\}/,
  );
  if (m2) {
    return buildDeterminant2Lesson([
      [numberFrom(m2[1]), numberFrom(m2[2])],
      [numberFrom(m2[3]), numberFrom(m2[4])],
    ]);
  }

  // Bracketed pair form: [2, 3, 1], [1, 0, -1], [4, -2, 3]
  const triplets = raw.match(/\[\s*([-\d]+)\s*,\s*([-\d]+)\s*,\s*([-\d]+)\s*\]/g);
  if (triplets && triplets.length >= 3) {
    const rows = triplets.slice(0, 3).map((t) =>
      (t.match(/[-\d]+/g) || ['0', '0', '0']).slice(0, 3).map(Number),
    );
    return buildDeterminant3Lesson(rows as number[][]);
  }

  const pairs = raw.match(/\[\s*([-\d]+)\s*,\s*([-\d]+)\s*\]/g);
  if (pairs && pairs.length >= 2) {
    const rows = pairs.slice(0, 2).map((t) => (t.match(/[-\d]+/g) || ['0', '0']).slice(0, 2).map(Number));
    return buildDeterminant2Lesson(rows as number[][]);
  }

  // Linear equation ax + b = c
  const lin = raw.match(/([-\d]*)x\s*([+-])\s*(\d+)\s*=\s*([-\d]+)/);
  if (lin) {
    const aCoef = lin[1] === '' || lin[1] === '+' ? 1 : lin[1] === '-' ? -1 : numberFrom(lin[1], 1);
    const bCoef = lin[2] === '-' ? -numberFrom(lin[3]) : numberFrom(lin[3]);
    return buildLinearLesson(aCoef, bCoef, numberFrom(lin[4]));
  }

  // Quadratic ax² + bx + c = 0
  const quad = raw.match(/([-\d]*)\s*x\^?2?\s*([+-]\s*\d*)\s*x\s*([+-]\s*\d+)\s*=\s*0/i);
  if (quad || (lower.includes('quadratic') && lower.includes('='))) {
    const q = raw.match(/([-\d]*)\s*x\^?2\s*([+-])\s*(\d+)\s*x\s*([+-])\s*(\d+)\s*=\s*0/i);
    if (q) {
      const aCoef = q[1] === '' || q[1] === '+' ? 1 : q[1] === '-' ? -1 : numberFrom(q[1], 1);
      const bCoef = q[2] === '-' ? -numberFrom(q[3]) : numberFrom(q[3]);
      const cCoef = q[4] === '-' ? -numberFrom(q[5]) : numberFrom(q[5]);
      return buildQuadraticLesson(aCoef, bCoef, cCoef);
    }
    return buildQuadraticLesson(1, -5, 6);
  }

  // Sensible default: the classroom demonstration determinant
  return buildDeterminant3Lesson([
    [2, 3, 1],
    [1, 0, -1],
    [4, -2, 3],
  ]);
};

/** The demonstration matrix used in the classroom intro. */
export const DEMO_MATRIX: number[][] = [
  [2, 3, 1],
  [1, 0, -1],
  [4, -2, 3],
];

export const buildDemoLesson = (): Lesson => buildDeterminant3Lesson(DEMO_MATRIX);

/** 3×3 lesson plus its real-time blackboard script (every number verified before writing). */
export const buildDeterminant3Lesson = (matrix: number[][]): Lesson => ({
  ...buildDeterminant3LessonBase(matrix),
  boardScript: buildDet3BoardScript(matrix),
});

export type { MathAnimationSpec };
