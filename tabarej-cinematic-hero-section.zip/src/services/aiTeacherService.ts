import { Language, Lesson, ApiSettings, ChatMessage, SolutionStep } from '../types/math';
import { parseQuestionToLesson } from './lessonEngine';

export interface VisionAnalysisResult {
  detectedText: string;
  latexExpression: string;
  topic: string;
  confidence: number;
  isAmbiguous: boolean;
  ambiguityReason?: string;
  /** Generated lesson when recognition is confident. */
  lesson?: Lesson;
}

class AiTeacherService {
  private apiSettings: ApiSettings = {
    provider: 'builtin',
    apiKey: '',
    model: 'gpt-4o',
    isConfigured: false,
  };

  constructor() {
    this.loadSettings();
  }

  getSettings(): ApiSettings {
    return { ...this.apiSettings };
  }

  saveSettings(settings: ApiSettings) {
    this.apiSettings = settings;
    try {
      localStorage.setItem('mathmind_api_settings', JSON.stringify(settings));
    } catch (e) {
      console.warn('Could not save API settings:', e);
    }
  }

  private loadSettings() {
    try {
      const stored = localStorage.getItem('mathmind_api_settings');
      if (stored) this.apiSettings = { ...this.apiSettings, ...JSON.parse(stored) };
    } catch (e) {
      console.warn('Could not load API settings:', e);
    }
  }

  /** Server-side endpoint (never a browser key) when the app is deployed with a backend. */
  private serverEndpoint(): string | null {
    const env = (import.meta as any)?.env ?? {};
    return env.VITE_AI_LESSON_ENDPOINT || null;
  }

  /**
   * Reads an uploaded photo. Priority:
   *  1. A secure server-side vision endpoint (key stays on the server).
   *  2. A user-supplied key stored only in their own browser (BYO key).
   *  3. The built-in offline recogniser + verified lesson engine.
   */
  async analyzeQuestionImage(imageDataUrl: string, fileName?: string): Promise<VisionAnalysisResult> {
    if (!imageDataUrl || imageDataUrl.length < 500) {
      return {
        detectedText: '',
        latexExpression: '',
        topic: 'Unknown',
        confidence: 0.1,
        isAmbiguous: true,
        ambiguityReason:
          'The uploaded image looks blank or truncated. Please upload a clearer photo of the question.',
      };
    }

    // 1. Server-side vision pipeline
    const endpoint = this.serverEndpoint();
    if (endpoint) {
      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: imageDataUrl }),
        });
        if (res.ok) {
          const data = await res.json();
          const lesson = parseQuestionToLesson(data.detectedText || '', data.latexExpression || '');
          return {
            detectedText: data.detectedText,
            latexExpression: data.latexExpression,
            topic: data.topic || lesson.topic,
            confidence: data.confidence ?? 0.95,
            isAmbiguous: !!data.isAmbiguous,
            ambiguityReason: data.ambiguityReason,
            lesson,
          };
        }
      } catch (err) {
        console.warn('Server vision endpoint unavailable, using local engine:', err);
      }
    }

    // 2. BYO key (stored only in this browser)
    if (this.apiSettings.isConfigured && this.apiSettings.apiKey && this.apiSettings.provider === 'openai') {
      try {
        return await this.callOpenAiVision(imageDataUrl);
      } catch (err) {
        console.warn('Vision API failed, using offline recogniser:', err);
      }
    }

    // 3. Offline recogniser (deliberately honest: it cannot read arbitrary
    //    handwriting without a vision model, so it says so instead of guessing).
    await new Promise((r) => setTimeout(r, 600));
    const name = (fileName || '').toLowerCase();

    const topicGuess = name.includes('trig')
      ? 'Trigonometry'
      : name.includes('calc') || name.includes('derivative')
      ? 'Calculus'
      : name.includes('geometry') || name.includes('cylinder')
      ? 'Geometry'
      : name.includes('algebra') || name.includes('equation')
      ? 'Algebra'
      : 'Matrices and Determinants';

    return {
      detectedText:
        'Offline recogniser: no vision model is connected, so the printed question could not be read from this photo.',
      latexExpression: '',
      topic: topicGuess,
      confidence: 0.35,
      isAmbiguous: true,
      ambiguityReason:
        'A vision-capable AI model is required to read handwritten or printed questions from a photo. Connect the secure server endpoint (VITE_AI_LESSON_ENDPOINT) or add a key in Settings, or type the question manually below — the lesson engine will still teach it perfectly.',
    };
  }

  private async callOpenAiVision(imageDataUrl: string): Promise<VisionAnalysisResult> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiSettings.apiKey}`,
      },
      body: JSON.stringify({
        model: this.apiSettings.model || 'gpt-4o',
        messages: [
          {
            role: 'system',
            content:
              'You are a mathematical OCR engine. Transcribe ONLY what is visibly written. Never invent numbers. Reply with JSON: {detectedText, latexExpression, topic, confidence, isAmbiguous, ambiguityReason}.',
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Extract this mathematics question exactly as written, in LaTeX.' },
              { type: 'image_url', image_url: { url: imageDataUrl } },
            ],
          },
        ],
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) throw new Error(`Vision error ${response.status}`);
    const json = await response.json();
    const parsed = JSON.parse(json.choices[0].message.content);
    const lesson = parseQuestionToLesson(parsed.detectedText || '', parsed.latexExpression || '');

    return {
      detectedText: parsed.detectedText,
      latexExpression: parsed.latexExpression,
      topic: parsed.topic || lesson.topic,
      confidence: parsed.confidence ?? 0.9,
      isAmbiguous: !!parsed.isAmbiguous,
      ambiguityReason: parsed.ambiguityReason,
      lesson,
    };
  }

  /** Turns any typed question into a full verified teaching lesson. */
  generateLessonFromText(questionText: string, latex: string): Lesson {
    return parseQuestionToLesson(questionText, latex);
  }

  /**
   * Context-aware doubt answering. Deliberately never repeats the same wording
   * twice in a row — it switches strategy instead.
   */
  async answerDoubt(
    lesson: Lesson,
    currentStep: SolutionStep,
    userQuery: string,
    language: Language,
    attempt: number = 0,
  ): Promise<ChatMessage> {
    const q = userQuery.toLowerCase().trim();
    const alt = attempt % 2 === 1; // change strategy when asked again
    let text = '';
    let latex: string | undefined = currentStep.equation;

    const pick = (o: { hinglish: string; hindi: string; english: string }) =>
      o[language] || o.hinglish;

    const simpler = currentStep.simplerExplanation
      ? pick(currentStep.simplerExplanation)
      : pick({
          hinglish: `Is step mein hum sirf ye kar rahe hain: ${currentStep.operation}.`,
          hindi: `इस चरण में हम केवल यह कर रहे हैं: ${currentStep.operation}।`,
          english: `In this step we are only doing: ${currentStep.operation}.`,
        });

    if (q.includes('samajh nahi') || q.includes('nahi aaya') || q.includes('simple') || q.includes('easy samjhao')) {
      text = alt
        ? `${simpler}\n\nDoosre shabdon mein: rule hai "${currentStep.ruleUsed}". Isliye ye line likhi gayi: ${currentStep.whyNecessary}`
        : `Theek hai beta, tension mat lo. ${simpler}`;
      latex = currentStep.equation;
    } else if (q.includes('kahan se aaya') || q.includes('number kahan') || q.includes('value kahan')) {
      text = pick({
        hinglish: `Ye numbers board par diye gaye matrix/question se aaye hain. Main unhe pehle hi a, b, c... naam de chuka hoon — wahi values ab formula mein baithi hain. Ye dekho: ${currentStep.operation}`,
        hindi: `ये संख्याएँ बोर्ड पर दिए गए प्रश्न से आई हैं। मैंने उन्हें a, b, c नाम दिए थे — वही अब सूत्र में प्रतिस्थापित हैं।`,
        english: `These numbers come directly from the question on the board. I already labelled them a, b, c — those are what got substituted here.`,
      });
    } else if (q.includes('minus') || q.includes('minus kyun') || q.includes('sign')) {
      const rule = lesson.importantSignRules[0];
      text = pick({
        hinglish: `Minus isliye aaya kyunki formula ke beech wale term ka cofactor sign negative hota hai (${rule ? rule.example : '+, −, +'}). Bracket ke aage minus ho to andar ka sign palat jata hai. Ye sabse common galti hai, isliye maine alag se likha hai.`,
        hindi: `ऋण इसलिए आया क्योंकि बीच वाले पद का सह-गुणक चिह्न ऋणात्मक होता है। कोष्ठक के आगे ऋण हो तो अंदर का चिह्न बदल जाता है।`,
        english: `The minus appears because the middle term's cofactor sign is negative (${rule ? rule.example : '+, −, +'}). A minus in front of a bracket flips the sign inside it.`,
      });
      latex = lesson.quickReminder.coloredFormulaLatex;
    } else if (q.includes('formula') || q.includes('dobara')) {
      const f = lesson.formulas[0];
      text = pick({
        hinglish: `Formula ye hai: ${f ? f.name : lesson.quickReminder.formulaName}. ${f ? f.note : ''} Isme signs ka pattern plus, minus, plus hai — beech wala term hamesha minus hota hai.`,
        hindi: `सूत्र यह है। ध्यान रखें कि चिह्नों का क्रम +, −, + है।`,
        english: `The formula is: ${lesson.quickReminder.formulaName}. Note the sign pattern +, −, +.`,
      });
      latex = lesson.quickReminder.formulaLatex;
    } else if (q.includes('example') || q.includes('udaharan')) {
      const pq = lesson.practiceQuestions[0];
      text = pq
        ? pick({
            hinglish: `Lo ek aasaan example. ${pq.question} Pehle chhote parts todo, phir jodo. Iska answer ${pq.finalAnswer} aata hai — pehle khud try karo, main hints dunga.`,
            hindi: `एक आसान उदाहरण लो। पहले छोटे भाग करो, फिर जोड़ो। उत्तर ${pq.finalAnswer} आता है।`,
            english: `Here is an easier example: ${pq.question}. Break it into small parts first. The answer is ${pq.finalAnswer} — try it yourself first.`,
          })
        : simpler;
      latex = pq?.latex;
    } else if (q.includes('hindi')) {
      text = currentStep.speechText.hindi;
    } else if (q.includes('hint') || q.includes('answer mat')) {
      text = pick({
        hinglish: `Sirf hint: pehle ${currentStep.operation} karo, calculation baad mein. Answer abhi nahi bataunga — khud nikalo, main side se guide karunga.`,
        hindi: `केवल संकेत: पहले ${currentStep.operation} करो, गणना बाद में। उत्तर अभी नहीं बताऊँगा।`,
        english: `Hint only: do "${currentStep.operation}" first, calculate afterwards. I will not reveal the answer yet.`,
      });
    } else if (q.includes('galat') || q.includes('wrong') || q.includes('mistake')) {
      text = pick({
        hinglish: `Sabse common galti: ${lesson.commonMistakes[0]} Apne signs aur order dobara check karo — pehle minors, phir signs, phir jodna.`,
        hindi: `सबसे सामान्य गलती: ${lesson.commonMistakes[0]}`,
        english: `The most common mistake is: ${lesson.commonMistakes[0]}`,
      });
    } else {
      text = alt
        ? pick({
            hinglish: `Dusre tareeke se samjhata hoon. Step ${currentStep.stepNumber} ka matlab hai: ${currentStep.whyNecessary}`,
            hindi: `दूसरे तरीके से समझाता हूँ। चरण ${currentStep.stepNumber} का अर्थ है: ${currentStep.whyNecessary}`,
            english: `Let me explain it differently. Step ${currentStep.stepNumber} means: ${currentStep.whyNecessary}`,
          })
        : pick({
            hinglish: `Achha sawal! Step ${currentStep.stepNumber} mein hum "${currentStep.ruleUsed}" use kar rahe hain. ${currentStep.whyNecessary}`,
            hindi: `अच्छा प्रश्न! चरण ${currentStep.stepNumber} में हम ${currentStep.ruleUsed} उपयोग कर रहे हैं।`,
            english: `Good question! In step ${currentStep.stepNumber} we apply "${currentStep.ruleUsed}". ${currentStep.whyNecessary}`,
          });
    }

    return {
      id: `doubt-${Date.now()}`,
      sender: 'teacher',
      text,
      timestamp: Date.now(),
      latex,
      stepRef: currentStep.stepNumber,
    };
  }

  /** Smaller, adaptive follow-up used when a comprehension check is answered wrongly. */
  buildRemediation(lesson: Lesson, currentStep: SolutionStep, language: Language): ChatMessage {
    const rem =
      currentStep.remediation ??
      ({
        title: 'Prerequisite concept',
        explanation: currentStep.whyNecessary,
        easierExample: lesson.revisionSummary[0] || 'Try the same method with smaller numbers.',
      } as any);

    return {
      id: `remediate-${Date.now()}`,
      sender: 'teacher',
      text:
        language === 'hindi'
          ? `Koi baat nahi — pehle ${rem.title} wapas dekhte hain. ${rem.explanation} Chhota example: ${rem.easierExample}`
          : language === 'english'
          ? `That is completely fine. Let us revisit: ${rem.title}. ${rem.explanation} Smaller example: ${rem.easierExample}`
          : `Koi baat nahi beta, chalo pehle ${rem.title} wapas samjhein. ${rem.explanation} Chhota example: ${rem.easierExample}`,
      timestamp: Date.now(),
      latex: rem.easierExampleLatex,
      stepRef: currentStep.stepNumber,
    };
  }
}

export const aiTeacherService = new AiTeacherService();
