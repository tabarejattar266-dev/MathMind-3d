import { BoardAction, Lesson, Narr } from '../types/math';
import { det3Breakdown, det3Sarrus } from './mathVerifier';

/**
 * Blackboard scripts.
 * Every write action is generated from the computed values, so the chalk, the
 * narration and the arithmetic always describe the same numbers.
 */

const T = (hinglish: string, hindi: string, english: string): Narr => ({ hinglish, hindi, english });
const EMPTY: Narr = { hinglish: '', hindi: '', english: '' };

/** Parenthesise negatives for LaTeX: -2 -> (-2). */
const pl = (x: number) => (x < 0 ? `(${x})` : `${x}`);

/** x - y written readably: 3 - (-4) -> "3 + 4". */
const diff = (x: number, y: number) => `${x} ${y < 0 ? '+' : '-'} ${Math.abs(y)}`;

/** Spoken difference: "0 minus 2", "3 plus 4". */
const say = (x: number, y: number) => (y < 0 ? `${x} plus ${-y}` : `${x} minus ${y}`);
const sayHi = (x: number, y: number) => (y < 0 ? `${x} प्लस ${-y}` : `${x} माइनस ${y}`);

/** Spoken number: -4 -> "minus 4". */
const spokenNum = (x: number) => (x < 0 ? `minus ${Math.abs(x)}` : `${x}`);
const spokenNumHi = (x: number) => (x < 0 ? `माइनस ${Math.abs(x)}` : `${x}`);

/** LaTeX term with sign: termStr(-3, "7") -> "- 3(7)". */
const termStr = (coef: number, inner: string) => `${coef < 0 ? '-' : '+'} ${Math.abs(coef)}(${inner})`;

/** Estimated chalk time for a line, proportional to how much is written. */
export const estWrite = (latex: string) => {
  const chars = latex.replace(/\\[a-zA-Z]+/g, 'x').replace(/[{}\\&\s^_]/g, '').length;
  return Math.min(7000, Math.max(1500, chars * 95 + 900));
};

const vm3 = (m: number[][]) =>
  `\\begin{vmatrix} ${m.map((r) => r.join(' & ')).join(' \\\\ ')} \\end{vmatrix}`;

/**
 * Full classroom script for a 3×3 determinant (Laplace expansion along row 1,
 * Sarrus verification and a practice question).
 */
export const buildDet3BoardScript = (M: number[][]): BoardAction[] => {
  const B = det3Breakdown(M);
  const [a, b, c] = M[0];
  const [d, e, f] = M[1];
  const [g, h, i] = M[2];

  // Minors (2×2 determinants) and signed terms — computed, never typed.
  const M1 = e * i - f * h;
  const M2 = d * i - f * g;
  const M3 = d * h - e * g;
  const t1 = a * M1;
  const t2 = -b * M2;
  const t3 = c * M3;
  const det = t1 + t2 + t3;

  const sarrus = det3Sarrus(M);
  const ok = det === B.det && sarrus === det;

  const pos = a * e * i + b * f * g + c * d * h;
  const neg = c * e * g + b * d * i + a * f * h;

  const practice: number[][] = [
    [a + 1, b, c],
    [d, e + 2, f],
    [g, h, i + 1],
  ];

  const acts: BoardAction[] = [];
  const add = (x: Omit<BoardAction, 'id'>): BoardAction => {
    const act: BoardAction = {
      id: `d3-${acts.length}`,
      ...x,
      writeMs: x.kind === 'write' ? x.writeMs ?? estWrite(x.latex ?? '') : x.writeMs,
    };
    acts.push(act);
    return act;
  };

  /* ---------- Group 0 · Understand the question ---------- */
  add({
    kind: 'write',
    stepIndex: 0,
    pinned: true,
    label: 'Question',
    color: 'chalk',
    latex: `\\Delta = ${vm3(M)}`,
    lead: T(
      'Chalo beta, tension mat lo. Sabse pehle board par diye gaye question ko dhyan se dekho.',
      'चलो बच्चों, घबराओ मत। सबसे पहले बोर्ड पर दिए गए प्रश्न को ध्यान से देखो।',
      "Chalo, don't worry. First, look carefully at the question on the board.",
    ),
    narration: T(
      'Humein is three-by-three determinant ki value find karni hai. Yani in nau numbers se ek hi answer nikalna hai.',
      'हमें इस 3x3 सारणिक का मान ज्ञात करना है। इन नौ संख्याओं से हमें एक ही उत्तर निकालना है।',
      'We have to find the value of this three by three determinant. From these nine numbers we get one single answer.',
    ),
    holdMs: 700,
  });

  /* ---------- Group 1 · Formula ---------- */
  const F = add({
    kind: 'write',
    stepIndex: 1,
    label: 'Formula · Laplace expansion',
    color: 'yellow',
    latex: `\\Delta = a(ei - fh) - b(di - fg) + c(dh - eg)`,
    lead: T(
      'Chalo beta, sabse pehle hum determinant ka formula likhenge.',
      'चलो, सबसे पहले हम सारणिक का सूत्र लिखते हैं।',
      'Let us first write the determinant formula.',
    ),
    narration: T(
      'Ye formula Laplace expansion kehlata hai. Dhyan do, beech wale term ke aage minus hai.',
      'यह लाप्लास विस्तार का सूत्र है। ध्यान दो, बीच वाले पद के आगे ऋण चिह्न है।',
      'This is the Laplace expansion formula. Notice the minus sign in front of the middle term.',
    ),
    holdMs: 600,
  });

  add({
    kind: 'point',
    stepIndex: 1,
    refersTo: F.id,
    highlight: ['a', 'e', 'i', 'f', 'h'],
    narration: T(
      'Ab yahan pe a aur e ko multiply karna hai. Chalo dekhte hain ye values kahan se aayi hain.',
      'अब यहाँ a और e को गुणा करना है। चलो देखते हैं ये मान कहाँ से आए हैं।',
      'Here we have to multiply a and e. Let us see where these values come from.',
    ),
  });

  /* ---------- Group 2 · Identify every value ---------- */
  add({
    kind: 'write',
    stepIndex: 2,
    label: 'Row 1 · values',
    color: 'cyan',
    latex: `a = ${a},\\quad b = ${b},\\quad c = ${c}`,
    lead: T('Ab matrix se values nikaalte hain.', 'अब मैट्रिक्स से मान निकालते हैं।', 'Now let us read the values from the matrix.'),
    narration: T(
      `Pehli row se a barabar ${a}, b barabar ${b}, aur c barabar ${c} hai.`,
      `पहली पंक्ति से a = ${a}, b = ${b} और c = ${c} है।`,
      `From the first row, a is ${a}, b is ${b}, and c is ${c}.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 2,
    label: 'Row 2 · values',
    color: 'cyan',
    latex: `d = ${d},\\quad e = ${e},\\quad f = ${f}`,
    narration: T(
      `Doosri row mein d ${spokenNum(d)}, e ${spokenNum(e)}, aur f ${spokenNum(f)} hai.`,
      `दूसरी पंक्ति में d = ${spokenNumHi(d)}, e = ${spokenNumHi(e)} और f = ${spokenNumHi(f)} है।`,
      `In the second row, d is ${spokenNum(d)}, e is ${spokenNum(e)}, and f is ${spokenNum(f)}.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 2,
    label: 'Row 3 · values',
    color: 'cyan',
    latex: `g = ${g},\\quad h = ${h},\\quad i = ${i}`,
    narration: T(
      `Teesri row mein g ${spokenNum(g)}, h ${spokenNum(h)}, aur i ${spokenNum(i)} hai.`,
      `तीसरी पंक्ति में g = ${spokenNumHi(g)}, h = ${spokenNumHi(h)} और i = ${spokenNumHi(i)} है।`,
      `In the third row, g is ${spokenNum(g)}, h is ${spokenNum(h)}, and i is ${spokenNum(i)}.`,
    ),
  });

  add({
    kind: 'erase',
    stepIndex: 2,
    narration: T(
      'Board thoda bhar gaya hai, isliye ise saaf karte hain. Question upar hi rahega.',
      'बोर्ड थोड़ा भर गया है, इसलिए इसे साफ़ करते हैं। प्रश्न ऊपर ही रहेगा।',
      'The board is getting full, so let us clean it. The question stays at the top.',
    ),
  });

  /* ---------- Group 3 · Substitute and calculate ---------- */
  add({
    kind: 'write',
    stepIndex: 3,
    label: 'Substitute',
    color: 'chalk',
    latex: `\\Delta = ${pl(a)}(${pl(e)} \\times ${pl(i)} - ${pl(f)} \\times ${pl(h)}) ${termStr(
      -b,
      `${pl(d)} \\times ${pl(i)} - ${pl(f)} \\times ${pl(g)}`,
    )} ${termStr(c, `${pl(d)} \\times ${pl(h)} - ${pl(e)} \\times ${pl(g)}`)}`,
    lead: T(
      'Ab in values ko formula mein substitute karte hain.',
      'अब इन मानों को सूत्र में प्रतिस्थापित करते हैं।',
      'Now we substitute these values into the formula.',
    ),
    narration: T(
      'Har letter ki jagah uska number rakh diya hai. Abhi calculate nahi karna, sirf replace kiya hai.',
      'हर अक्षर की जगह उसकी संख्या रख दी है। अभी गणना नहीं करनी, केवल प्रतिस्थापन किया है।',
      'Every letter is replaced by its number. We are not calculating yet, only substituting.',
    ),
  });

  add({
    kind: 'write',
    stepIndex: 3,
    color: 'chalk',
    latex: `\\Delta = ${a}(${diff(e * i, f * h)}) ${termStr(-b, diff(d * i, f * g))} ${termStr(c, diff(d * h, e * g))}`,
    lead: T(
      'Ab bracket ke andar pehle multiply karte hain.',
      'अब कोष्ठक के अंदर पहले गुणा करते हैं।',
      'Now inside the brackets we multiply first.',
    ),
    narration: T(
      `Har bracket ke andar pehle multiply, phir subtract. Pehla: ${say(e * i, f * h)}, barabar ${M1}. Doosra: ${say(
        d * i,
        f * g,
      )}, barabar ${M2}. Teesra: ${say(d * h, e * g)}, barabar ${M3}.`,
      `हर कोष्ठक में पहले गुणा, फिर घटाव। पहला: ${sayHi(e * i, f * h)} = ${spokenNumHi(M1)}। दूसरा: ${sayHi(
        d * i,
        f * g,
      )} = ${spokenNumHi(M2)}। तीसरा: ${sayHi(d * h, e * g)} = ${spokenNumHi(M3)}।`,
      `Inside each bracket, multiply first and then subtract. First: ${say(e * i, f * h)}, which is ${M1}. Second: ${say(
        d * i,
        f * g,
      )}, which is ${M2}. Third: ${say(d * h, e * g)}, which is ${M3}.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 3,
    color: 'chalk',
    latex: `\\Delta = ${pl(a)}(${M1}) ${termStr(-b, String(M2))} ${termStr(c, String(M3))}`,
    lead: T('Ab har bracket ka answer likhte hain.', 'अब हर कोष्ठक का उत्तर लिखते हैं।', 'Now we write the answer of each bracket.'),
    narration: T(
      `Ab teeno brackets ke answers: ${spokenNum(M1)}, ${spokenNum(M2)}, aur ${spokenNum(M3)}. Inko formula mein rakh diya hai.`,
      `अब तीनों कोष्ठकों के उत्तर: ${spokenNumHi(M1)}, ${spokenNumHi(M2)} और ${spokenNumHi(M3)} हैं।`,
      `Now the three bracket answers are ${spokenNum(M1)}, ${spokenNum(M2)}, and ${spokenNum(M3)}. We place them in the formula.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 3,
    color: 'chalk',
    latex: `\\Delta = ${t1} ${t2 < 0 ? '-' : '+'} ${Math.abs(t2)} ${t3 < 0 ? '-' : '+'} ${Math.abs(t3)}`,
    lead: T('Ab har term ko uske bracket value se multiply karte hain.', 'अब हर पद को उसके मान से गुणा करते हैं।', 'Now we multiply each term by its bracket value.'),
    narration: T(
      `Pehla term: ${a} into ${M1} barabar ${spokenNum(t1)}. Doosra: ${b >= 0 ? 'minus ' + b : 'plus ' + -b} into ${M2}, yaani ${spokenNum(
        t2,
      )}. Teesra: ${c >= 0 ? 'plus ' + c : 'minus ' + -c} into ${M3} barabar ${spokenNum(t3)}.`,
      `पहला पद: ${a} गुणा ${M1} = ${spokenNumHi(t1)}। दूसरा पद: ${spokenNumHi(-b)} गुणा ${M2} = ${spokenNumHi(t2)}। तीसरा पद: ${spokenNumHi(c)} गुणा ${M3} = ${spokenNumHi(t3)}।`,
      `First term: ${a} times ${M1} equals ${spokenNum(t1)}. Second term: ${b >= 0 ? 'minus ' + b : 'plus ' + -b} times ${M2}, which is ${spokenNum(
        t2,
      )}. Third term: ${c >= 0 ? 'plus ' + c : 'minus ' + -c} times ${M3} equals ${spokenNum(t3)}.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 3,
    label: 'Result of the expansion',
    color: ok ? 'emerald' : 'rose',
    latex: `\\Delta = \\mathbf{${det}}`,
    narration: T(
      `Sab terms jodte hain: ${spokenNum(t1)}, ${spokenNum(t2)}, aur ${spokenNum(t3)}. Total ${spokenNum(det)} aata hai.`,
      `सभी पदों को जोड़ें: ${spokenNumHi(t1)}, ${spokenNumHi(t2)} और ${spokenNumHi(t3)}। कुल ${spokenNumHi(det)} आता है।`,
      `Add all the terms: ${spokenNum(t1)}, ${spokenNum(t2)}, and ${spokenNum(t3)}. The total is ${spokenNum(det)}.`,
    ),
    holdMs: 900,
  });

  /* ---------- Group 4 · Verify ---------- */
  add({
    kind: 'erase',
    stepIndex: 4,
    narration: T(
      'Ab answer ko doosre tareeke se check karte hain. Board saaf karte hain.',
      'अब उत्तर को दूसरी विधि से जाँचते हैं। बोर्ड साफ़ करते हैं।',
      'Now let us check the answer with a second method. Let us clean the board.',
    ),
  });

  add({
    kind: 'write',
    stepIndex: 4,
    label: 'Verify · Sarrus rule',
    color: 'emerald',
    latex: `\\text{Sarrus: } \\Delta = aei + bfg + cdh - ceg - bdi - afh`,
    lead: T('Ab dusre method se verify karte hain.', 'अब दूसरी विधि से जाँचते हैं।', 'Now let us verify with another method.'),
    narration: T(
      'Ye Sarrus rule hai. Teen downward diagonals ke products jodte hain, aur teen upward diagonals ke products ghatate hain.',
      'यह सैरस नियम है। तीन नीचे जाने वाले विकर्णों के गुणनफल जोड़ते हैं और तीन ऊपर जाने वाले घटाते हैं।',
      'This is the Sarrus rule. We add the three downward diagonal products and subtract the three upward ones.',
    ),
  });

  add({
    kind: 'write',
    stepIndex: 4,
    color: 'chalk',
    latex: `\\Delta = ${pl(a * e * i)} + ${pl(b * f * g)} + ${pl(c * d * h)} - ${pl(c * e * g)} - ${pl(b * d * i)} - ${pl(a * f * h)}`,
    narration: T(
      `Plus wale diagonals ka sum ${spokenNum(pos)} hai. Minus wale diagonals ka sum ${spokenNum(neg)} hai.`,
      `धनात्मक विकर्णों का योग ${spokenNumHi(pos)} है। ऋणात्मक विकर्णों का योग ${spokenNumHi(neg)} है।`,
      `The downward diagonals add up to ${spokenNum(pos)}. The upward diagonals add up to ${spokenNum(neg)}.`,
    ),
  });

  add({
    kind: 'write',
    stepIndex: 4,
    color: ok ? 'emerald' : 'rose',
    latex: ok ? `\\Delta = ${diff(pos, neg)} = ${det}` : `\\text{Mismatch: recheck the working}`,
    narration: ok
      ? T(
          `${say(pos, neg)} barabar ${det}. Ye Sarrus ka answer hai.`,
          `${sayHi(pos, neg)} = ${spokenNumHi(det)}। यह सैरस का उत्तर है।`,
          `${say(pos, neg)} equals ${det}. This is the Sarrus answer.`,
        )
      : T('Dono methods mein fark hai, isliye hum dobara check karenge.', 'दोनों विधियों में अंतर है, इसलिए हम दोबारा जाँचेंगे।', 'The two methods disagree, so we will check again.'),
  });

  add({
    kind: 'write',
    stepIndex: 4,
    label: 'Verified answer',
    color: ok ? 'emerald' : 'rose',
    latex: ok ? `\\therefore \\Delta = \\mathbf{${det}} \\quad \\text{(verified)}` : `\\text{Recheck required}`,
    narration: ok
      ? T(
          `Dono methods se ${det} aaya. Isliye answer ${det} verified hai. Shabash beta!`,
          `दोनों विधियों से ${spokenNumHi(det)} आया। इसलिए उत्तर ${spokenNumHi(det)} सत्यापित है। शाबाश!`,
          `Both methods give ${det}. So the answer ${det} is verified. Well done!`,
        )
      : T('Recheck zaroori hai.', 'दोबारा जाँच ज़रूरी है।', 'A recheck is needed.'),
    holdMs: 900,
  });

  /* ---------- Group 5 · Your turn ---------- */
  add({
    kind: 'write',
    stepIndex: 5,
    label: 'Your turn',
    color: 'yellow',
    latex: `\\Delta = ${vm3(practice)}`,
    lead: T('Ab tumhari baari!', 'अब तुम्हारी बारी!', 'Now it is your turn!'),
    narration: T(
      'Ye naya determinant board par hai. Pehle teen minors nikaalo, phir signs lagao, phir jodo. Answer aane par Practice button se check karo.',
      'यह नया सारणिक बोर्ड पर है। पहले तीन माइनर निकालो, फिर चिह्न लगाओ, फिर जोड़ो। उत्तर आने पर Practice बटन से जाँचो।',
      'This new determinant is on the board. First find the three minors, apply the signs, then add. Check your answer with the Practice button.',
    ),
    holdMs: 900,
  });

  return acts;
};

/**
 * Generic adapter: turns any existing lesson's cues into a blackboard script,
 * so every lesson type (2×2, linear, quadratic…) uses the same writing engine.
 */
export const cuesToBoardScript = (lesson: Lesson): BoardAction[] => {
  const out: BoardAction[] = [];
  let lastWriteId: string | undefined;
  let sinceErase = 0;

  lesson.cues.forEach((cue, ci) => {
    const lines = cue.boardAppend ?? [];

    if (lines.length === 0) {
      out.push({
        id: `c${ci}-p`,
        kind: 'point',
        stepIndex: cue.stepIndex,
        refersTo: lastWriteId,
        highlight: cue.highlightTerms,
        narration: cue.narration,
      });
      return;
    }

    lines.forEach((ln, li) => {
      if (sinceErase >= 5) {
        out.push({ id: `c${ci}-${li}-erase`, kind: 'erase', stepIndex: cue.stepIndex, narration: EMPTY });
        sinceErase = 0;
      }
      const id = `c${ci}-${li}`;
      out.push({
        id,
        kind: 'write',
        stepIndex: cue.stepIndex,
        latex: ln.latex,
        color: ln.color,
        label: ln.label,
        pinned: cue.stage === 'question' && li === 0 ? true : undefined,
        narration: li === lines.length - 1 ? cue.narration : EMPTY,
        writeMs: estWrite(ln.latex),
      });
      sinceErase += 1;
      lastWriteId = id;
    });
  });

  return out;
};
