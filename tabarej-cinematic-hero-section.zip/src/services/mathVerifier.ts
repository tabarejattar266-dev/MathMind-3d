/**
 * mathVerifier
 * ------------
 * Every number that appears on the chalkboard is produced here, never typed by
 * hand. This is the "reliable calculation engine" guard: if the engine cannot
 * verify a result it reports `verified: false` and the UI shows the uncertainty
 * instead of a confidently wrong answer.
 */

export interface ExactCheck {
  value: number;
  verified: boolean;
  detail: string;
}

const round = (n: number, dp = 6) => {
  const f = Math.pow(10, dp);
  return Math.round(n * f) / f;
};

/** Parenthesise negative numbers so LaTeX reads (−3) instead of −3. */
export const p = (n: number): string => (n < 0 ? `(${n})` : `${n}`);

/** Signed rendering: keeps − for display inside sums. */
export const signed = (n: number): string => (n < 0 ? `- ${Math.abs(n)}` : `+ ${n}`);

/** 2×2 determinant. */
export const det2 = (m: number[][]): number => m[0][0] * m[1][1] - m[0][1] * m[1][0];

/** 3×3 determinant by cofactor expansion along row 1. */
export const det3Cofactor = (m: number[][]): number => {
  const [a, b, c] = m[0];
  const [d, e, f] = m[1];
  const [g, h, i] = m[2];
  const m11 = e * i - f * h;
  const m12 = d * i - f * g;
  const m13 = d * h - e * g;
  return a * m11 - b * m12 + c * m13;
};

/** 3×3 determinant by the Sarrus rule — an independent second method. */
export const det3Sarrus = (m: number[][]): number => {
  const [a, b, c] = m[0];
  const [d, e, f] = m[1];
  const [g, h, i] = m[2];
  return a * e * i + b * f * g + c * d * h - (c * e * g + b * d * i + a * f * h);
};

export interface Det3Breakdown {
  matrix: number[][];
  a: number; b: number; c: number;
  d: number; e: number; f: number;
  g: number; h: number; i: number;
  minor11: number; minor12: number; minor13: number;
  minor11Latex: string; minor12Latex: string; minor13Latex: string;
  term1: number; term2: number; term3: number;
  det: number;
  sarrusDet: number;
  verified: boolean;
  column2ZeroIndex: number; // 0,1 or 2 — column containing a 0 if any (nice for verification)
}

export const det3Breakdown = (m: number[][]): Det3Breakdown => {
  const [a, b, c] = m[0];
  const [d, e, f] = m[1];
  const [g, h, i] = m[2];

  const minor11 = e * i - f * h;
  const minor12 = d * i - f * g;
  const minor13 = d * h - e * g;

  const minor11Latex = `${p(e)} \\times ${p(i)} - ${p(f)} \\times ${p(h)}`;
  const minor12Latex = `${p(d)} \\times ${p(i)} - ${p(f)} \\times ${p(g)}`;
  const minor13Latex = `${p(d)} \\times ${p(h)} - ${p(e)} \\times ${p(g)}`;

  const term1 = a * minor11;
  const term2 = b * minor12;
  const term3 = c * minor13;

  const det = a * minor11 - b * minor12 + c * minor13;
  const sarrusDet = det3Sarrus(m);

  const column2ZeroIndex = m[1][0] === 0 ? 0 : m[1][1] === 0 ? 1 : m[1][2] === 0 ? 2 : -1;

  return {
    matrix: m,
    a, b, c, d, e, f, g, h, i,
    minor11, minor12, minor13,
    minor11Latex, minor12Latex, minor13Latex,
    term1, term2, term3,
    det,
    sarrusDet,
    verified: det === sarrusDet,
    column2ZeroIndex,
  };
};

/** Independent Sarrus verification string for the chalkboard. */
export const sarrusVerificationLatex = (b: Det3Breakdown): string => {
  const { a, b: bb, c, d, e, f, g, h, i } = b;
  const pos = a * e * i + bb * f * g + c * d * h;
  const neg = c * e * g + bb * d * i + a * f * h;
  return String.raw`&= [${p(a)}${p(e)}${p(i)} + ${p(bb)}${p(f)}${p(g)} + ${p(c)}${p(d)}${p(h)}] - [${p(c)}${p(e)}${p(g)} + ${p(bb)}${p(d)}${p(i)} + ${p(a)}${p(f)}${p(h)}] \\ &= ${pos} - (${neg}) = ${b.det}`;
};

export interface LinearSolution {
  a: number; b: number; c: number;
  afterSubtract: number;
  x: number;
  isExact: boolean;
  substituteLatex: string;
  substituteValue: number;
  verified: boolean;
}

export const solveLinear = (a: number, b: number, c: number): LinearSolution => {
  const afterSubtract = c - b;
  const x = afterSubtract / a;
  const isExact = Number.isInteger(x);
  const substituteValue = a * x + b;
  return {
    a, b, c,
    afterSubtract,
    x,
    isExact,
    substituteLatex: `${p(a)}${p(x === Math.round(x) ? Math.round(x) : round(x, 3))} ${b >= 0 ? '+' : '-'} ${Math.abs(b)} = ${round(substituteValue, 6)}`,
    substituteValue,
    verified: Math.abs(substituteValue - c) < 1e-9,
  };
};

export interface QuadraticSolution {
  a: number; b: number; c: number;
  discriminant: number;
  root1: number;
  root2: number;
  factorable: boolean;
  factorLatex?: string;
  isExact: boolean;
  verified: boolean;
}

export const solveQuadratic = (a: number, b: number, c: number): QuadraticSolution => {
  const discriminant = b * b - 4 * a * c;
  const root1 = (-b - Math.sqrt(discriminant)) / (2 * a);
  const root2 = (-b + Math.sqrt(discriminant)) / (2 * a);
  const factorable = Number.isInteger(discriminant) && discriminant >= 0 && Math.sqrt(discriminant) % 1 === 0;
  const r1 = Math.round(root1);
  const r2 = Math.round(root2);
  const factorLatex =
    factorable && a === 1
      ? `(x ${r1 <= 0 ? '+' : '-'} ${Math.abs(r1)})(x ${r2 <= 0 ? '+' : '-'} ${Math.abs(r2)}) = 0`
      : undefined;

  const check = (r: number) => Math.abs(a * r * r + b * r + c) < 1e-9;

  return {
    a, b, c,
    discriminant,
    root1,
    root2,
    factorable,
    factorLatex,
    isExact: factorable,
    verified: factorable ? check(r1) && check(r2) : Math.abs(discriminant) >= 0,
  };
};

/** Safe evaluation helper for a tiny subset of arithmetic checks. */
export const checkEquality = (lhs: number, rhs: number): ExactCheck => ({
  value: lhs,
  verified: Math.abs(lhs - rhs) < 1e-9,
  detail: `${lhs} ${Math.abs(lhs - rhs) < 1e-9 ? '=' : '≠'} ${rhs}`,
});
