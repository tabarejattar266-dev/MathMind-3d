import { BoardAction, Language, Narr } from '../types/math';
import { speechService } from './speechService';

/**
 * WritingTimeline
 * ---------------
 * The single clock of the classroom. Every board action goes through phases:
 *
 *   write   : chalk writes the line (progress 0→1). `lead` narration plays while the chalk starts.
 *   explain : `narration` plays once the line is fully visible (points/highlights apply here).
 *   hold    : short pause so the student can absorb the line.
 *   erase   : eraser sweep (for erase actions), `narration` may play.
 *
 * A phase only ends when its clock has run AND its narration has finished, so
 * the teacher never speaks about a symbol that is not on the board yet.
 *
 * Pause stops the clock and the speech together; play resumes the same phase.
 */

export type Phase = 'write' | 'explain' | 'hold' | 'erase';

export interface FrameInfo {
  index: number;
  action: BoardAction;
  phase: Phase;
  /** 0..1 chalk progress for write actions. */
  progress: number;
  /** 0..1 eraser sweep for erase actions. */
  wipe: number;
  playing: boolean;
}

export interface TimelineSnapshot {
  index: number;
  total: number;
  phase: Phase;
  playing: boolean;
  finished: boolean;
  stepIndex: number;
  speed: number;
  voiceOn: boolean;
  language: Language;
  caption: string;
  visibleActions: BoardAction[];
  currentAction: BoardAction | null;
}

const EMPTY_ACTION: BoardAction = {
  id: 'empty',
  kind: 'write',
  stepIndex: 0,
  latex: '',
  narration: { hinglish: '', hindi: '', english: '' },
};

const pick = (n: Narr | undefined, lang: Language) => (n ? n[lang] || n.hinglish || '' : '');

/** Rough spoken duration of a sentence at normal speed. */
const estimateMs = (text: string) => {
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  return words * 380 + 450;
};

export class WritingTimeline {
  private actions: BoardAction[];
  private language: Language;
  private speed = 1;
  private voiceOn = true;

  private index = 0;
  private phase: Phase = 'write';
  private elapsed = 0;
  private playing = false;
  private finished = false;

  private raf = 0;
  private lastTs = 0;

  private speechDone = true;
  private phaseSpoken = false;
  private speechToken = 0;

  private snap!: TimelineSnapshot;
  private subs = new Set<() => void>();
  private frameSubs = new Set<(f: FrameInfo) => void>();

  constructor(actions: BoardAction[], language: Language) {
    this.actions = actions.length ? actions : [EMPTY_ACTION];
    this.language = language;
    this.snap = this.buildSnapshot();
  }

  /* ------------------------------------------------------------------ */
  /* React store API                                                     */
  /* ------------------------------------------------------------------ */

  subscribe = (fn: () => void) => {
    this.subs.add(fn);
    return () => {
      this.subs.delete(fn);
    };
  };

  getSnapshot = () => this.snap;

  /** Per-frame subscription used by the chalkboard painter (no React re-render). */
  onFrame = (fn: (f: FrameInfo) => void) => {
    this.frameSubs.add(fn);
    return () => {
      this.frameSubs.delete(fn);
    };
  };

  emitNow() {
    this.emitFrame();
  }

  /* ------------------------------------------------------------------ */
  /* Public controls                                                     */
  /* ------------------------------------------------------------------ */

  play() {
    if (this.playing) return;
    this.playing = true;
    if (this.finished) {
      this.goTo(0);
    } else {
      speechService.resume();
      if (!this.phaseSpoken) this.startPhaseSpeech();
    }
    this.lastTs = 0;
    this.raf = requestAnimationFrame(this.loop);
    this.notify();
    this.emitFrame();
  }

  pause() {
    if (!this.playing) return;
    this.playing = false;
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    speechService.pause();
    this.notify();
    this.emitFrame();
  }

  toggle() {
    if (this.playing) this.pause();
    else this.play();
  }

  /** Restart the current action from its first symbol and play it. */
  replay() {
    this.playing = false;
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.goTo(this.index);
    this.play();
  }

  next() {
    if (this.index < this.actions.length - 1) this.jump(this.index + 1);
  }

  prev() {
    if (this.index > 0) this.jump(this.index - 1);
  }

  /** Jump to the first action of the next lesson step (the teacher moves on). */
  nextStep() {
    const cur = this.actions[this.index].stepIndex;
    const j = this.actions.findIndex((a, k) => k > this.index && a.stepIndex > cur);
    if (j >= 0) this.jump(j);
  }

  /** Jump to the first action of the current step, or of the previous one. */
  prevStep() {
    const cur = this.actions[this.index].stepIndex;
    const start = this.actions.findIndex((a) => a.stepIndex === cur);
    if (this.index > start) {
      this.jump(start);
      return;
    }
    const prevStart = this.actions.findIndex((a) => a.stepIndex === cur - 1);
    if (prevStart >= 0) this.jump(prevStart);
    else this.jump(0);
  }

  setSpeed(s: number) {
    this.speed = s;
    speechService.setRate(s);
    this.notify();
  }

  setLanguage(l: Language) {
    if (l === this.language) return;
    this.language = l;
    speechService.stop();
    this.phaseSpoken = false;
    if (this.playing) this.startPhaseSpeech();
    this.notify();
  }

  setVoice(on: boolean) {
    if (on === this.voiceOn) return;
    this.voiceOn = on;
    speechService.stop();
    this.phaseSpoken = false;
    this.speechDone = true;
    if (on && this.playing) this.startPhaseSpeech();
    this.notify();
  }

  /** Called after a student's doubt has been answered: re-speak the current sentence and continue. */
  resumeAfterDoubt() {
    speechService.stop();
    this.phaseSpoken = false;
    this.speechDone = true;
    this.play();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.playing = false;
    speechService.stop();
  }

  /* ------------------------------------------------------------------ */
  /* Internals                                                           */
  /* ------------------------------------------------------------------ */

  private current(): BoardAction {
    return this.actions[this.index] ?? EMPTY_ACTION;
  }

  private phasesFor(a: BoardAction): Phase[] {
    if (a.kind === 'erase') return ['erase', 'hold'];
    if (a.kind === 'point') return ['explain', 'hold'];
    return ['write', 'explain', 'hold'];
  }

  private specFor(p: Phase): { minMs: number; text: string } {
    const a = this.current();
    switch (p) {
      case 'write':
        return { minMs: a.writeMs ?? 2400, text: pick(a.lead, this.language) };
      case 'explain':
        return { minMs: 450, text: pick(a.narration, this.language) };
      case 'erase':
        return { minMs: 900, text: pick(a.narration, this.language) };
      default:
        return { minMs: a.holdMs ?? 450, text: '' };
    }
  }

  private canLeave(): boolean {
    const s = this.specFor(this.phase);
    const speaking = this.voiceOn && !!s.text && speechService.isAvailable();

    if (!speaking) {
      const est = s.text ? estimateMs(s.text) : 0;
      return this.elapsed >= Math.max(s.minMs, est);
    }

    // With a voice: wait for the sentence to finish (minimum time keeps the pace human).
    const minWithVoice = Math.max(s.minMs, estimateMs(s.text) * 0.6);
    if (this.elapsed < minWithVoice) return false;
    if (this.speechDone) return true;
    // Safety net: never stall the lesson if the browser never reports the end.
    return this.elapsed > estimateMs(s.text) * 3 + 8000;
  }

  private startPhaseSpeech() {
    const s = this.specFor(this.phase);
    this.phaseSpoken = true;
    if (!s.text || !this.voiceOn || !speechService.isAvailable()) {
      this.speechDone = true;
      return;
    }
    this.speechDone = false;
    const tok = ++this.speechToken;
    speechService.speak(s.text, this.language, {
      onEnd: () => {
        if (tok === this.speechToken) this.speechDone = true;
      },
      onError: () => {
        if (tok === this.speechToken) this.speechDone = true;
      },
    });
  }

  private enterPhase(p: Phase) {
    this.phase = p;
    this.elapsed = 0;
    speechService.stop();
    this.phaseSpoken = false;
    this.speechDone = true;
    if (this.playing) this.startPhaseSpeech();
    this.notify();
  }

  private goTo(i: number) {
    if (i >= this.actions.length) {
      this.finished = true;
      this.playing = false;
      cancelAnimationFrame(this.raf);
      this.raf = 0;
      this.index = this.actions.length - 1;
      this.phase = 'hold';
      this.elapsed = 0;
      this.notify();
      this.emitFrame();
      return;
    }
    this.finished = false;
    this.index = Math.max(0, i);
    this.phase = this.phasesFor(this.current())[0];
    this.elapsed = 0;
    speechService.stop();
    this.phaseSpoken = false;
    this.speechDone = true;
    if (this.playing) this.startPhaseSpeech();
    this.notify();
    this.emitFrame();
  }

  private jump(i: number) {
    const wasPlaying = this.playing;
    this.playing = false;
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.goTo(i);
    if (wasPlaying) this.play();
  }

  private advance(ms: number) {
    this.elapsed += ms;
    if (!this.canLeave()) return;
    const phases = this.phasesFor(this.current());
    const k = phases.indexOf(this.phase);
    if (k < phases.length - 1) this.enterPhase(phases[k + 1]);
    else this.goTo(this.index + 1);
  }

  private loop = (ts: number) => {
    this.raf = 0;
    if (!this.playing) return;
    if (!this.lastTs) this.lastTs = ts;
    const dt = Math.min(ts - this.lastTs, 120);
    this.lastTs = ts;
    this.advance(dt * this.speed);
    this.emitFrame();
    if (this.playing) this.raf = requestAnimationFrame(this.loop);
  };

  private emitFrame() {
    const a = this.current();
    const progress =
      this.phase === 'write'
        ? Math.min(1, this.elapsed / Math.max(1, a.writeMs ?? 2400))
        : this.phase === 'erase'
        ? 0
        : 1;
    const wipe = this.phase === 'erase' ? Math.min(1, this.elapsed / 900) : 0;
    const info: FrameInfo = {
      index: this.index,
      action: a,
      phase: this.phase,
      progress,
      wipe,
      playing: this.playing,
    };
    this.frameSubs.forEach((fn) => fn(info));
  }

  private notify() {
    this.snap = this.buildSnapshot();
    this.subs.forEach((fn) => fn());
  }

  private buildSnapshot(): TimelineSnapshot {
    const cur = this.current();

    // Lines currently on the board: writes since the last erase, plus pinned lines.
    let list: number[] = [];
    for (let k = 0; k <= this.index && k < this.actions.length; k++) {
      const act = this.actions[k];
      if (act.kind === 'erase') {
        const erasedNow = k < this.index || this.phase === 'hold';
        if (erasedNow) list = list.filter((j) => this.actions[j].pinned);
      } else if (act.kind === 'write') {
        list.push(k);
      }
    }

    return {
      index: this.index,
      total: this.actions.length,
      phase: this.phase,
      playing: this.playing,
      finished: this.finished,
      stepIndex: cur.stepIndex,
      speed: this.speed,
      voiceOn: this.voiceOn,
      language: this.language,
      caption: this.specFor(this.phase).text,
      visibleActions: list.map((j) => this.actions[j]),
      currentAction: this.actions[this.index] ?? null,
    };
  }
}
