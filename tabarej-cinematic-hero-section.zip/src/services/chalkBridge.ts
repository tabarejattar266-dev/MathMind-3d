/**
 * chalkBridge
 * -----------
 * Tiny shared state between the 2D chalkboard (where the chalk tip is drawn)
 * and the 3D classroom (where the teacher's arm must reach that tip).
 *
 *  - target : normalised (0..1) position of the chalk tip / pointer on the board.
 *  - mode   : 'write' (chalk on the board), 'point' (pointer, no writing), 'idle'.
 *  - frameEl / projectOverlay : the board frame is projected onto the 3D board
 *    every frame so the 2D writing sits exactly on the green board in the scene.
 */
export type ChalkMode = 'idle' | 'write' | 'point';

export const chalkBridge: {
  frameEl: HTMLElement | null;
  overlayEl: HTMLElement | null;
  projectOverlay: boolean;
  target: { nx: number; ny: number } | null;
  mode: ChalkMode;
} = {
  frameEl: null,
  overlayEl: null,
  projectOverlay: false,
  target: null,
  mode: 'idle',
};
