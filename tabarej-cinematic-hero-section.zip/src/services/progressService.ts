import { StudentProgress } from '../types/math';

const STORAGE_KEY = 'mathmind_3d_student_progress_v1';

const DEFAULT_PROGRESS: StudentProgress = {
  topicsStudied: 3,
  questionsAttempted: 8,
  practiceAccuracy: 88,
  streakDays: 4,
  completedLessonIds: ['det-2x2-basic'],
  savedQuestionIds: [],
  weakTopics: ['Trigonometry Signs in Q3', 'Sign changes in 3x3 Minors'],
  lastActiveDate: new Date().toISOString().split('T')[0],
};

class ProgressService {
  public getProgress(): StudentProgress {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        this.saveProgress(DEFAULT_PROGRESS);
        return DEFAULT_PROGRESS;
      }
      const parsed: StudentProgress = JSON.parse(stored);
      this.updateStreakIfNeeded(parsed);
      return parsed;
    } catch (e) {
      console.warn('Could not read progress from localStorage:', e);
      return DEFAULT_PROGRESS;
    }
  }

  public saveProgress(progress: StudentProgress) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (e) {
      console.warn('Could not save progress to localStorage:', e);
    }
  }

  private updateStreakIfNeeded(progress: StudentProgress) {
    const today = new Date().toISOString().split('T')[0];
    if (progress.lastActiveDate === today) return;

    const last = new Date(progress.lastActiveDate);
    const curr = new Date(today);
    const diffDays = Math.round((curr.getTime() - last.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 1) {
      progress.streakDays += 1;
    } else if (diffDays > 1) {
      progress.streakDays = 1; // Reset streak if missed more than 1 day
    }
    progress.lastActiveDate = today;
    this.saveProgress(progress);
  }

  public completeLesson(lessonId: string) {
    const progress = this.getProgress();
    if (!progress.completedLessonIds.includes(lessonId)) {
      progress.completedLessonIds.push(lessonId);
      progress.topicsStudied = Math.max(progress.topicsStudied, progress.completedLessonIds.length + 2);
      this.saveProgress(progress);
    }
  }

  public recordPracticeAttempt(isCorrect: boolean) {
    const progress = this.getProgress();
    progress.questionsAttempted += 1;
    if (isCorrect) {
      progress.practiceAccuracy = Math.min(100, Math.round(((progress.practiceAccuracy * (progress.questionsAttempted - 1) + 100) / progress.questionsAttempted)));
    } else {
      progress.practiceAccuracy = Math.max(0, Math.round(((progress.practiceAccuracy * (progress.questionsAttempted - 1) + 0) / progress.questionsAttempted)));
    }
    this.saveProgress(progress);
  }

  public toggleSaveQuestion(questionId: string): boolean {
    const progress = this.getProgress();
    const index = progress.savedQuestionIds.indexOf(questionId);
    let isSaved = false;
    if (index >= 0) {
      progress.savedQuestionIds.splice(index, 1);
      isSaved = false;
    } else {
      progress.savedQuestionIds.push(questionId);
      isSaved = true;
    }
    this.saveProgress(progress);
    return isSaved;
  }

  public resetProgress(): StudentProgress {
    this.saveProgress(DEFAULT_PROGRESS);
    return DEFAULT_PROGRESS;
  }
}

export const progressService = new ProgressService();
