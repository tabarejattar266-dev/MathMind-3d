import { Language } from '../types/math';

export interface SpeechCallbacks {
  onStart?: () => void;
  onEnd?: () => void;
  onBoundary?: (charIndex: number) => void;
  onError?: (err: any) => void;
}

export type VoiceStatus = 'unknown' | 'checking' | 'ready' | 'unavailable';

/**
 * A same-origin Node deployment needs no configuration. For a static Arena
 * frontend, set the public URL in public/voice-config.json after deploying
 * the backend, or set VITE_TTS_ENDPOINT when Arena builds the frontend.
 * Only a public endpoint belongs here; never an API key.
 */
const viteEnv = (import.meta as any).env ?? {};
const isLocalBrowser =
  typeof window !== 'undefined' &&
  /^(localhost|127\.0\.0\.1|\[::1\])$/.test(window.location.hostname);
const DEFAULT_TTS_ENDPOINT =
  viteEnv.DEV && isLocalBrowser ? 'http://localhost:8787/api/tts' : '/api/tts';
const RUNTIME_CONFIG_URL = '/voice-config.json';

const voiceError = (code: string, message: string) => {
  const err = new Error(message) as Error & { code?: string };
  err.code = code;
  return err;
};

/**
 * Teacher voice service.
 *
 * The ONLY speech source is the ElevenLabs backend using the requested
 * voice "Michael C. Vincent — Suspenseful Storyteller". There is no
 * browser SpeechSynthesis fallback: when the backend, key or voice is
 * unavailable, speak() reports a clear VOICE_UNAVAILABLE error so the UI
 * can show an error + retry, while captions and the lesson continue.
 */
class SpeechService {
  private audio: HTMLAudioElement = new Audio();
  private currentObjectUrl: string | null = null;
  private requestId = 0;
  private activeCallbacks?: SpeechCallbacks;
  private isSpeaking = false;
  private isPaused = false;
  private rate = 1.0;
  private recognition: any = null;

  private backendAvailable: boolean | null = null;
  private resolvedEndpoint: string | null = null;
  private status: VoiceStatus = 'unknown';
  private lastError: string | null = null;
  private listeners = new Set<(status: VoiceStatus, message: string | null) => void>();

  public isAvailable(): boolean {
    // Optimistic until the backend check proves otherwise, so the lesson
    // timeline attempts speech and simply moves on if it fails.
    return this.backendAvailable !== false;
  }

  public setRate(newRate: number) {
    this.rate = Math.max(0.5, Math.min(2.0, newRate));
    try {
      this.audio.playbackRate = this.rate;
    } catch {
      /* no audio loaded yet */
    }
  }

  public getRate(): number {
    return this.rate;
  }

  /* ---------------- voice status (for UI error + retry) ---------------- */

  private setStatus(status: VoiceStatus, message: string | null = null) {
    this.status = status;
    this.lastError = message;
    this.listeners.forEach((fn) => fn(status, message));
  }

  /** Subscribe to voice availability changes. Fires immediately once. */
  public onVoiceStatus(fn: (status: VoiceStatus, message: string | null) => void) {
    this.listeners.add(fn);
    fn(this.status, this.lastError);
    return () => {
      this.listeners.delete(fn);
    };
  }

  public getVoiceStatus() {
    return { status: this.status, message: this.lastError };
  }

  /** Runtime URL can be set without putting credentials in a frontend build. */
  private async getEndpoint(force = false): Promise<string> {
    if (!force && this.resolvedEndpoint) return this.resolvedEndpoint;
    let candidate = String(viteEnv.VITE_TTS_ENDPOINT || '').trim();
    if (!candidate) {
      try {
        const response = await fetch(RUNTIME_CONFIG_URL, {
          cache: 'no-store',
          signal: AbortSignal.timeout(5000),
        });
        if (response.ok && response.headers.get('content-type')?.includes('application/json')) {
          const config = await response.json();
          candidate = typeof config?.ttsEndpoint === 'string' ? config.ttsEndpoint.trim() : '';
        }
      } catch {
        // Same-origin backend remains the default if no optional config exists.
      }
    }
    if (!candidate) candidate = DEFAULT_TTS_ENDPOINT;

    const url = new URL(candidate, window.location.origin);
    if (url.username || url.password || url.search || url.hash || !url.pathname.endsWith('/api/tts')) {
      throw new Error('The voice endpoint must be a public URL ending in /api/tts with no credentials, query string, or fragment.');
    }
    if (url.protocol !== 'https:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) {
      throw new Error('The deployed voice endpoint must use HTTPS.');
    }
    this.resolvedEndpoint = url.href;
    return url.href;
  }

  /**
   * Check whether the ElevenLabs backend is reachable, configured and has
   * the requested voice resolved. Result is cached; pass force to re-check.
   */
  public async checkBackend(force = false): Promise<boolean> {
    if (!force && this.backendAvailable !== null) return this.backendAvailable;

    this.setStatus('checking');
    if (force) this.backendAvailable = null;
    const ctrl = new AbortController();
    // Allow time for a managed web service to wake up after idle.
    const timer = window.setTimeout(() => ctrl.abort(), isLocalBrowser ? 7000 : 75000);
    let healthEndpoint = '/api/health';
    try {
      const endpoint = await this.getEndpoint(force);
      healthEndpoint = endpoint.replace(/\/api\/tts\/?$/, '/api/health');
      const healthUrl = new URL(healthEndpoint);
      if (force) healthUrl.searchParams.set('retry', '1');
      const res = await fetch(healthUrl.href, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: ctrl.signal,
      });
      if (!res.headers.get('content-type')?.includes('application/json')) {
        throw new Error('This origin served a web page instead of the MathMind voice API. The static Arena site has no deployed Node backend at this URL.');
      }
      const json = await res.json();
      if (json?.server !== 'mathmind-3d-backend' || !json.elevenlabs) {
        throw new Error('This URL did not return the MathMind voice backend. Configure the public Node service URL in voice-config.json.');
      }
      const configured = !!json.elevenlabs.configured;
      this.backendAvailable = configured;

      if (res.ok && configured) {
        // A resolved voice is not proof that TTS works. The backend sets
        // audioVerified only after receiving a valid MP3 from ElevenLabs.
        this.setStatus(json.elevenlabs.audioVerified ? 'ready' : 'checking');
      } else {
        this.setStatus(
          'unavailable',
          (json?.elevenlabs?.message as string) ||
            (json?.note as string) ||
            `Voice API returned HTTP ${res.status}. Check backend configuration.`,
        );
      }
      return configured;
    } catch (error) {
      this.backendAvailable = false;
      this.setStatus(
        'unavailable',
        isLocalBrowser && viteEnv.DEV
          ? `The local voice API is not reachable at ${healthEndpoint}. Start the Node server, or set the public endpoint in voice-config.json.`
          : `The deployed voice API is not reachable at ${healthEndpoint}. Arena may be hosting only static files. Deploy the Node service and set its public HTTPS /api/tts URL in public/voice-config.json (or VITE_TTS_ENDPOINT in Arena's build settings). ${error instanceof Error ? error.message : ''}`,
      );
      return false;
    } finally {
      window.clearTimeout(timer);
    }
  }

  /* ---------------- text preparation ---------------- */

  /**
   * Pre-processes math terms for natural Hindi/Hinglish/English pronunciation.
   */
  private prepareTextForVoice(text: string, language: Language): string {
    let clean = text;

    if (language === 'hindi') {
      clean = clean.replace(/\\Delta/g, 'डेल्टा');
      clean = clean.replace(/\\theta/g, 'थीटा');
      clean = clean.replace(/\\pi/g, 'पाई');
    }

    // Clean common LaTeX symbols into natural phonetic words
    clean = clean.replace(/\\Delta/g, 'Delta');
    clean = clean.replace(/\\theta/g, 'Theta');
    clean = clean.replace(/\\pi/g, 'Pi');
    clean = clean.replace(/\\times/g, 'multiplied by');
    clean = clean.replace(/\\cdot/g, 'into');
    clean = clean.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1 over $2');
    clean = clean.replace(/\\sqrt\{([^}]+)\}/g, 'square root of $1');
    clean = clean.replace(/\^2/g, ' squared');
    clean = clean.replace(/\^3/g, ' cubed');
    clean = clean.replace(/\\approx/g, 'approximately equals');
    clean = clean.replace(/\\neq/g, 'not equal to');
    clean = clean.replace(/\\le/g, 'less than or equal to');
    clean = clean.replace(/\\ge/g, 'greater than or equal to');

    // Clean brackets
    clean = clean.replace(/\\left|\\right/g, '');
    clean = clean.replace(/\{|\}/g, ' ');

    return clean;
  }

  /* ---------------- speaking ---------------- */

  /**
   * Speak using the ElevenLabs teacher voice via the backend.
   * On any failure, callbacks.onError fires with a coded error — the UI
   * shows a clear message and a retry option. No substitute voice is used.
   */
  public async speak(
    text: string,
    language: Language,
    callbacks?: SpeechCallbacks,
  ) {
    this.stop();
    const requestId = this.requestId;
    this.activeCallbacks = callbacks;

    const ready = await this.checkBackend();
    if (requestId !== this.requestId) return;
    if (!ready) {
      callbacks?.onError?.(
        voiceError(
          'VOICE_UNAVAILABLE',
          this.lastError ||
            'The ElevenLabs teacher voice is not available. Check the backend server and its configuration.',
        ),
      );
      return;
    }

    const spokenText = this.prepareTextForVoice(text, language);

    try {
      const endpoint = await this.getEndpoint();
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
        body: JSON.stringify({ text: spokenText }),
      });
      if (requestId !== this.requestId) return;

      if (!res.ok) {
        let msg = `Teacher voice request failed (${res.status}) at ${endpoint}.`;
        let errorCode = 'TTS_FAILED';
        try {
          const j = await res.json();
          if (j?.error) errorCode = j.error;
          if (j?.message) msg = j.message;
        } catch {
          /* keep the status-based message */
        }
        this.backendAvailable = false;
        this.setStatus('unavailable', msg);
        callbacks?.onError?.(voiceError(errorCode, msg));
        return;
      }

      const blob = await res.blob();
      if (requestId !== this.requestId) return;
      if (!blob.size || !blob.type.toLowerCase().includes('audio')) {
        throw voiceError('INVALID_AUDIO', 'The backend returned an empty or non-audio response.');
      }
      if (this.currentObjectUrl) URL.revokeObjectURL(this.currentObjectUrl);
      const url = URL.createObjectURL(blob);
      this.currentObjectUrl = url;

      this.audio.src = url;
      this.audio.playbackRate = this.rate;

      this.audio.onended = () => {
        if (requestId !== this.requestId) return;
        this.isSpeaking = false;
        this.isPaused = false;
        URL.revokeObjectURL(url);
        this.currentObjectUrl = null;
        callbacks?.onEnd?.();
      };
      this.audio.onerror = () => {
        if (requestId !== this.requestId) return;
        this.isSpeaking = false;
        this.isPaused = false;
        URL.revokeObjectURL(url);
        this.currentObjectUrl = null;
        const message = 'The ElevenLabs audio response arrived but the browser could not decode or play it.';
        this.setStatus('unavailable', message);
        callbacks?.onError?.(voiceError('TTS_FAILED', 'The teacher voice audio could not be played.'));
      };

      // Do not mark the utterance as started until HTMLMediaElement confirms
      // playback. This catches autoplay-policy failures instead of silently
      // leaving the timeline waiting for audio that never began.
      try {
        await this.audio.play();
        if (requestId !== this.requestId) return;
        this.isSpeaking = true;
        this.isPaused = false;
        this.setStatus('ready');
        callbacks?.onStart?.();
      } catch (playErr: any) {
        if (requestId !== this.requestId) return;
        this.isSpeaking = false;
        this.isPaused = false;
        const message =
          playErr?.name === 'NotAllowedError'
            ? 'The browser blocked audio playback. Press Play again to allow the teacher voice.'
            : 'The ElevenLabs audio was received but playback failed. Press Retry to try again.';
        this.setStatus('unavailable', message);
        callbacks?.onError?.(voiceError('AUDIO_PLAYBACK_FAILED', message));
      }
    } catch (err: any) {
      if (requestId !== this.requestId) return;
      const message = err?.message || 'Could not retrieve teacher audio from the backend.';
      this.backendAvailable = false;
      const detail = isLocalBrowser && viteEnv.DEV
        ? `${message} Start the local Node server or configure voice-config.json.`
        : `${message} Verify the deployed backend and public voice-config.json / VITE_TTS_ENDPOINT setting.`;
      this.setStatus('unavailable', detail);
      callbacks?.onError?.(voiceError(err?.code || 'VOICE_UNAVAILABLE', detail));
    }
  }

  public pause() {
    if (this.audio.src && !this.audio.paused) {
      this.audio.pause();
      this.isPaused = true;
    }
  }

  public resume() {
    if (this.audio.src && this.audio.paused) {
      this.audio.play().then(() => {
        this.isPaused = false;
        this.isSpeaking = true;
      }).catch((err: any) => {
        const message = err?.name === 'NotAllowedError'
          ? 'The browser blocked audio playback. Press Play again to allow the teacher voice.'
          : 'Audio could not resume. Press Retry to try again.';
        this.setStatus('unavailable', message);
        this.activeCallbacks?.onError?.(voiceError('AUDIO_PLAYBACK_FAILED', message));
      });
    }
  }

  public stop() {
    this.requestId += 1;
    this.audio.onended = null;
    this.audio.onerror = null;
    try {
      this.audio.pause();
      this.audio.removeAttribute('src');
      this.audio.load();
    } catch {
      /* no audio loaded */
    }
    if (this.currentObjectUrl) {
      URL.revokeObjectURL(this.currentObjectUrl);
      this.currentObjectUrl = null;
    }
    this.isSpeaking = false;
    this.isPaused = false;
  }

  public getStatus() {
    return {
      isSpeaking: this.isSpeaking,
      isPaused: this.isPaused,
    };
  }

  /* ---------------- speech recognition (student doubts) ---------------- */

  /**
   * Speech recognition for hands-free voice doubts.
   */
  public startSpeechRecognition(
    language: Language,
    onResult: (transcript: string) => void,
    onError: (err: any) => void,
    onEnd: () => void
  ): boolean {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onError('Speech Recognition is not supported on this device/browser.');
      return false;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = true;
      rec.lang = language === 'english' ? 'en-US' : 'hi-IN';

      rec.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((r: any) => r[0].transcript)
          .join('');
        onResult(transcript);
      };

      rec.onerror = (event: any) => {
        onError(event.error);
      };

      rec.onend = () => {
        onEnd();
      };

      rec.start();
      this.recognition = rec;
      return true;
    } catch (e) {
      onError(e);
      return false;
    }
  }

  public stopSpeechRecognition() {
    if (this.recognition) {
      this.recognition.stop();
      this.recognition = null;
    }
  }
}

export const speechService = new SpeechService();
