import { useState } from 'react';
import { Lesson, Language, LearningMode } from './types/math';
import { SAMPLE_LESSONS } from './data/sampleLessons';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ClassroomWorkspace from './components/classroom/ClassroomWorkspace';
import QuestionUploadModal from './components/QuestionUpload/QuestionUploadModal';
import StudentDashboardModal from './components/dashboard/StudentDashboardModal';
import ApiConfigModal from './components/settings/ApiConfigModal';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'classroom'>('home');
  const [activeLesson, setActiveLesson] = useState<Lesson>(SAMPLE_LESSONS[0]);
  const [language, setLanguage] = useState<Language>('hinglish');
  const [learningMode, setLearningMode] = useState<LearningMode>('teacher');

  // Modals state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isApiSettingsOpen, setIsApiSettingsOpen] = useState(false);

  const handleSelectLesson = (lesson: Lesson) => {
    setActiveLesson(lesson);
    setCurrentView('classroom');
  };

  const handleStartLearning = () => {
    setIsUploadOpen(true);
  };

  const handleBackToHome = () => {
    setCurrentView('home');
  };

  return (
    <div className="min-h-screen bg-[#060a17] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Global Navigation Bar */}
      <Navbar
        language={language}
        onLanguageChange={setLanguage}
        learningMode={learningMode}
        onModeChange={setLearningMode}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenDashboard={() => setIsDashboardOpen(true)}
        onOpenApiSettings={() => setIsApiSettingsOpen(true)}
        isInClassroom={currentView === 'classroom'}
      />

      {/* Main View Router */}
      {currentView === 'home' ? (
        <main className="flex-1">
          <HeroSection
            onStartLearning={handleStartLearning}
            onTrySample={handleSelectLesson}
            language={language}
          />
        </main>
      ) : (
        <main className="flex-1">
          <ClassroomWorkspace
            key={activeLesson.id}
            lesson={activeLesson}
            language={language}
            onLanguageChange={setLanguage}
            onBackToHome={handleBackToHome}
          />
        </main>
      )}

      {/* Global Modals */}
      <QuestionUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onSelectLesson={handleSelectLesson}
      />

      <StudentDashboardModal
        isOpen={isDashboardOpen}
        onClose={() => setIsDashboardOpen(false)}
        onSelectLesson={handleSelectLesson}
      />

      <ApiConfigModal
        isOpen={isApiSettingsOpen}
        onClose={() => setIsApiSettingsOpen(false)}
      />
    </div>
  );
}
