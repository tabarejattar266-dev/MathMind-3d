export type Language = 'hinglish' | 'hindi' | 'english';

export type LearningMode =
  | 'teacher'
  | 'quick'
  | 'hint'
  | 'practice'
  | 'exam'
  | 'visual'
  | 'beginner';

/** How the AI teacher adapts depth + pace of the lesson. */
export type TeachingMode = 'beginner' | 'normal' | 'exam';

/** Trilingual narration text. */
export interface Narr {
  hinglish: string;
  hindi: string;
  english: string;
}

/**
 * One physical action on the blackboard.
 *  - write : the chalk writes `latex` progressively, symbol by symbol.
 *  - point : the teacher points at symbols already on the board (`highlight`).
 *  - erase : the eraser sweeps the working area (pinned lines such as the question stay).
 *
 * Narration is spoken AFTER the writing it describes is visible (the `lead`
 * sentence is spoken while the chalk starts moving, and it never names a value
 * that is not yet on the board).
 */
export interface BoardAction {
  id: string;
  kind: 'write' | 'point' | 'erase';
  stepIndex: number;
  latex?: string;
  color?: BoardColor;
  label?: string;
  /** Tokens (single symbols such as "a", "e") highlighted in yellow while speaking. */
  highlight?: string[];
  /** For point actions: id of the write action whose symbols are pointed at. */
  refersTo?: string;
  /** Pinned lines (the question) survive erase actions. */
  pinned?: boolean;
  lead?: Narr;
  narration: Narr;
  writeMs?: number;
  holdMs?: number;
}

/** The 7 pedagogical stages every question must pass through. */
export type TeachingStage =
  | 'question'
  | 'basics'
  | 'formula'
  | 'values'
  | 'solve'
  | 'verify'
  | 'practice';

/** Colour of the chalk used for a board line. */
export type BoardColor = 'chalk' | 'yellow' | 'cyan' | 'emerald' | 'rose';

export interface BoardLine {
  id: string;
  latex: string;
  color: BoardColor;
  label?: string;
}

/**
 * A meaningful mathematical animation. Every animation must illustrate the
 * actual operation being taught — never decoration.
 */
export interface MathAnimationSpec {
  kind:
    | 'none'
    | 'multiply'
    | 'subtract'
    | 'substitute'
    | 'expand'
    | 'sign_flip'
    | 'sum'
    | 'isolate'
    | 'reveal_answer'
    | 'point_terms';
  operands?: string[];
  result?: string;
  label?: string;
  note?: string;
  sign?: 'positive' | 'negative';
}

/**
 * One atomic teaching beat on the continuous lesson timeline.
 * Narration, chalk writing, gesture, camera and animation all hang off a cue,
 * so playback stays perfectly synchronised.
 */
export interface LessonCue {
  id: string;
  stepIndex: number;
  stage: TeachingStage;
  narration: {
    hinglish: string;
    hindi: string;
    english: string;
  };
  /** Used automatically when the student switches to Beginner mode. */
  beginnerNote?: {
    hinglish: string;
    hindi: string;
    english: string;
  };
  /** Latex lines the teacher writes on the board during this cue. */
  boardAppend?: BoardLine[];
  /** Which board region the teacher / camera focuses on. */
  focus?: 'question' | 'formula' | 'values' | 'solve' | 'verify' | 'practice';
  /** Latex fragments highlighted in yellow while speaking. */
  highlightTerms?: string[];
  gesture: 'point' | 'write' | 'explain' | 'emphasize' | 'wave';
  camera: 'wide' | 'board' | 'teacher' | 'students';
  animation?: MathAnimationSpec;
  /** Minimum dwell time (ms) so students can absorb the line. */
  minMs?: number;
}

export type AnimationType =
  | 'matrix_determinant_2x2'
  | 'matrix_determinant_3x3'
  | 'quadratic_parabola'
  | 'unit_circle_trig'
  | 'calculus_tangent_slope'
  | 'geometry_solids'
  | 'equation_balance'
  | 'fraction_visualizer'
  | 'diagram_2d';

export interface VisualHighlight {
  activeIndices?: number[];
  activeTerms?: string[];
  color?: string;
  angleDeg?: number;
  deltaX?: number;
  highlightDiagonals?: 'primary' | 'secondary' | 'both';
  balanceWeights?: { left: number; right: number };
  solidType?: 'cylinder' | 'sphere' | 'cone' | 'cube';
  customParam?: any;
}

export interface StepCheckQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface CalculationLine {
  label: string;
  latex: string;
  note: string;
  isResult?: boolean;
  highlightColor?: string;
}

export interface SolutionStep {
  stepNumber: number;
  title: string;
  stage: TeachingStage;
  equation: string;
  operation: string;
  whyNecessary: string;
  ruleUsed: string;
  speechText: {
    english: string;
    hindi: string;
    hinglish: string;
  };
  simplerExplanation?: {
    english: string;
    hindi: string;
    hinglish: string;
  };
  realLifeAnalogy?: {
    english: string;
    hindi: string;
    hinglish: string;
  };
  calculationLines?: CalculationLine[];
  visualHighlight?: VisualHighlight;
  checkQuestion?: StepCheckQuestion;
  /** Timeline beats that make up this step. */
  cues?: LessonCue[];
  /** Prerequisite concept to re-teach when the student gets the check wrong. */
  remediation?: {
    title: string;
    explanation: string;
    easierExample: string;
    easierExampleLatex?: string;
  };
}

export interface PracticeQuestion {
  id: string;
  question: string;
  latex: string;
  hints: string[];
  finalAnswer: string;
  explanation: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface FormulaSymbolExplanation {
  symbol: string;
  meaning: string;
  color: string;
  position?: string;
}

export interface SignRule {
  rule: string;
  example: string;
  note: string;
}

export interface QuickReminderInfo {
  formulaName: string;
  formulaLatex: string;
  coloredFormulaLatex: string;
  symbols: FormulaSymbolExplanation[];
  signRules: SignRule[];
}

export interface FormulaReference {
  name: string;
  latex: string;
  note: string;
}

export interface VerificationResult {
  method: string;
  latex: string;
  isVerified: boolean;
  explanation: string;
  sanityCheck?: string;
}

export interface Lesson {
  id: string;
  title: string;
  topic: string;
  subtopic: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  originalQuestion: string;
  latexExpression: string;
  imageUrl?: string;
  /** Line written as the heading on the green chalkboard. */
  boardTitle?: string;
  teacherIntro: {
    english: string;
    hindi: string;
    hinglish: string;
  };
  quickReminder: QuickReminderInfo;
  prerequisites: string[];
  formulas: FormulaReference[];
  steps: SolutionStep[];
  /** Flattened timeline used by the video-style playback engine. */
  cues: LessonCue[];
  /** Real-time blackboard script (writing, pointing, erasing) with synced narration. */
  boardScript?: BoardAction[];
  finalAnswerSummary: {
    resultLatex: string;
    resultValue: string;
    verificationNote: string;
    verificationLatex: string;
  };
  verification: VerificationResult;
  animationType: AnimationType;
  animationInitialParams: Record<string, any>;
  commonMistakes: string[];
  importantSignRules: SignRule[];
  revisionSummary: string[];
  practiceQuestions: PracticeQuestion[];
  masteryQuiz: QuizQuestion[];
  /** Short line the teacher says while the lesson is paused. */
  pausedPrompt?: {
    english: string;
    hindi: string;
    hinglish: string;
  };
}

export interface ChatMessage {
  id: string;
  sender: 'student' | 'teacher';
  text: string;
  timestamp: number;
  latex?: string;
  stepRef?: number;
}

export interface StudentProgress {
  topicsStudied: number;
  questionsAttempted: number;
  practiceAccuracy: number;
  streakDays: number;
  completedLessonIds: string[];
  savedQuestionIds: string[];
  weakTopics: string[];
  lastActiveDate: string;
}

export interface ApiSettings {
  provider: 'builtin' | 'openai' | 'anthropic' | 'gemini';
  apiKey: string;
  model: string;
  isConfigured: boolean;
}
