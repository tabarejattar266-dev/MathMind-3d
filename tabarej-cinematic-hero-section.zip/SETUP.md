# MathMind3D Voice Hosting (Arena)

The lesson website is built with Vite. Its current Arena preview/deployment
appears to host static files only: this project contains no Arena server
deployment manifest, no Arena secrets API integration, and no deploy access in
this workspace. The ElevenLabs backend exists in `server/`, but source code in
that folder does not become a running service just because the static site is
published. Starting `npm run dev` locally would not fix visitors' audio.

**The API key must never be placed in frontend code, `public/voice-config.json`,
or a `VITE_` variable.** The key previously shared in chat should be revoked.
Create a replacement key with **Voices (read)** and **Text to Speech** permissions.

## Option A: Host Site and Voice Together (Preferred)

Use a Node hosting platform. `render.yaml` is ready for Render and configures a
web service that builds this Vite site, compiles the backend TypeScript to
`server/dist/index.js`, and runs it with plain Node on the assigned `PORT`.
It serves both the website and `/api/tts`
on the same origin, so the frontend needs no URL configuration or CORS.

From the hosting platforms' web UIs (no local terminal required):

1. Export/push the Arena project to a GitHub repository using Arena's export or
   GitHub option, if available. Check that `server/.env` is **not** included;
   that file was removed from this project. Do not export the old key.
2. In [Render](https://dashboard.render.com), choose **New > Blueprint**, connect
   that repository, select `render.yaml`, and choose **Deploy Blueprint**.
3. When Render asks for `ELEVENLABS_API_KEY` (marked `sync: false`), paste a
   **new rotated key there**, not into Arena or the repo. Enable **Voices (read)**
   and **Text to Speech** on the ElevenLabs key. Set `PORT` only if your host
   does not supply one. No `VITE_` secret is needed.
4. Open the resulting Render URL. `/livez` should return HTTP 200. `/api/health`
   should report `elevenlabs.configured: true` after resolving the exact voice;
   `elevenlabs.ready` remains false until the first valid MP3 is generated.
   `/api/voices` should list **Michael C.
   Vincent - Suspenseful Storyteller** with an ID resolved from ElevenLabs.
   If it does not, follow the specific error shown there (permissions, invalid
   key, or exact voice unavailable). No other voice will be used.
5. Play a sample maths lesson at the Render URL and confirm the browser receives
   `audio/mpeg` for `/api/tts` and that it is audible. After this, `/api/health`
   reports `elevenlabs.ready: true`. This is the test that proves playback,
   not merely a healthy server.

Note: Render's free web services may sleep when idle; the frontend allows up
to 75 seconds for a cold start. An always-on plan is an option if cold starts
are unacceptable.

## Option B: Keep the Existing Arena URL (Static Frontend)

If Arena cannot host a Node web service or store server-side secrets, **an
external Node service is required**. The static Arena page alone cannot call
ElevenLabs securely. You can use the Render service above as the voice API:

1. Deploy the Node service in Render as in Option A, including the rotated
   `ELEVENLABS_API_KEY` in **Render's backend secret settings**.
2. Copy Render's public HTTPS URL (e.g. `https://your-service.onrender.com`).
3. In Arena's project file editor, set the **public URL only** in
   `public/voice-config.json`:

   ```json
   { "ttsEndpoint": "https://your-service.onrender.com/api/tts" }
   ```

   Then publish/redeploy the Arena frontend. Alternatively, if Arena provides
   frontend build environment settings, set `VITE_TTS_ENDPOINT` to that same
   public URL and rebuild/redeploy. It is a URL, **not** the API key.
4. In Render's service **Environment** settings, set `FRONTEND_ORIGINS` to the
   Arena website's exact origin, e.g. `https://your-site.example`. Do not add a
   trailing slash or a path. Save/redeploy the service so browsers can call it.
5. Open the Arena URL and play a lesson. The voice error banner should clear,
   and the network request to the Render `/api/tts` URL should return
   `200 audio/mpeg`. Check by listening too. If `/api/health` says
   `MISSING_VOICES_READ`, fix the ElevenLabs key permissions in Render.

`public/voice-config.json` exists so this public URL can be changed in Arena's
file editor without access to a terminal or a build-time secret. It defaults
to an empty value; same-origin `/api/tts` is used until an external URL is
configured. During truly local Vite development, the backend URL defaults to
`http://localhost:8787/api/tts`, but this **never** applies on a remote Arena
preview or deployed production site.

## Test and Troubleshoot

- `/livez`: the Node process is running (200 even before a secret is configured).
- `/api/health`: the Node service reports voice status with 401/403/503 for
  invalid/missing credentials or unavailable voice, and 502 if generation failed.
  A 200 before the first successful `/api/tts` does **not** claim audio works:
  `elevenlabs.ready` remains false until a valid MP3 was returned.
- `/api/voices`: the exact teacher voice and account/library source; empty list
  means it has not been verified, so no substitute voice is used.
- `/api/tts`: returns actual `audio/mpeg` only after ElevenLabs grants access
  to the requested voice. Permission errors return clear JSON instead.
- The website's **Retry voice connection** control repeats the health check
  without changing the classroom, math solver, blackboard, or other features.
- If an Arena static deployment shows a backend-not-reachable message, the
  Node service is either not deployed or its public URL/CORS origin is not
  configured. It is not a request to start a terminal on your own computer.

The previous key was present in a local `server/.env` but was exposed in chat
and lacked **Voices (read)**, so it was removed. The new key must be configured
by the hosting platform after rotation. No live audio success can be claimed
until the remote service and browser have been tested with that new key.